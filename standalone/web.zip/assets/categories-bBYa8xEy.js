const s=[{slug:"skincare",label:"스킨케어"},{slug:"maskpack",label:"마스크팩"},{slug:"cleansing",label:"클렌징"},{slug:"suncare",label:"선케어"}];function e(l){return s.find(a=>a.slug===l)}export{s as C,e as f};
