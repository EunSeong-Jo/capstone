import{I as o}from"./index-DG-msEo5.js";import{j as t,k as r,v as s}from"./proxy-DCLTRJd5.js";function i(){!t.current&&r();const[e]=o.useState(s.current);return e}export{i as u};
