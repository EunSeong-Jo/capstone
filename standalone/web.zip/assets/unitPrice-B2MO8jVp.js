const r={sheet:"1매당",ml10:"10ml당",g10:"10g당",piece:"1개당"};function e(n,t){if(n==null||!t)return null;const l=r[t];return l?`${l} ${Math.round(n).toLocaleString()}원`:null}export{e as f};
