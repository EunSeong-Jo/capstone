import{I as o}from"./index-Cm4sjtEO.js";import{j as t,k as r,v as s}from"./proxy-CVzcZ_1f.js";function i(){!t.current&&r();const[e]=o.useState(s.current);return e}export{i as u};
