
  # Design User Profile Screen

  This is a code bundle for Design User Profile Screen. The original project is available at https://www.figma.com/design/obPHXC7L4rRxJ82l33HRO1/Design-User-Profile-Screen.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  