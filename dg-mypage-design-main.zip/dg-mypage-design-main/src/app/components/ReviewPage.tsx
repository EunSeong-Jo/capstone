import React, { useState } from "react";
import { ArrowLeft, Home, ChevronRight, ExternalLink } from "lucide-react";

const BLUE = "#1A6EE8";

type MainTab = "작성 가능한 후기" | "작성한 후기" | "체험단 신청";
type SubTab  = "온라인 구매" | "오프라인 구매";

const writableItems = [
  {
    id: 1,
    maxPoint: 500,
    brand: "이니스프리",
    name: "수분 밸런싱 토너 200ml",
    option: "기본 · 200ml",
    date: "2026.06.05 구매확정",
    bg: "#DFF0E8",
    emoji: "🧴",
  },
  {
    id: 2,
    maxPoint: 800,
    brand: "닥터자르트",
    name: "세라마이드 수분 크림 60ml",
    option: "기본 · 60ml",
    date: "2026.06.05 구매확정",
    bg: "#FCE4E4",
    emoji: "🫙",
  },
  {
    id: 3,
    maxPoint: 400,
    brand: "코스알엑스",
    name: "히알루론산 에센스 50ml",
    option: "기본 · 50ml",
    date: "2026.05.28 구매확정",
    bg: "#E0ECF8",
    emoji: "💧",
  },
  {
    id: 4,
    maxPoint: 600,
    brand: "마녀공장",
    name: "순식물성 클렌징 오일 200ml",
    option: "기본 · 200ml",
    date: "2026.05.28 구매확정",
    bg: "#FDF5DC",
    emoji: "🫧",
  },
  {
    id: 5,
    maxPoint: 500,
    brand: "에스트라",
    name: "365 수분크림 50ml",
    option: "기본 · 50ml",
    date: "2026.05.20 구매확정",
    bg: "#F0E8F8",
    emoji: "✨",
  },
  {
    id: 6,
    maxPoint: 300,
    brand: "아베노",
    name: "스킨 릴리프 로션 354ml",
    option: "기본 · 354ml",
    date: "2026.05.10 구매확정",
    bg: "#E8F4E8",
    emoji: "🌿",
  },
  {
    id: 7,
    maxPoint: 700,
    brand: "설화수",
    name: "윤조에센스 75ml",
    option: "기본 · 75ml",
    date: "2026.04.22 구매확정",
    bg: "#FDE8E8",
    emoji: "🌸",
  },
  {
    id: 8,
    maxPoint: 1000,
    brand: "헤라",
    name: "블랙쿠션 파운데이션 15g",
    option: "21N1 · 15g",
    date: "2026.04.11 구매확정",
    bg: "#F5EDE0",
    emoji: "💄",
  },
];

const writtenItems = [
  {
    id: 101,
    maxPoint: 500,
    brand: "라운드랩",
    name: "독도 토너 200ml",
    option: "기본 · 200ml",
    date: "2026.03.15 구매확정",
    bg: "#DFF0E8",
    emoji: "🧴",
    rating: 5,
    reviewDate: "2026.03.20",
  },
  {
    id: 102,
    maxPoint: 800,
    brand: "아토팜",
    name: "MLE 크림 65ml",
    option: "기본 · 65ml",
    date: "2026.03.01 구매확정",
    bg: "#E0ECF8",
    emoji: "🫙",
    rating: 4,
    reviewDate: "2026.03.08",
  },
];

interface Props { onBack: () => void; }

function StarRating({ rating }: { rating: number }) {
  return (
    <span style={{ fontSize: 12, letterSpacing: 1 }}>
      {"⭐".repeat(rating)}{"☆".repeat(5 - rating)}
    </span>
  );
}

export function ReviewPage({ onBack }: Props) {
  const [mainTab, setMainTab] = useState<MainTab>("작성 가능한 후기");
  const [subTab,  setSubTab]  = useState<SubTab>("온라인 구매");

  const mainTabs: MainTab[] = ["작성 가능한 후기", "작성한 후기", "체험단 신청"];

  return (
    <div style={{
      minHeight: "100vh", background: "#fff",
      maxWidth: 375, margin: "0 auto",
      display: "flex", flexDirection: "column",
    }}>

      {/* ── 헤더 ── */}
      <div style={{
        position: "sticky", top: 0, background: "#fff",
        zIndex: 40, borderBottom: "1px solid rgba(0,0,0,0.07)",
      }}>
        <div style={{ height: 48 }} />
        <div style={{
          display: "flex", alignItems: "center", justifyContent: "space-between",
          padding: "0 16px 14px",
        }}>
          <button onClick={onBack}><ArrowLeft size={22} color="#1A1A1A" /></button>
          <span style={{ fontSize: 16, fontWeight: 700, color: "#1A1A1A" }}>후기</span>
          <button><Home size={22} color="#1A1A1A" /></button>
        </div>
      </div>

      {/* ── 스크롤 영역 ── */}
      <div style={{ flex: 1, overflowY: "auto", scrollbarWidth: "none" }}>

        {/* 적립 가능 금액 */}
        <div style={{ padding: "20px 16px 12px" }}>
          <div style={{ display: "flex", alignItems: "baseline", gap: 6, marginBottom: 6 }}>
            <span style={{ fontSize: 16, fontWeight: 600, color: "#1A1A1A" }}>적립가능 금액</span>
            <span style={{ fontSize: 20, fontWeight: 800, color: BLUE }}>19,000원</span>
          </div>
          <div style={{
            display: "flex", alignItems: "center", justifyContent: "space-between",
          }}>
            <span style={{ fontSize: 13, color: "#888" }}>나의 후기 9개 · 도움돼요 0개</span>
            <button style={{ fontSize: 13, color: "#555", fontWeight: 600 }}>작성 안내</button>
          </div>
        </div>

        {/* 후기왕 챌린지 배너 */}
        <div style={{ padding: "0 16px 16px" }}>
          <button style={{
            width: "100%", display: "flex", alignItems: "center", justifyContent: "space-between",
            padding: "13px 16px", borderRadius: 10,
            border: "1.5px solid #E0E0E0", background: "#fff",
          }}>
            <span style={{ fontSize: 14, fontWeight: 700, color: "#1A1A1A" }}>
              100만원 적립금의 후기왕에 도전해보세요!
            </span>
            <ChevronRight size={16} color="#888" />
          </button>
        </div>

        {/* ── 메인 탭 ── */}
        <div style={{
          display: "flex", alignItems: "flex-end",
          borderBottom: "1px solid #EBEBEB",
          padding: "0 16px",
          gap: 20,
        }}>
          {mainTabs.map(t => (
            <div key={t} style={{ position: "relative", paddingBottom: 10 }}>
              <button
                onClick={() => setMainTab(t)}
                style={{
                  display: "flex", alignItems: "center", gap: 3,
                  background: "transparent", border: "none",
                  fontSize: 14, fontWeight: 700,
                  color: mainTab === t ? "#1A1A1A" : "#BBBBBB",
                  whiteSpace: "nowrap",
                }}
              >
                {t}
                {t === "작성 가능한 후기" && (
                  <span style={{ fontSize: 14, fontWeight: 700, color: mainTab === t ? "#1A1A1A" : "#BBBBBB" }}> 14</span>
                )}
                {t === "작성한 후기" && (
                  <span style={{ fontSize: 14, fontWeight: 700, color: mainTab === t ? "#1A1A1A" : "#BBBBBB" }}> 9</span>
                )}
                {t === "체험단 신청" && (
                  <ExternalLink size={12} color={mainTab === t ? "#1A1A1A" : "#BBBBBB"} />
                )}
              </button>
              {mainTab === t && (
                <div style={{
                  position: "absolute", bottom: -1, left: 0, right: 0,
                  height: 2, background: "#1A1A1A",
                }} />
              )}
            </div>
          ))}
        </div>

        {/* ── 서브 탭 (온라인/오프라인) ── */}
        <div style={{
          display: "flex", background: "#F6F6F6",
          borderBottom: "1px solid #E8E8E8",
        }}>
          {(["온라인 구매", "오프라인 구매"] as SubTab[]).map(t => (
            <button
              key={t}
              onClick={() => setSubTab(t)}
              style={{
                padding: "11px 20px",
                fontSize: 13, fontWeight: subTab === t ? 700 : 500,
                color: subTab === t ? "#1A1A1A" : "#999",
                background: subTab === t ? "#fff" : "transparent",
                border: "none",
                borderBottom: subTab === t ? "2px solid #1A1A1A" : "2px solid transparent",
              }}
            >{t}</button>
          ))}
        </div>

        {/* ── 상품 목록 ── */}
        <div style={{ minHeight: "calc(100vh - 340px)" }}>
          {mainTab === "작성 가능한 후기" && writableItems.map((item, idx) => (
            <div
              key={item.id}
              style={{ borderBottom: "1px solid #F0F0F0" }}
            >
              {/* 상품 정보 */}
              <div style={{ display: "flex", gap: 12, padding: "16px 16px 10px" }}>
                {/* 이미지 */}
                <div style={{
                  width: 80, height: 80, borderRadius: 10, flexShrink: 0,
                  background: item.bg,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 36, border: "1px solid rgba(0,0,0,0.05)",
                }}>
                  {item.emoji}
                </div>

                {/* 텍스트 */}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 4, marginBottom: 3 }}>
                    <span style={{ fontSize: 11, color: "#888" }}>최대적립금</span>
                    <span style={{ fontSize: 13, fontWeight: 700, color: BLUE }}>
                      {item.maxPoint.toLocaleString()}원
                    </span>
                  </div>
                  <p style={{ fontSize: 12, color: "#888", marginBottom: 2 }}>{item.brand}</p>
                  <p style={{
                    fontSize: 13, fontWeight: 600, color: "#1A1A1A",
                    lineHeight: 1.4, marginBottom: 4,
                  }} className="line-clamp-2">{item.name}</p>
                  <p style={{ fontSize: 11, color: "#aaa" }}>{item.option} | {item.date}</p>
                </div>
              </div>

              {/* 후기 작성 버튼 2개 */}
              <div style={{
                display: "grid", gridTemplateColumns: "1fr 1fr",
                gap: 8, padding: "0 16px 16px",
              }}>
                {["후기 작성", "스타일 후기 작성"].map(label => (
                  <button key={label} style={{
                    padding: "10px 0", borderRadius: 8,
                    border: "1px solid #CCCCCC", background: "#fff",
                    fontSize: 13, fontWeight: 600, color: "#1A1A1A",
                  }}>{label}</button>
                ))}
              </div>
            </div>
          ))}

          {mainTab === "작성한 후기" && writtenItems.map((item) => (
            <div key={item.id} style={{ borderBottom: "1px solid #F0F0F0" }}>
              <div style={{ display: "flex", gap: 12, padding: "16px 16px 10px" }}>
                <div style={{
                  width: 80, height: 80, borderRadius: 10, flexShrink: 0,
                  background: item.bg,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 36, border: "1px solid rgba(0,0,0,0.05)",
                }}>
                  {item.emoji}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 4, marginBottom: 3 }}>
                    <StarRating rating={item.rating} />
                    <span style={{ fontSize: 11, color: "#aaa", marginLeft: 4 }}>
                      {item.reviewDate} 작성
                    </span>
                  </div>
                  <p style={{ fontSize: 12, color: "#888", marginBottom: 2 }}>{item.brand}</p>
                  <p style={{
                    fontSize: 13, fontWeight: 600, color: "#1A1A1A",
                    lineHeight: 1.4, marginBottom: 4,
                  }}>{item.name}</p>
                  <p style={{ fontSize: 11, color: "#aaa" }}>{item.option} | {item.date}</p>
                </div>
              </div>
              <div style={{ padding: "0 16px 16px" }}>
                <button style={{
                  width: "100%", padding: "10px 0", borderRadius: 8,
                  border: "1px solid #CCCCCC", background: "#fff",
                  fontSize: 13, fontWeight: 600, color: "#1A1A1A",
                }}>후기 수정</button>
              </div>
            </div>
          ))}

          {mainTab === "체험단 신청" && (
            <div style={{
              display: "flex", flexDirection: "column", alignItems: "center",
              justifyContent: "center", padding: "60px 20px",
              color: "#aaa", gap: 8,
            }}>
              <span style={{ fontSize: 32 }}>📝</span>
              <p style={{ fontSize: 14 }}>진행 중인 체험단이 없습니다.</p>
            </div>
          )}
        </div>

        <div style={{ height: 32 }} />
      </div>
    </div>
  );
}
