import React, { useState } from "react";
import { ArrowLeft, Home, Search, ChevronDown, Share2 } from "lucide-react";

const G = "#3C7358";

type CouponTab = "보유 쿠폰" | "쿠폰 받기";

const categories = ["전체", "뷰티", "스킨케어", "만료임박", "장바구니 쿠폰", "등급 쿠폰팩", "브랜드"];

const coupons = [
  {
    id: 1,
    discount: "20%",
    name: "6월 뷰티 전월 구매 감사 20% 쿠폰",
    maxDiscount: "최대 1만5천원 할인",
    expiry: "만료 5일 전",
    category: "뷰티",
    shared: false,
  },
  {
    id: 2,
    discount: "15%",
    name: "6월 럭셔리 뷰티 브랜드 15% 쿠폰",
    maxDiscount: "최대 1만원 할인",
    expiry: "만료 5일 전",
    category: "뷰티",
    shared: false,
  },
  {
    id: 3,
    discount: "15%",
    name: "[뷰티] 6월 뷰티 전월 구매 감사 럭셔리 15% 쿠폰",
    maxDiscount: "최대 2만원 할인",
    expiry: "만료 5일 전",
    category: "뷰티",
    shared: false,
  },
  {
    id: 4,
    discount: "15%",
    name: "뷰티 브랜드 15% 쿠폰",
    maxDiscount: "최대 7천원 할인",
    expiry: "만료 5일 전",
    category: "뷰티",
    shared: true,
  },
  {
    id: 5,
    discount: "10%",
    name: "스킨케어 신규 브랜드 10% 쿠폰",
    maxDiscount: "최대 5천원 할인",
    expiry: "만료 12일 전",
    category: "스킨케어",
    shared: false,
  },
  {
    id: 6,
    discount: "5%",
    name: "전 브랜드 5% 추가 할인 쿠폰",
    maxDiscount: "최대 3천원 할인",
    expiry: "만료 20일 전",
    category: "장바구니 쿠폰",
    shared: false,
  },
];

interface Props { onBack: () => void; }

export function CouponPage({ onBack }: Props) {
  const [activeTab, setActiveTab] = useState<CouponTab>("보유 쿠폰");
  const [selectedCategory, setSelectedCategory] = useState("뷰티");
  const [searchText, setSearchText] = useState("");
  const [sortOpen, setSortOpen] = useState(false);

  const filtered = coupons.filter(c => {
    const matchCat = selectedCategory === "전체" || c.category === selectedCategory;
    const matchSearch = c.name.includes(searchText) || searchText === "";
    return matchCat && matchSearch;
  });

  return (
    <div style={{ minHeight: "100vh", background: "#F4F6F4", maxWidth: 375, margin: "0 auto", display: "flex", flexDirection: "column" }}>

      {/* 헤더 */}
      <div style={{ position: "sticky", top: 0, background: "#fff", zIndex: 40, borderBottom: "1px solid rgba(0,0,0,0.07)" }}>
        <div style={{ height: 48 }} />
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 16px 0" }}>
          <button onClick={onBack}><ArrowLeft size={22} color="#1A1A1A" /></button>
          <span style={{ fontSize: 16, fontWeight: 700, color: "#1A1A1A" }}>쿠폰</span>
          <button><Home size={22} color="#1A1A1A" /></button>
        </div>

        {/* 쿠폰 탭 */}
        <div style={{ display: "flex", alignItems: "center", padding: "10px 16px 0", gap: 4 }}>
          {(["보유 쿠폰", "쿠폰 받기"] as CouponTab[]).map(t => (
            <button
              key={t}
              onClick={() => setActiveTab(t)}
              style={{
                padding: "8px 0",
                marginRight: 16,
                fontSize: 15,
                fontWeight: activeTab === t ? 700 : 400,
                color: activeTab === t ? "#1A1A1A" : "#aaa",
                borderBottom: activeTab === t ? "2.5px solid #1A1A1A" : "2.5px solid transparent",
                background: "transparent",
                whiteSpace: "nowrap",
              }}
            >
              {t} <span style={{ fontSize: 13 }}>
                {t === "보유 쿠폰" ? "(5장)" : "(1,990장)"}
              </span>
            </button>
          ))}
          <div style={{ flex: 1 }} />
          <button style={{
            padding: "7px 12px", borderRadius: 8,
            border: "1.5px solid #1A1A1A",
            background: "#fff", fontSize: 12, fontWeight: 700, color: "#1A1A1A",
            whiteSpace: "nowrap",
          }}>
            + 쿠폰등록
          </button>
        </div>

        {/* 검색창 */}
        <div style={{ padding: "12px 16px 0" }}>
          <div style={{
            display: "flex", alignItems: "center", gap: 8,
            background: "#F4F4F4", borderRadius: 10, padding: "10px 14px",
          }}>
            <input
              value={searchText}
              onChange={e => setSearchText(e.target.value)}
              placeholder="브랜드, 쿠폰명으로 검색해보세요."
              style={{
                flex: 1, background: "transparent", border: "none", outline: "none",
                fontSize: 13, color: "#1A1A1A",
              }}
            />
            <Search size={16} color="#aaa" />
          </div>
        </div>

        {/* 카테고리 필터 */}
        <div style={{
          display: "flex", gap: 6,
          padding: "12px 16px 12px",
          overflowX: "auto", scrollbarWidth: "none",
        }}>
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              style={{
                padding: "6px 14px", borderRadius: 20, whiteSpace: "nowrap",
                fontSize: 13, fontWeight: selectedCategory === cat ? 700 : 400,
                background: selectedCategory === cat ? "#1A1A1A" : "#fff",
                color: selectedCategory === cat ? "#fff" : "#555",
                border: selectedCategory === cat ? "none" : "1px solid #DEDEDE",
                flexShrink: 0,
              }}
            >{cat}</button>
          ))}
        </div>
      </div>

      {/* 카운트 + 정렬 */}
      <div style={{
        display: "flex", alignItems: "center", justifyContent: "space-between",
        padding: "12px 20px", background: "#fff",
        borderBottom: "1px solid rgba(0,0,0,0.06)",
      }}>
        <span style={{ fontSize: 13, color: "#555", fontWeight: 600 }}>{filtered.length}장</span>
        <div style={{ position: "relative" }}>
          <button
            onClick={() => setSortOpen(!sortOpen)}
            style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 13, color: "#555" }}
          >
            할인순 <ChevronDown size={14} color="#555" style={{ transform: sortOpen ? "rotate(180deg)" : "none", transition: "transform 0.2s" }} />
          </button>
          {sortOpen && (
            <div style={{
              position: "absolute", right: 0, top: "100%", marginTop: 4,
              background: "#fff", borderRadius: 10, boxShadow: "0 4px 16px rgba(0,0,0,0.12)",
              zIndex: 100, overflow: "hidden", minWidth: 100,
            }}>
              {["할인순", "만료임박순", "최신순"].map(opt => (
                <button key={opt} onClick={() => setSortOpen(false)} style={{
                  display: "block", width: "100%", textAlign: "left",
                  padding: "11px 16px", fontSize: 13, color: "#1A1A1A",
                  borderBottom: "1px solid rgba(0,0,0,0.05)", background: "transparent",
                }}>{opt}</button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* 쿠폰 목록 */}
      <div style={{ flex: 1, overflowY: "auto", padding: "12px 16px 32px", scrollbarWidth: "none" }}>
        {filtered.length === 0 ? (
          <div style={{ textAlign: "center", padding: "60px 0", color: "#aaa", fontSize: 14 }}>
            해당 쿠폰이 없습니다.
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {filtered.map(coupon => (
              <div
                key={coupon.id}
                style={{
                  background: "#fff",
                  borderRadius: 14,
                  padding: "18px 16px 14px",
                  boxShadow: "0 1px 6px rgba(0,0,0,0.06)",
                  position: "relative",
                  overflow: "hidden",
                }}
              >
                {/* 왼쪽 컬러 액센트 바 */}
                <div style={{
                  position: "absolute", left: 0, top: 0, bottom: 0,
                  width: 4, background: G, borderRadius: "14px 0 0 14px",
                }} />

                <div style={{ paddingLeft: 8 }}>
                  {/* 할인율 */}
                  <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 8 }}>
                    {coupon.shared && <Share2 size={14} color="#aaa" />}
                    <span style={{ fontSize: 26, fontWeight: 800, color: "#1A1A1A", lineHeight: 1 }}>
                      {coupon.discount}
                    </span>
                  </div>

                  {/* 쿠폰명 */}
                  <p style={{ fontSize: 14, fontWeight: 600, color: "#1A1A1A", marginBottom: 4, lineHeight: 1.45 }}>
                    {coupon.name}
                  </p>

                  {/* 부가 정보 */}
                  <p style={{ fontSize: 12, color: "#888", marginBottom: 2 }}>{coupon.maxDiscount}</p>

                  {/* 하단 행 */}
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 8 }}>
                    <span style={{
                      fontSize: 12, color: "#E85A2A", fontWeight: 500,
                    }}>{coupon.expiry}</span>
                    <button style={{
                      fontSize: 12, fontWeight: 700, color: G,
                      textDecoration: "underline", background: "transparent", border: "none",
                    }}>적용상품</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
