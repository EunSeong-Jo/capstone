import React, { useState } from "react";
import { ArrowLeft, ShoppingBag, X, Bell } from "lucide-react";
import emptyCharImg from "../../imports/KakaoTalk_20260625_022210725_15.png";

const G = "#3C7358";

type StoreTab = "온라인몰";

interface RestockItem {
  id: number;
  brand: string;
  name: string;
  option: string;
  price: string;
  bg: string;
  emoji: string;
  date: string;
  status: "신청중" | "재입고됨";
}

const onlineItems: RestockItem[] = [
  {
    id: 1,
    brand: "이니스프리",
    name: "블랙티 유스 앰플 30ml",
    option: "기본",
    price: "52,000원",
    bg: "#DFF0E8",
    emoji: "🧴",
    date: "2026.06.20 신청",
    status: "신청중",
  },
  {
    id: 2,
    brand: "헤라",
    name: "블랙쿠션 파운데이션 15g",
    option: "23 베이지",
    price: "65,000원",
    bg: "#F5EDE0",
    emoji: "💄",
    date: "2026.06.15 신청",
    status: "재입고됨",
  },
  {
    id: 3,
    brand: "설화수",
    name: "윤조에센스 6세대 75ml",
    option: "기본",
    price: "120,000원",
    bg: "#FDE8E8",
    emoji: "🌸",
    date: "2026.06.10 신청",
    status: "신청중",
  },
];


interface Props { onBack: () => void; }

export function RestockPage({ onBack }: Props) {
  const [tab, setTab] = useState<StoreTab>("온라인몰");
  const [items, setItems] = useState<RestockItem[]>(onlineItems);

  const cancel = (id: number) => setItems(prev => prev.filter(i => i.id !== id));

  const isEmpty = tab === "매장" || items.length === 0;

  return (
    <div style={{
      minHeight: "100vh", background: "#fff",
      maxWidth: 375, margin: "0 auto",
      display: "flex", flexDirection: "column",
    }}>

      {/* ── 헤더 ── */}
      <div style={{
        position: "sticky", top: 0, background: "#fff",
        zIndex: 40, borderBottom: "1px solid rgba(0,0,0,0.07)",
      }}>
        <div style={{ height: 48 }} />
        <div style={{
          display: "flex", alignItems: "center", justifyContent: "space-between",
          padding: "0 16px 0",
        }}>
          <button onClick={onBack}><ArrowLeft size={22} color="#1A1A1A" /></button>
          <span style={{ fontSize: 16, fontWeight: 700, color: "#1A1A1A" }}>
            재입고 알림 신청 내역
          </span>
          <button><ShoppingBag size={22} color="#1A1A1A" /></button>
        </div>

        <div style={{ height: 1, background: "#EBEBEB", marginTop: 4 }} />
      </div>

      {/* ── 바디 ── */}
      <div style={{
        flex: 1, overflowY: "auto", scrollbarWidth: "none",
        display: "flex", flexDirection: "column",
      }}>
        {isEmpty ? (
          /* ── 빈 상태 ── */
          <div style={{
            flex: 1, display: "flex", flexDirection: "column",
            alignItems: "center", justifyContent: "center",
            padding: "0 32px 80px",
          }}>
            <img src={emptyCharImg} alt="빈 상태 캐릭터" style={{ width: 120, height: 120, objectFit: "contain" }} />
            <p style={{ fontSize: 15, color: "#AAAAAA", marginTop: 12, textAlign: "center" }}>
              재입고 알림을 신청한 상품이 없어요.
            </p>
          </div>
        ) : (
          /* ── 상품 목록 ── */
          <div style={{ minHeight: "calc(100vh - 130px)" }}>
            {/* 건수 */}
            <div style={{ padding: "14px 16px 4px" }}>
              <span style={{ fontSize: 13, color: "#888", fontWeight: 600 }}>
                총 {items.length}건
              </span>
            </div>

            {items.map((item, idx) => (
              <div
                key={item.id}
                style={{
                  borderBottom: "1px solid #F2F2F2",
                  padding: "14px 16px",
                }}
              >
                <div style={{ display: "flex", gap: 12 }}>
                  {/* 이미지 */}
                  <div style={{
                    width: 80, height: 80, borderRadius: 12, flexShrink: 0,
                    background: item.bg,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 36, border: "1px solid rgba(0,0,0,0.05)",
                    position: "relative",
                  }}>
                    {item.emoji}
                    {/* 재입고됨 뱃지 */}
                    {item.status === "재입고됨" && (
                      <div style={{
                        position: "absolute", top: -6, left: -6,
                        background: G, borderRadius: 20,
                        padding: "2px 7px",
                        display: "flex", alignItems: "center", gap: 3,
                      }}>
                        <Bell size={9} color="#fff" />
                        <span style={{ fontSize: 9, fontWeight: 700, color: "#fff" }}>재입고</span>
                      </div>
                    )}
                  </div>

                  {/* 텍스트 */}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <p style={{ fontSize: 12, color: "#999", marginBottom: 2 }}>{item.brand}</p>
                        <p style={{
                          fontSize: 13, fontWeight: 600, color: "#1A1A1A",
                          lineHeight: 1.4, marginBottom: 3,
                        }}>{item.name}</p>
                        <p style={{ fontSize: 12, color: "#aaa", marginBottom: 4 }}>
                          옵션 : {item.option}
                        </p>
                        <p style={{ fontSize: 14, fontWeight: 700, color: "#1A1A1A" }}>
                          {item.price}
                        </p>
                      </div>
                      {/* X 버튼 */}
                      <button
                        onClick={() => cancel(item.id)}
                        style={{
                          padding: 4, marginLeft: 8, flexShrink: 0,
                          background: "transparent", border: "none",
                        }}
                      >
                        <X size={18} color="#CCCCCC" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* 하단 상태 + 날짜 행 */}
                <div style={{
                  display: "flex", alignItems: "center",
                  justifyContent: "space-between",
                  marginTop: 12,
                }}>
                  <span style={{ fontSize: 11, color: "#aaa" }}>{item.date}</span>

                  {item.status === "재입고됨" ? (
                    <button style={{
                      padding: "8px 18px", borderRadius: 8,
                      background: G, border: "none",
                      fontSize: 13, fontWeight: 700, color: "#fff",
                    }}>바로 구매</button>
                  ) : (
                    <span style={{
                      fontSize: 12, fontWeight: 600,
                      color: "#AAAAAA",
                      display: "flex", alignItems: "center", gap: 4,
                    }}>
                      <Bell size={13} color="#CCCCCC" />
                      알림 신청중
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
