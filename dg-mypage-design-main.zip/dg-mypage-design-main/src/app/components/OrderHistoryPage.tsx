import React, { useState } from "react";
import { ArrowLeft, ShoppingBag, ChevronDown } from "lucide-react";

const G_DARK = "#3C7358";

/* ── 주문 데이터 ── */
const orders = [
  {
    id: "ORD-2026041101",
    date: "2026.04.11",
    status: "배송완료",
    statusBg: "#333",
    statusColor: "#fff",
    items: [
      {
        id: 1,
        name: "수분 밸런싱 토너 200ml",
        option: "옵션 : 기본 200ml",
        qty: 1,
        price: "28,000",
        bg: "#DFF0E8",
        emoji: "🧴",
      },
      {
        id: 2,
        name: "히알루론산 에센스 50ml",
        option: "옵션 : 기본 50ml",
        qty: 1,
        price: "18,000",
        bg: "#E0ECF8",
        emoji: "💧",
      },
    ],
  },
  {
    id: "ORD-2026060501",
    date: "2026.06.05",
    status: "배송중",
    statusBg: G_DARK,
    statusColor: "#fff",
    items: [
      {
        id: 3,
        name: "세라마이드 수분 크림 60ml",
        option: "옵션 : 본품 60ml",
        qty: 1,
        price: "42,000",
        bg: "#FCE4E4",
        emoji: "🫙",
      },
    ],
  },
  {
    id: "ORD-2026061801",
    date: "2026.06.18",
    status: "결제완료",
    statusBg: "#F0EAE0",
    statusColor: "#8B6A3A",
    items: [
      {
        id: 4,
        name: "나이아신아마이드 세럼 30ml",
        option: "옵션 : 기본 30ml",
        qty: 2,
        price: "34,000",
        bg: "#FDF5DC",
        emoji: "✨",
      },
      {
        id: 5,
        name: "순한 거품 클렌저 150ml",
        option: "옵션 : 기본 150ml",
        qty: 1,
        price: "15,000",
        bg: "#EDE8F8",
        emoji: "🫧",
      },
    ],
  },
];

const purchaseTypes = ["온라인몰 구매", "매장 구매"];
const statusTypes   = ["전체 상태", "주문접수", "결제완료", "배송준비중", "배송중", "배송완료"];

interface Props {
  onBack: () => void;
}

export function OrderHistoryPage({ onBack }: Props) {
  const [purchaseOpen, setPurchaseOpen] = useState(false);
  const [statusOpen,   setStatusOpen]   = useState(false);
  const [selectedPurchase, setSelectedPurchase] = useState("온라인몰 구매");
  const [selectedStatus,   setSelectedStatus]   = useState("전체 상태");

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#F4F6F4",
        maxWidth: 375,
        margin: "0 auto",
        display: "flex",
        flexDirection: "column",
        position: "relative",
      }}
    >
      {/* ── 헤더 ── */}
      <div
        style={{
          background: "#fff",
          borderBottom: "1px solid rgba(0,0,0,0.07)",
          position: "sticky",
          top: 0,
          zIndex: 40,
        }}
      >
        <div style={{ height: 48 }} />
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "0 16px 14px",
          }}
        >
          <button onClick={onBack} style={{ padding: 4 }}>
            <ArrowLeft size={22} color="#1A1A1A" />
          </button>
          <span style={{ fontSize: 16, fontWeight: 700, color: "#1A1A1A" }}>
            주문/배송 조회
          </span>
          <button style={{ padding: 4 }}>
            <ShoppingBag size={22} color="#1A1A1A" />
          </button>
        </div>

        {/* ── 필터 드롭다운 2개 ── */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            borderTop: "1px solid rgba(0,0,0,0.07)",
          }}
        >
          {/* 구매 유형 */}
          <div style={{ flex: 1, position: "relative" }}>
            <button
              onClick={() => { setPurchaseOpen(!purchaseOpen); setStatusOpen(false); }}
              style={{
                width: "100%",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                padding: "13px 16px",
                background: "transparent",
                border: "none",
              }}
            >
              <span style={{ fontSize: 14, color: "#1A1A1A", fontWeight: 500 }}>
                {selectedPurchase}
              </span>
              <ChevronDown
                size={15}
                color="#555"
                style={{
                  transform: purchaseOpen ? "rotate(180deg)" : "rotate(0deg)",
                  transition: "transform 0.2s",
                }}
              />
            </button>
            {purchaseOpen && (
              <div
                style={{
                  position: "absolute",
                  top: "100%",
                  left: 0,
                  width: "100%",
                  background: "#fff",
                  boxShadow: "0 4px 16px rgba(0,0,0,0.12)",
                  borderRadius: "0 0 12px 12px",
                  zIndex: 100,
                  overflow: "hidden",
                }}
              >
                {purchaseTypes.map((opt) => (
                  <button
                    key={opt}
                    onClick={() => { setSelectedPurchase(opt); setPurchaseOpen(false); }}
                    style={{
                      width: "100%",
                      textAlign: "left",
                      padding: "12px 16px",
                      fontSize: 14,
                      color: opt === selectedPurchase ? G_DARK : "#1A1A1A",
                      fontWeight: opt === selectedPurchase ? 700 : 400,
                      borderBottom: "1px solid rgba(0,0,0,0.05)",
                      background: "transparent",
                    }}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* 구분선 */}
          <div style={{ width: 1, height: 20, background: "rgba(0,0,0,0.12)" }} />

          {/* 배송 상태 */}
          <div style={{ flex: 1, position: "relative" }}>
            <button
              onClick={() => { setStatusOpen(!statusOpen); setPurchaseOpen(false); }}
              style={{
                width: "100%",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                padding: "13px 16px",
                background: "transparent",
                border: "none",
              }}
            >
              <span style={{ fontSize: 14, color: "#1A1A1A", fontWeight: 500 }}>
                {selectedStatus}
              </span>
              <ChevronDown
                size={15}
                color="#555"
                style={{
                  transform: statusOpen ? "rotate(180deg)" : "rotate(0deg)",
                  transition: "transform 0.2s",
                }}
              />
            </button>
            {statusOpen && (
              <div
                style={{
                  position: "absolute",
                  top: "100%",
                  right: 0,
                  width: "100%",
                  background: "#fff",
                  boxShadow: "0 4px 16px rgba(0,0,0,0.12)",
                  borderRadius: "0 0 12px 12px",
                  zIndex: 100,
                  overflow: "hidden",
                }}
              >
                {statusTypes.map((opt) => (
                  <button
                    key={opt}
                    onClick={() => { setSelectedStatus(opt); setStatusOpen(false); }}
                    style={{
                      width: "100%",
                      textAlign: "left",
                      padding: "12px 16px",
                      fontSize: 14,
                      color: opt === selectedStatus ? G_DARK : "#1A1A1A",
                      fontWeight: opt === selectedStatus ? 700 : 400,
                      borderBottom: "1px solid rgba(0,0,0,0.05)",
                      background: "transparent",
                    }}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ── 주문 목록 ── */}
      <div
        style={{
          flex: 1,
          overflowY: "auto",
          paddingBottom: 32,
          scrollbarWidth: "none",
        }}
      >
        {orders.map((order) => (
          <div key={order.id} style={{ marginBottom: 8 }}>
            {/* 날짜 + 상세보기 */}
            <div
              style={{
                background: "#fff",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                padding: "14px 16px 10px",
                borderBottom: "1px solid rgba(0,0,0,0.05)",
              }}
            >
              <span style={{ fontSize: 15, fontWeight: 700, color: "#1A1A1A" }}>
                {order.date}
              </span>
              <button
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 2,
                  fontSize: 13,
                  color: "#555",
                }}
              >
                상세보기 <span style={{ fontSize: 13 }}>›</span>
              </button>
            </div>

            {/* 배송 상태 배지 */}
            <div
              style={{
                background: "#fff",
                padding: "10px 16px",
                borderBottom: "1px solid rgba(0,0,0,0.05)",
              }}
            >
              <span
                style={{
                  display: "inline-block",
                  background: order.statusBg,
                  color: order.statusColor,
                  fontSize: 13,
                  fontWeight: 700,
                  padding: "5px 12px",
                  borderRadius: 6,
                }}
              >
                {order.status}
              </span>
            </div>

            {/* 상품 목록 */}
            {order.items.map((item, iIdx) => (
              <div
                key={item.id}
                style={{
                  background: "#fff",
                  borderTop: iIdx > 0 ? "1px solid rgba(0,0,0,0.06)" : "none",
                }}
              >
                {/* 상품 정보 행 */}
                <div
                  style={{
                    display: "flex",
                    gap: 12,
                    padding: "14px 16px",
                  }}
                >
                  {/* 이미지 */}
                  <div
                    style={{
                      width: 80,
                      height: 80,
                      borderRadius: 10,
                      background: item.bg,
                      flexShrink: 0,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontSize: 36,
                      border: "1px solid rgba(0,0,0,0.06)",
                    }}
                  >
                    {item.emoji}
                  </div>

                  {/* 텍스트 */}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p
                      style={{
                        fontSize: 14,
                        fontWeight: 600,
                        color: "#1A1A1A",
                        lineHeight: 1.45,
                        marginBottom: 4,
                      }}
                    >
                      {item.name}
                    </p>
                    <p style={{ fontSize: 12, color: "#999", marginBottom: 2 }}>{item.option}</p>
                    <p style={{ fontSize: 12, color: "#999", marginBottom: 6 }}>
                      수량 : {item.qty}개
                    </p>
                    <p style={{ fontSize: 16, fontWeight: 700, color: "#1A1A1A" }}>
                      {item.price}원
                    </p>
                  </div>
                </div>

                {/* 3버튼 행 */}
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "1fr 1fr 1fr",
                    gap: 6,
                    padding: "0 16px 14px",
                  }}
                >
                  {["재구매", "리뷰 작성", "배송조회"].map((btn) => (
                    <button
                      key={btn}
                      style={{
                        padding: "9px 4px",
                        borderRadius: 8,
                        border: "1px solid rgba(0,0,0,0.14)",
                        background: "#fff",
                        fontSize: 13,
                        fontWeight: 500,
                        color: "#1A1A1A",
                      }}
                    >
                      {btn}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
