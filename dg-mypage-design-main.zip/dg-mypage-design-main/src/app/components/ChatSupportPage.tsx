import React, { useState, useRef, useEffect } from "react";
import { ArrowLeft, RotateCcw, LogOut, Plus, Send } from "lucide-react";
import botCharImg from "../../imports/KakaoTalk_20260625_022210725_13.png";

const G = "#3C7358";

interface Message {
  id: number;
  role: "bot" | "user";
  text?: string;
  isWelcome?: boolean;
  isButtons?: boolean;
}

const quickButtons = [
  ["온라인몰 주문내역 문의", "이벤트"],
  ["온라인몰 주문 전 문의", "결제/영수증"],
  ["쿠폰/포인트/기프트카드", "멤버십/회원정보"],
  ["단종상품 문의", "FAQ/공지사항"],
  ["성분 분석 문의", "대체뭐야머니"],
  ["배송 문의", "취소/교환/반품"],
];

/* ── 챗봇 마스코트 ── */
function BotAvatar() {
  return (
    <div style={{
      width: 40, height: 40, borderRadius: "50%", flexShrink: 0,
      background: "#111",
      overflow: "hidden",
      boxShadow: "0 2px 8px rgba(0,0,0,0.25)",
    }}>
      <img src={botCharImg} alt="대체뭐야 챗봇" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
    </div>
  );
}

interface Props { onBack: () => void; }

export function ChatSupportPage({ onBack }: Props) {
  const [inputText, setInputText] = useState("");
  const [messages, setMessages] = useState<Message[]>([
    { id: 1, role: "bot", isWelcome: true },
    { id: 2, role: "bot", isButtons: true },
  ]);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = () => {
    if (!inputText.trim()) return;
    const userMsg: Message = { id: Date.now(), role: "user", text: inputText };
    const botReply: Message = {
      id: Date.now() + 1, role: "bot",
      text: "안녕하세요! 대체뭐야 챗봇이에요 😊\n말씀하신 내용을 확인 중입니다.\n잠시만 기다려 주세요.",
    };
    setMessages(prev => [...prev, userMsg, botReply]);
    setInputText("");
  };

  const handleQuickBtn = (label: string) => {
    const userMsg: Message = { id: Date.now(), role: "user", text: label };
    const botReply: Message = {
      id: Date.now() + 1, role: "bot",
      text: `'${label}'에 대한 문의를 접수했습니다.\n담당자가 빠르게 확인 후 답변 드릴게요! 🙏`,
    };
    setMessages(prev => [...prev, userMsg, botReply]);
  };

  return (
    <div style={{ height: "100vh", maxWidth: 375, margin: "0 auto", display: "flex", flexDirection: "column", background: "#F4F6F4" }}>

      {/* 헤더 */}
      <div style={{ background: "#fff", borderBottom: "1px solid rgba(0,0,0,0.07)", flexShrink: 0 }}>
        <div style={{ height: 48 }} />
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 16px 14px" }}>
          <button onClick={onBack}><ArrowLeft size={22} color="#1A1A1A" /></button>
          <span style={{ fontSize: 16, fontWeight: 700, color: "#1A1A1A" }}>채팅 상담</span>
          <div style={{ display: "flex", gap: 12 }}>
            <button><RotateCcw size={20} color="#555" /></button>
            <button><LogOut size={20} color="#555" /></button>
          </div>
        </div>
      </div>

      {/* 채팅 영역 */}
      <div style={{ flex: 1, overflowY: "auto", padding: "16px 12px", scrollbarWidth: "none" }}>

        {/* 날짜 필 */}
        <div style={{ display: "flex", justifyContent: "center", marginBottom: 20 }}>
          <span style={{
            fontSize: 12, color: "#888",
            background: "rgba(0,0,0,0.08)",
            padding: "5px 14px", borderRadius: 20,
          }}>2026년 6월 25일</span>
        </div>

        {messages.map(msg => (
          <div key={msg.id}>
            {msg.role === "bot" && (
              <div style={{ display: "flex", gap: 8, marginBottom: 12, alignItems: "flex-start" }}>
                <BotAvatar />
                <div style={{ flex: 1, maxWidth: "80%" }}>
                  <span style={{ fontSize: 11, color: "#888", marginBottom: 4, display: "block" }}>
                    대체뭐야 · 방금 전
                  </span>

                  {msg.isWelcome && (
                    <>
                      {/* 마스코트 일러스트 카드 */}
                      <div style={{
                        background: "#111", borderRadius: "4px 16px 16px 16px",
                        padding: "16px 20px 8px", marginBottom: 8, textAlign: "center",
                        overflow: "hidden",
                      }}>
                        <img
                          src={botCharImg}
                          alt="대체뭐야 챗봇 캐릭터"
                          style={{ width: 100, height: 100, objectFit: "contain" }}
                        />
                      </div>
                      {/* 인사 말풍선 */}
                      <div style={{
                        background: "#fff", borderRadius: "4px 16px 16px 16px",
                        padding: "14px 16px",
                        boxShadow: "0 1px 4px rgba(0,0,0,0.08)",
                        fontSize: 13, color: "#1A1A1A", lineHeight: 1.7,
                      }}>
                        반갑습니다.<br />
                        저는 고객님의 궁금증을 해결해 드릴 대체뭐야 챗봇이에요.<br /><br />
                        ⭐ <strong>대화 TIP</strong><br />
                        ✔ 문장보다 키워드를 더 잘 이해해요.<br />
                        ex) 배송 지연, 단종상품, 교환, 반품 등<br /><br />
                        ✔ 상품명을 잘 이해할 수 없어요. 상품명을 빼고 질문해 주세요.<br />
                        ex) 토너 주문했는데 언제와? → 배송 일정<br /><br />
                        ⭐ 현재 문의량이 많아 상담이 일부 지연될 수 있어요 🙏
                      </div>
                    </>
                  )}

                  {msg.isButtons && (
                    <div style={{
                      background: "#fff", borderRadius: "4px 16px 16px 16px",
                      padding: "12px", marginTop: 4,
                      boxShadow: "0 1px 4px rgba(0,0,0,0.08)",
                    }}>
                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
                        {quickButtons.map(([left, right]) => (
                          <React.Fragment key={left}>
                            <button
                              onClick={() => handleQuickBtn(left)}
                              style={{
                                padding: "10px 8px", borderRadius: 8,
                                border: "1px solid #E0E0E0", background: "#fff",
                                fontSize: 12, color: "#1A1A1A", textAlign: "center",
                                lineHeight: 1.35,
                              }}
                            >{left}</button>
                            <button
                              onClick={() => handleQuickBtn(right)}
                              style={{
                                padding: "10px 8px", borderRadius: 8,
                                border: "1px solid #E0E0E0", background: "#fff",
                                fontSize: 12, color: "#1A1A1A", textAlign: "center",
                                lineHeight: 1.35,
                              }}
                            >{right}</button>
                          </React.Fragment>
                        ))}
                      </div>
                    </div>
                  )}

                  {msg.text && (
                    <div style={{
                      background: "#fff", borderRadius: "4px 16px 16px 16px",
                      padding: "12px 14px",
                      boxShadow: "0 1px 4px rgba(0,0,0,0.08)",
                      fontSize: 13, color: "#1A1A1A", lineHeight: 1.6,
                      whiteSpace: "pre-line",
                    }}>{msg.text}</div>
                  )}
                </div>
              </div>
            )}

            {msg.role === "user" && msg.text && (
              <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 12 }}>
                <div style={{
                  background: G, borderRadius: "16px 4px 16px 16px",
                  padding: "11px 14px", maxWidth: "72%",
                  fontSize: 13, color: "#fff", lineHeight: 1.5,
                  whiteSpace: "pre-line",
                }}>{msg.text}</div>
              </div>
            )}
          </div>
        ))}

        <div ref={bottomRef} />
      </div>

      {/* 입력창 */}
      <div style={{
        background: "#fff", borderTop: "1px solid rgba(0,0,0,0.08)",
        padding: "10px 12px",
        display: "flex", alignItems: "center", gap: 8,
        flexShrink: 0,
        paddingBottom: "calc(10px + env(safe-area-inset-bottom, 0px))",
      }}>
        <button style={{
          width: 34, height: 34, borderRadius: "50%",
          border: "1.5px solid #D0D0D0", background: "#fff",
          display: "flex", alignItems: "center", justifyContent: "center",
          flexShrink: 0,
        }}>
          <Plus size={18} color="#555" />
        </button>
        <input
          value={inputText}
          onChange={e => setInputText(e.target.value)}
          onKeyDown={e => e.key === "Enter" && sendMessage()}
          placeholder="버튼을 선택하거나 메시지를 입력하세요"
          style={{
            flex: 1, border: "1px solid #E0E0E0", borderRadius: 20,
            padding: "10px 14px", fontSize: 13, color: "#1A1A1A",
            background: "#FAFAFA", outline: "none",
          }}
        />
        <button
          onClick={sendMessage}
          style={{
            width: 34, height: 34, borderRadius: "50%",
            background: inputText.trim() ? G : "#E0E0E0",
            border: "none",
            display: "flex", alignItems: "center", justifyContent: "center",
            flexShrink: 0, transition: "background 0.2s",
          }}
        >
          <Send size={16} color="#fff" />
        </button>
      </div>
    </div>
  );
}
