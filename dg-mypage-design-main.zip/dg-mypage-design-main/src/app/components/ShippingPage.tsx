import React, { useState } from "react";
import { ArrowLeft, ShoppingBag, Plus, Pencil, Trash2, ChevronRight, Building2 } from "lucide-react";

const G = "#3C7358";

type PageTab = "배송지" | "환불계좌";

interface Address {
  id: number;
  label: string;
  isDefault: boolean;
  isSameDay: boolean;
  zipCode: string;
  roadAddr: string;
  jibunAddr: string;
  phone: string;
  entrance: string;
  entranceDetail: string;
}

const initialAddresses: Address[] = [
  {
    id: 1,
    label: "집",
    isDefault: true,
    isSameDay: true,
    zipCode: "06292",
    roadAddr: "서울 강남구 언주로 508 (역삼동, 역삼하이츠) ****",
    jibunAddr: "서울 강남구 역삼동 823 ****",
    phone: "010-****-7742",
    entrance: "공동현관 출입방법",
    entranceDetail: "비밀번호 (열*2*7*열*)",
  },
  {
    id: 2,
    label: "회사",
    isDefault: false,
    isSameDay: false,
    zipCode: "06235",
    roadAddr: "서울 강남구 테헤란로 152 (역삼동, 강남파이낸스센터) ****",
    jibunAddr: "서울 강남구 역삼동 737 ****",
    phone: "010-****-1234",
    entrance: "공동현관 출입방법",
    entranceDetail: "카드키",
  },
];

const bankAccounts = [
  {
    id: 1,
    bank: "카카오뱅크",
    emoji: "🏦",
    accountNum: "333-****-****-31",
    holder: "김지연",
    isDefault: true,
  },
];

interface Props { onBack: () => void; }

export function ShippingPage({ onBack }: Props) {
  const [tab, setTab]           = useState<PageTab>("배송지");
  const [addresses, setAddresses] = useState<Address[]>(initialAddresses);

  const setDefault = (id: number) => {
    setAddresses(prev => prev.map(a => ({ ...a, isDefault: a.id === id })));
  };

  const deleteAddress = (id: number) => {
    setAddresses(prev => prev.filter(a => a.id !== id));
  };

  return (
    <div style={{
      minHeight: "100vh", background: "#F4F6F4",
      maxWidth: 375, margin: "0 auto",
      display: "flex", flexDirection: "column",
    }}>

      {/* ── 헤더 ── */}
      <div style={{
        position: "sticky", top: 0, background: "#fff",
        zIndex: 40, borderBottom: "1px solid rgba(0,0,0,0.07)",
      }}>
        <div style={{ height: 48 }} />
        <div style={{
          display: "flex", alignItems: "center", justifyContent: "space-between",
          padding: "0 16px 0",
        }}>
          <button onClick={onBack}><ArrowLeft size={22} color="#1A1A1A" /></button>
          <span style={{ fontSize: 16, fontWeight: 700, color: "#1A1A1A" }}>
            배송지/환불계좌 관리
          </span>
          <button><ShoppingBag size={22} color="#1A1A1A" /></button>
        </div>

        {/* 탭 */}
        <div style={{ display: "flex", marginTop: 2 }}>
          {(["배송지", "환불계좌"] as PageTab[]).map(t => (
            <div key={t} style={{ flex: 1, position: "relative" }}>
              <button
                onClick={() => setTab(t)}
                style={{
                  width: "100%", padding: "14px 0",
                  fontSize: 15, fontWeight: 700,
                  color: tab === t ? "#1A1A1A" : "#BBBBBB",
                  background: "transparent", border: "none",
                }}
              >{t}</button>
              {tab === t && (
                <div style={{
                  position: "absolute", bottom: 0,
                  left: 0, right: 0, height: 2, background: "#1A1A1A",
                }} />
              )}
            </div>
          ))}
        </div>
        <div style={{ height: 1, background: "#EBEBEB" }} />
      </div>

      {/* ── 스크롤 바디 ── */}
      <div style={{ flex: 1, overflowY: "auto", scrollbarWidth: "none", padding: "16px 16px 32px" }}>

        {tab === "배송지" && (
          <>
            {/* 주소 카드 목록 */}
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {addresses.map(addr => (
                <div
                  key={addr.id}
                  style={{
                    background: "#fff",
                    borderRadius: 14,
                    border: addr.isDefault ? `1.5px solid ${G}` : "1.5px solid #E0E0E0",
                    padding: "16px",
                  }}
                >
                  {/* 상단: 라벨 + 배지 + 수정버튼 */}
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                      <span style={{ fontSize: 17, fontWeight: 800, color: "#1A1A1A" }}>
                        {addr.label}
                      </span>
                      {addr.isDefault && (
                        <span style={{
                          fontSize: 11, fontWeight: 700,
                          background: G, color: "#fff",
                          padding: "3px 9px", borderRadius: 20,
                        }}>기본 배송지</span>
                      )}
                      {addr.isSameDay && (
                        <span style={{
                          fontSize: 11, fontWeight: 700,
                          color: "#E8527A",
                          display: "flex", alignItems: "center", gap: 2,
                        }}>
                          🏍 오늘드림
                        </span>
                      )}
                    </div>
                    <button style={{
                      padding: "5px 12px", borderRadius: 8,
                      border: "1px solid #D0D0D0", background: "#fff",
                      fontSize: 12, fontWeight: 600, color: "#555",
                      display: "flex", alignItems: "center", gap: 4,
                    }}>
                      <Pencil size={11} color="#777" />
                      수정
                    </button>
                  </div>

                  {/* 주소 정보 */}
                  <p style={{ fontSize: 12, color: "#888", marginBottom: 4 }}>({addr.zipCode})</p>
                  <p style={{ fontSize: 13, color: "#1A1A1A", lineHeight: 1.5, marginBottom: 2 }}>
                    도로명 : {addr.roadAddr}
                  </p>
                  <p style={{ fontSize: 12, color: "#999", marginBottom: 10 }}>
                    지번 : {addr.jibunAddr}
                  </p>
                  <p style={{ fontSize: 13, fontWeight: 600, color: "#1A1A1A", marginBottom: 12 }}>
                    {addr.phone}
                  </p>

                  {/* 점선 구분선 */}
                  <div style={{
                    borderTop: "1px dashed #D8D8D8",
                    marginBottom: 12,
                  }} />

                  {/* 공동현관 */}
                  <p style={{ fontSize: 13, fontWeight: 700, color: "#1A1A1A", marginBottom: 3 }}>
                    {addr.entrance}
                  </p>
                  <p style={{ fontSize: 13, color: "#666" }}>{addr.entranceDetail}</p>

                  {/* 하단 버튼 행 */}
                  {!addr.isDefault && (
                    <div style={{
                      display: "flex", gap: 8, marginTop: 14,
                      borderTop: "1px solid #F0F0F0", paddingTop: 12,
                    }}>
                      <button
                        onClick={() => setDefault(addr.id)}
                        style={{
                          flex: 1, padding: "9px 0", borderRadius: 8,
                          border: `1.5px solid ${G}`, background: "#fff",
                          fontSize: 12, fontWeight: 700, color: G,
                        }}
                      >기본 배송지로 설정</button>
                      <button
                        onClick={() => deleteAddress(addr.id)}
                        style={{
                          padding: "9px 14px", borderRadius: 8,
                          border: "1px solid #E0E0E0", background: "#fff",
                          fontSize: 12, fontWeight: 600, color: "#999",
                          display: "flex", alignItems: "center", gap: 4,
                        }}
                      >
                        <Trash2 size={13} color="#bbb" />
                        삭제
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* 배송지 추가 버튼 */}
            <button style={{
              width: "100%", marginTop: 12,
              padding: "18px 0", borderRadius: 14,
              border: "1.5px solid #D8D8D8", background: "#fff",
              display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
              fontSize: 15, fontWeight: 700, color: G,
            }}>
              <Plus size={18} color={G} strokeWidth={2.5} />
              배송지 추가
            </button>

            {/* 안내 문구 */}
            <p style={{ fontSize: 12, color: "#999", marginTop: 14, paddingLeft: 4 }}>
              · 배송지는 최대 20개까지 등록 가능합니다.
            </p>
          </>
        )}

        {tab === "환불계좌" && (
          <>
            <p style={{ fontSize: 13, color: "#888", marginBottom: 14 }}>
              환불 시 사용할 계좌를 등록해주세요.
            </p>

            {bankAccounts.map(acc => (
              <div
                key={acc.id}
                style={{
                  background: "#fff", borderRadius: 14,
                  border: `1.5px solid ${G}`,
                  padding: "16px", marginBottom: 12,
                }}
              >
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <div style={{
                      width: 36, height: 36, borderRadius: 10,
                      background: "#FFF0C8",
                      display: "flex", alignItems: "center", justifyContent: "center",
                      fontSize: 20,
                    }}>{acc.emoji}</div>
                    <div>
                      <p style={{ fontSize: 14, fontWeight: 700, color: "#1A1A1A" }}>{acc.bank}</p>
                      <p style={{ fontSize: 12, color: "#888" }}>예금주: {acc.holder}</p>
                    </div>
                  </div>
                  {acc.isDefault && (
                    <span style={{
                      fontSize: 11, fontWeight: 700,
                      background: G, color: "#fff",
                      padding: "3px 9px", borderRadius: 20,
                    }}>기본 계좌</span>
                  )}
                </div>
                <p style={{ fontSize: 15, fontWeight: 700, color: "#1A1A1A", marginBottom: 10 }}>
                  {acc.accountNum}
                </p>
                <button style={{
                  width: "100%", padding: "9px 0", borderRadius: 8,
                  border: "1px solid #D0D0D0", background: "#fff",
                  fontSize: 13, fontWeight: 600, color: "#555",
                }}>수정</button>
              </div>
            ))}

            <button style={{
              width: "100%", marginTop: 4,
              padding: "18px 0", borderRadius: 14,
              border: "1.5px solid #D8D8D8", background: "#fff",
              display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
              fontSize: 15, fontWeight: 700, color: G,
            }}>
              <Plus size={18} color={G} strokeWidth={2.5} />
              계좌 추가
            </button>

            <p style={{ fontSize: 12, color: "#999", marginTop: 14, paddingLeft: 4 }}>
              · 환불계좌는 최대 5개까지 등록 가능합니다.
            </p>
          </>
        )}
      </div>
    </div>
  );
}
