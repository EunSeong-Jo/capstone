import React from "react";
import { ArrowLeft, Home, Settings, Info, ChevronRight, Share2 } from "lucide-react";

const G = "#3C7358";
const BLUE = "#1A6EE8";

const recentHistory = [
  {
    id: 1,
    icon: "🛍",
    iconBg: "#1A1A1A",
    iconColor: "#fff",
    title: "세라마이드 크림 외 2개",
    sub: "사용 · 06.05 14:22",
    amount: -68400,
    type: "사용",
  },
  {
    id: 2,
    icon: "🏦",
    iconBg: "#E8F4FF",
    iconColor: G,
    title: "카카오뱅크 (*239)",
    sub: "충전 · 06.01 10:00",
    amount: +80000,
    type: "충전",
  },
  {
    id: 3,
    icon: "🛍",
    iconBg: "#1A1A1A",
    iconColor: "#fff",
    title: "이니스프리 토너 200ml",
    sub: "사용 · 05.28 19:30",
    amount: -28000,
    type: "사용",
  },
  {
    id: 4,
    icon: "🏦",
    iconBg: "#E8F4FF",
    iconColor: G,
    title: "토스뱅크 (*614)",
    sub: "충전 · 05.20 09:15",
    amount: +50000,
    type: "충전",
  },
];

interface Props { onBack: () => void; }

export function MoneyPage({ onBack }: Props) {
  return (
    <div style={{ minHeight: "100vh", background: "#fff", maxWidth: 375, margin: "0 auto", display: "flex", flexDirection: "column" }}>

      {/* 헤더 */}
      <div style={{ position: "sticky", top: 0, background: "#fff", zIndex: 40, borderBottom: "1px solid rgba(0,0,0,0.07)" }}>
        <div style={{ height: 48 }} />
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 16px 14px" }}>
          <button onClick={onBack}><ArrowLeft size={22} color="#1A1A1A" /></button>
          <span style={{ fontSize: 16, fontWeight: 700, color: "#1A1A1A" }}>대체뭐야머니</span>
          <div style={{ display: "flex", gap: 8 }}>
            <button><Settings size={20} color="#1A1A1A" /></button>
            <button><Home size={22} color="#1A1A1A" /></button>
          </div>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: "auto", scrollbarWidth: "none" }}>

        {/* 머니 배너 */}
        <div style={{ padding: "20px 20px 0" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 12 }}>
            <div style={{
              width: 28, height: 28, borderRadius: 8,
              background: G,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 14, color: "#fff", fontWeight: 800,
            }}>M</div>
            <span style={{ fontSize: 13, color: "#555" }}>
              <strong style={{ color: G }}>Money</strong> 결제할 땐 자동 충전! 인출도 자유롭게!
            </span>
          </div>

          {/* 잔액 */}
          <p style={{ fontSize: 32, fontWeight: 800, color: "#1A1A1A", marginBottom: 12 }}>3,450원</p>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
            <span style={{ fontSize: 13, color: "#888" }}>충전 금액</span>
            <span style={{ fontSize: 13, color: "#1A1A1A", fontWeight: 500 }}>3,450원</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
              <span style={{ fontSize: 13, color: "#888" }}>포인트 (인출 제한)</span>
              <Info size={13} color="#bbb" />
            </div>
            <span style={{ fontSize: 13, color: "#1A1A1A", fontWeight: 500 }}>0원</span>
          </div>

          {/* 버튼 2개 */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 20 }}>
            <button style={{
              padding: "14px 0", borderRadius: 10,
              border: "1.5px solid #1A1A1A",
              background: "#fff",
              fontSize: 14, fontWeight: 700, color: "#1A1A1A",
            }}>머니 인출</button>
            <button style={{
              padding: "14px 0", borderRadius: 10,
              border: "none",
              background: "#1A1A1A",
              fontSize: 14, fontWeight: 700, color: "#fff",
            }}>계좌 충전</button>
          </div>
        </div>

        <div style={{ height: 1, background: "#F0F0F0" }} />

        {/* 최근 이용 내역 */}
        <div style={{ padding: "20px 20px 0" }}>
          <p style={{ fontSize: 16, fontWeight: 700, color: "#1A1A1A", marginBottom: 16 }}>최근 이용 내역</p>
          {recentHistory.map((item, idx) => (
            <div
              key={item.id}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 12,
                paddingBottom: 18,
                marginBottom: idx < recentHistory.length - 1 ? 18 : 0,
                borderBottom: idx < recentHistory.length - 1 ? "1px solid #F2F2F2" : "none",
              }}
            >
              {/* 아이콘 원 */}
              <div style={{
                width: 42, height: 42, borderRadius: "50%", flexShrink: 0,
                background: item.iconBg,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 20,
              }}>
                {item.icon}
              </div>
              <div style={{ flex: 1 }}>
                <p style={{ fontSize: 14, fontWeight: 500, color: "#1A1A1A", marginBottom: 2 }}>{item.title}</p>
                <p style={{ fontSize: 12, color: "#aaa" }}>{item.sub}</p>
              </div>
              <span style={{
                fontSize: 14, fontWeight: 700,
                color: item.amount > 0 ? BLUE : "#1A1A1A",
                flexShrink: 0,
              }}>
                {item.amount > 0
                  ? `+${item.amount.toLocaleString()}원`
                  : `-${Math.abs(item.amount).toLocaleString()}원`}
              </span>
            </div>
          ))}
        </div>

        <div style={{ height: 40 }} />
      </div>
    </div>
  );
}
