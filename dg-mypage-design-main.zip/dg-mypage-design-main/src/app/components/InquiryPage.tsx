import React, { useState } from "react";
import { ArrowLeft, ShoppingBag, ChevronDown, ChevronRight, Phone, MessageCircle, HelpCircle, Headphones } from "lucide-react";

const G = "#3C7358";

type InquiryTab = "문의하기" | "문의내역";

const inquiryTypes = [
  { emoji: "📦", label: "배송 문의" },
  { emoji: "↩️",  label: "취소/교환/환불" },
  { emoji: "🌿", label: "성분 문의" },
  { emoji: "💊", label: "단종상품 문의" },
  { emoji: "💳", label: "결제/적립금" },
  { emoji: "👤", label: "회원정보" },
  { emoji: "🤖", label: "AI 추천 문의" },
  { emoji: "💬", label: "기타" },
];

const periodOptions = ["1개월간 문의내역", "3개월간 문의내역", "6개월간 문의내역", "1년간 문의내역"];

const historyItems = [
  {
    id: 1,
    type: "배송 문의",
    title: "이니스프리 토너 배송이 너무 늦어요",
    date: "2026.05.28",
    status: "답변완료",
    statusColor: G,
    answer: "안녕하세요, 대체뭐야 고객센터입니다. 배송 지연에 불편을 드려 죄송합니다. 확인 결과 택배사 사정으로 1-2일 지연되었으며, 2026.05.30에 도착 예정입니다.",
  },
  {
    id: 2,
    type: "성분 문의",
    title: "이 성분이 민감성 피부에 맞나요?",
    date: "2026.06.10",
    status: "답변대기",
    statusColor: "#E8922A",
    answer: null,
  },
];

interface Props { onBack: () => void; }

export function InquiryPage({ onBack }: Props) {
  const [tab, setTab] = useState<InquiryTab>("문의하기");
  const [period, setPeriod] = useState(periodOptions[0]);
  const [periodOpen, setPeriodOpen] = useState(false);
  const [expandedId, setExpandedId] = useState<number | null>(null);

  // 문의하기 폼 상태
  const [selectedType, setSelectedType] = useState<string | null>(null);
  const [inquiryText, setInquiryText] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = () => {
    if (!selectedType || !inquiryText.trim()) return;
    setSubmitted(true);
    setTimeout(() => {
      setTab("문의내역");
      setSubmitted(false);
      setSelectedType(null);
      setInquiryText("");
    }, 1500);
  };

  return (
    <div style={{ minHeight: "100vh", background: "#fff", maxWidth: 375, margin: "0 auto", display: "flex", flexDirection: "column" }}>

      {/* 헤더 */}
      <div style={{ position: "sticky", top: 0, background: "#fff", zIndex: 40, borderBottom: "1px solid rgba(0,0,0,0.07)" }}>
        <div style={{ height: 48 }} />
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 16px 0" }}>
          <button onClick={onBack}><ArrowLeft size={22} color="#1A1A1A" /></button>
          <span style={{ fontSize: 16, fontWeight: 700, color: "#1A1A1A" }}>1:1 문의</span>
          <button><ShoppingBag size={22} color="#1A1A1A" /></button>
        </div>

        {/* 탭 */}
        <div style={{ display: "flex", marginTop: 2 }}>
          {(["문의하기", "문의내역"] as InquiryTab[]).map(t => (
            <div key={t} style={{ flex: 1, position: "relative" }}>
              <button
                onClick={() => setTab(t)}
                style={{
                  width: "100%", padding: "14px 0",
                  fontSize: 15, fontWeight: 700,
                  color: tab === t ? "#1A1A1A" : "#BBBBBB",
                  background: "transparent", border: "none",
                }}
              >{t}</button>
              {tab === t && (
                <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: 2, background: "#1A1A1A" }} />
              )}
            </div>
          ))}
        </div>
        <div style={{ height: 1, background: "#EBEBEB" }} />
      </div>

      {/* ── 문의하기 탭 ── */}
      {tab === "문의하기" && (
        <div style={{ flex: 1, overflowY: "auto", scrollbarWidth: "none", padding: "20px 16px 120px" }}>

          {submitted ? (
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "80px 0", gap: 12 }}>
              <span style={{ fontSize: 48 }}>✅</span>
              <p style={{ fontSize: 16, fontWeight: 700, color: "#1A1A1A" }}>문의가 접수되었습니다!</p>
              <p style={{ fontSize: 13, color: "#888" }}>빠르게 답변 드릴게요.</p>
            </div>
          ) : (
            <>
              <p style={{ fontSize: 15, fontWeight: 700, color: "#1A1A1A", marginBottom: 14 }}>문의 유형 선택</p>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 24 }}>
                {inquiryTypes.map(t => (
                  <button
                    key={t.label}
                    onClick={() => setSelectedType(t.label)}
                    style={{
                      padding: "14px 8px", borderRadius: 12,
                      border: selectedType === t.label ? `2px solid ${G}` : "1.5px solid #E0E0E0",
                      background: selectedType === t.label ? "#EAF5EE" : "#fff",
                      display: "flex", alignItems: "center", gap: 8,
                    }}
                  >
                    <span style={{ fontSize: 20 }}>{t.emoji}</span>
                    <span style={{ fontSize: 13, fontWeight: selectedType === t.label ? 700 : 500, color: selectedType === t.label ? G : "#555" }}>
                      {t.label}
                    </span>
                  </button>
                ))}
              </div>

              <p style={{ fontSize: 15, fontWeight: 700, color: "#1A1A1A", marginBottom: 10 }}>문의 내용</p>
              <textarea
                value={inquiryText}
                onChange={e => setInquiryText(e.target.value)}
                placeholder="문의하실 내용을 자세히 작성해 주세요.&#10;(최소 10자 이상)"
                style={{
                  width: "100%", height: 140, padding: "14px", borderRadius: 12,
                  border: "1.5px solid #E0E0E0", fontSize: 13, color: "#1A1A1A",
                  lineHeight: 1.6, resize: "none", outline: "none", boxSizing: "border-box",
                  background: "#FAFAFA",
                }}
              />
              <p style={{ fontSize: 11, color: "#AAAAAA", textAlign: "right", marginTop: 4, marginBottom: 20 }}>
                {inquiryText.length} / 1000
              </p>

              <button
                onClick={handleSubmit}
                style={{
                  width: "100%", padding: "16px 0", borderRadius: 12,
                  background: selectedType && inquiryText.length >= 10 ? G : "#E0E0E0",
                  border: "none", fontSize: 15, fontWeight: 700, color: "#fff",
                  transition: "background 0.2s",
                }}
              >문의 접수하기</button>

              <p style={{ fontSize: 12, color: "#AAAAAA", textAlign: "center", marginTop: 12 }}>
                · 평일 09:00 ~ 18:00 내 순차적으로 답변 드립니다.
              </p>
            </>
          )}
        </div>
      )}

      {/* ── 문의내역 탭 ── */}
      {tab === "문의내역" && (
        <div style={{ flex: 1, display: "flex", flexDirection: "column", scrollbarWidth: "none" }}>
          <div style={{ padding: "16px 16px 0", position: "relative" }}>
            <button
              onClick={() => setPeriodOpen(!periodOpen)}
              style={{
                width: "100%", padding: "13px 16px", borderRadius: 8,
                border: "1.5px solid #CCCCCC", background: "#fff",
                display: "flex", alignItems: "center", justifyContent: "space-between",
                fontSize: 14, color: "#1A1A1A",
              }}
            >
              {period}
              <ChevronDown size={16} color="#555" style={{ transform: periodOpen ? "rotate(180deg)" : "none", transition: "transform 0.2s" }} />
            </button>

            {periodOpen && (
              <div style={{
                position: "absolute", top: "100%", left: 16, right: 16,
                background: "#fff", borderRadius: 10,
                boxShadow: "0 4px 16px rgba(0,0,0,0.12)", zIndex: 100, overflow: "hidden",
              }}>
                {periodOptions.map(opt => (
                  <button key={opt} onClick={() => { setPeriod(opt); setPeriodOpen(false); }} style={{
                    display: "block", width: "100%", textAlign: "left",
                    padding: "12px 16px", fontSize: 14,
                    color: opt === period ? G : "#1A1A1A",
                    fontWeight: opt === period ? 700 : 400,
                    borderBottom: "1px solid rgba(0,0,0,0.05)", background: "transparent",
                  }}>{opt}</button>
                ))}
              </div>
            )}

            <p style={{ fontSize: 12, color: "#AAAAAA", marginTop: 8, paddingLeft: 2 }}>
              · 1년 이전 내역은 PC버전에서 확인해주세요.
            </p>
          </div>

          <div style={{ height: 1, background: "#F0F0F0", margin: "12px 0 0" }} />

          {/* 내역 목록 */}
          <div style={{ flex: 1, overflowY: "auto", scrollbarWidth: "none", minHeight: "calc(100vh - 340px)" }}>
            {historyItems.length === 0 ? (
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "80px 0", gap: 12 }}>
                <div style={{ width: 64, height: 64, borderRadius: "50%", border: "2px solid #D0D0D0", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <span style={{ fontSize: 28, color: "#C0C0C0", fontWeight: 700 }}>!</span>
                </div>
                <p style={{ fontSize: 14, color: "#AAAAAA" }}>문의내역이 없습니다.</p>
              </div>
            ) : (
              historyItems.map(item => (
                <div key={item.id}>
                  <button
                    onClick={() => setExpandedId(expandedId === item.id ? null : item.id)}
                    style={{ width: "100%", textAlign: "left", padding: "16px", borderBottom: "1px solid #F2F2F2", background: "#fff" }}
                  >
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 6 }}>
                      <span style={{ fontSize: 11, padding: "2px 8px", borderRadius: 4, background: "#F0F0F0", color: "#666", fontWeight: 600 }}>
                        {item.type}
                      </span>
                      <span style={{ fontSize: 12, fontWeight: 700, color: item.statusColor }}>{item.status}</span>
                    </div>
                    <p style={{ fontSize: 14, fontWeight: 600, color: "#1A1A1A", marginBottom: 4, lineHeight: 1.4 }}>{item.title}</p>
                    <p style={{ fontSize: 12, color: "#AAAAAA" }}>{item.date}</p>
                  </button>

                  {expandedId === item.id && item.answer && (
                    <div style={{ padding: "14px 16px", background: "#F8FAF9", borderBottom: "1px solid #F0F0F0" }}>
                      <p style={{ fontSize: 12, fontWeight: 700, color: G, marginBottom: 8 }}>💬 답변</p>
                      <p style={{ fontSize: 13, color: "#444", lineHeight: 1.6 }}>{item.answer}</p>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* 하단 문의 바 */}
      <div style={{ borderTop: "1px solid rgba(0,0,0,0.07)", background: "#fff" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", padding: "14px 0", paddingBottom: "calc(14px + env(safe-area-inset-bottom, 0px))" }}>
          {[
            { Icon: Phone,         label: "대표전화" },
            { Icon: MessageCircle, label: "채팅 상담" },
            { Icon: HelpCircle,    label: "1:1문의"   },
            { Icon: Headphones,    label: "고객센터"  },
          ].map(({ Icon, label }, idx, arr) => (
            <React.Fragment key={label}>
              <button style={{ display: "flex", alignItems: "center", gap: 4, padding: "6px 10px" }}>
                <Icon size={13} color="#888" strokeWidth={1.8} />
                <span style={{ fontSize: 12, color: "#666", fontWeight: 500 }}>{label}</span>
              </button>
              {idx < arr.length - 1 && <span style={{ color: "#D8D8D8", fontSize: 12 }}>|</span>}
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
}
