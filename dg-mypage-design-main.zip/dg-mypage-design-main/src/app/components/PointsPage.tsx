import React, { useState } from "react";
import { ArrowLeft, Home, Info } from "lucide-react";

const G = "#3C7358";
const BLUE = "#1A6EE8";

type HistoryTab = "전체" | "적립" | "사용" | "예정";

const historyData = [
  { id: 1, title: "유효기간 만료", sub: "소멸 · 2026.06.19", amount: -1000, type: "사용" as HistoryTab },
  { id: 2, title: "유효기간 만료", sub: "소멸 · 2026.06.14", amount: -500,  type: "사용" as HistoryTab },
  { id: 3, title: "도착지연으로 인한 적립금 보상", sub2: "수분 밸런싱 토너 200ml", sub: "적립 · 2026.05.20 (2026.06.18 소멸 예정)", amount: +1000, type: "적립" as HistoryTab },
  { id: 4, title: "도착지연으로 인한 적립금 보상", sub2: "히알루론산 에센스 50ml", sub: "적립 · 2026.05.20 (2026.06.18 소멸 예정)", amount: +1000, type: "적립" as HistoryTab },
  { id: 5, title: "주문 적립", sub2: "세라마이드 수분 크림 60ml", sub: "적립 · 2026.05.28 (2031.05.27 소멸 예정)", amount: +290, type: "적립" as HistoryTab },
  { id: 6, title: "주문 적립", sub2: "나이아신아마이드 세럼 30ml", sub: "적립 · 2026.05.30 (2031.05.29 소멸 예정)", amount: +240, type: "적립" as HistoryTab },
  { id: 7, title: "리뷰 작성 적립", sub2: "닥터자르트 세라마이드 크림", sub: "적립 · 2026.04.10 (2031.04.09 소멸 예정)", amount: +500, type: "적립" as HistoryTab },
  { id: 8, title: "주문 결제 사용", sub2: "이니스프리 토너 주문", sub: "사용 · 2026.03.22", amount: -2000, type: "사용" as HistoryTab },
  { id: 9, title: "신규 가입 적립", sub: "적립 · 2026.01.01 (2031.12.31 소멸 예정)", amount: +2000, type: "적립" as HistoryTab },
  { id: 10, title: "재진단 완료 적립", sub: "예정 · 지급 예정일 2026.07.01", amount: +300, type: "예정" as HistoryTab },
];

const TABS: HistoryTab[] = ["전체", "적립", "사용", "예정"];

interface Props { onBack: () => void; }

export function PointsPage({ onBack }: Props) {
  const [tab, setTab] = useState<HistoryTab>("전체");

  const filtered = tab === "전체" ? historyData : historyData.filter(h => h.type === tab);

  return (
    <div style={{ minHeight: "100vh", background: "#fff", maxWidth: 375, margin: "0 auto", display: "flex", flexDirection: "column" }}>

      {/* 헤더 */}
      <div style={{ position: "sticky", top: 0, background: "#fff", zIndex: 40, borderBottom: "1px solid rgba(0,0,0,0.07)" }}>
        <div style={{ height: 48 }} />
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 16px 14px" }}>
          <button onClick={onBack}><ArrowLeft size={22} color="#1A1A1A" /></button>
          <span style={{ fontSize: 16, fontWeight: 700, color: "#1A1A1A" }}>적립금</span>
          <button><Home size={22} color="#1A1A1A" /></button>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: "auto", scrollbarWidth: "none" }}>

        {/* 현재 적립금 */}
        <div style={{ padding: "24px 20px 20px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 4, marginBottom: 8 }}>
            <span style={{ fontSize: 13, color: "#555" }}>현재 적립금</span>
            <Info size={13} color="#aaa" />
          </div>
          <p style={{ fontSize: 32, fontWeight: 800, color: "#1A1A1A", marginBottom: 16 }}>2,885원</p>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
            <span style={{ fontSize: 13, color: "#888" }}>예정 적립금</span>
            <span style={{ fontSize: 13, color: "#888" }}>0원</span>
          </div>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <span style={{ fontSize: 13, color: "#888" }}>소멸 예정 적립금(30일 이내)</span>
            <span style={{ fontSize: 13, color: "#888" }}>0원</span>
          </div>
        </div>

        <div style={{ height: 1, background: "#F0F0F0" }} />

        {/* 탭 */}
        <div style={{ display: "flex", borderBottom: "1px solid #EBEBEB", background: "#fff", position: "relative" }}>
          {TABS.map(t => (
            <div key={t} style={{ width: "25%", position: "relative" }}>
              <button
                onClick={() => setTab(t)}
                style={{
                  width: "100%",
                  padding: "13px 0",
                  fontSize: 14,
                  fontWeight: 700,
                  color: t === tab ? "#1A1A1A" : "#BBBBBB",
                  background: "transparent",
                  border: "none",
                  textAlign: "center",
                  display: "block",
                }}
              >{t}</button>
              {t === tab && (
                <div style={{
                  position: "absolute",
                  bottom: -1,
                  left: 0,
                  right: 0,
                  height: 2,
                  background: "#1A1A1A",
                }} />
              )}
            </div>
          ))}
        </div>

        {/* 내역 리스트 */}
        <div style={{ minHeight: "calc(100vh - 260px)" }}>
          {filtered.map((item, idx) => (
            <div
              key={item.id}
              style={{
                display: "flex",
                alignItems: "flex-start",
                justifyContent: "space-between",
                padding: "18px 20px",
                borderBottom: idx < filtered.length - 1 ? "1px solid #F2F2F2" : "none",
              }}
            >
              <div style={{ flex: 1, paddingRight: 12 }}>
                <p style={{ fontSize: 14, fontWeight: 600, color: "#1A1A1A", marginBottom: 3 }}>{item.title}</p>
                {item.sub2 && <p style={{ fontSize: 12, color: "#888", marginBottom: 2 }}>{item.sub2}</p>}
                <p style={{ fontSize: 12, color: "#aaa" }}>{item.sub}</p>
              </div>
              <span style={{
                fontSize: 14, fontWeight: 700, flexShrink: 0,
                color: item.amount > 0 ? BLUE : "#888",
              }}>
                {item.amount > 0 ? `+${item.amount.toLocaleString()}원` : `${item.amount.toLocaleString()}원`}
              </span>
            </div>
          ))}
        </div>

        <div style={{ height: 32 }} />
      </div>
    </div>
  );
}
