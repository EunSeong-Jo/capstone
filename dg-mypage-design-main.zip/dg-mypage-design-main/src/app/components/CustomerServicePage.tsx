import React, { useState } from "react";
import { ArrowLeft, Search, ChevronRight, Phone, MessageCircle, HelpCircle, Headphones } from "lucide-react";
import faqCharImg from "../../imports/KakaoTalk_20260625_022210725_09.png";

const G = "#3C7358";

const categories = [
  { label: "회원/멤버십",     emoji: "👤" },
  { label: "주문/결제",       emoji: "💳" },
  { label: "배송문의",        emoji: "🚚" },
  { label: "취소/교환/환불",  emoji: "↩️"  },
  { label: "이벤트",          emoji: "🎉" },
  { label: "사이트이용\n오류/개선", emoji: "⚙️" },
];

const keywords = ["#성분분석", "#단종상품", "#대체제추천", "#배송", "#교환", "#반품", "#적립금", "#쿠폰"];

const notices = [
  { id: 1, tag: "이벤트", date: "2026.06.24", title: "[대체뭐야 이벤트] 6월 베스트 성분 챌린지 당첨자 발표" },
  { id: 2, tag: "이벤트", date: "2026.06.24", title: "[대체뭐야 라이브] 6/16 이니스프리 방송참여 이벤트 당첨자 발표" },
  { id: 3, tag: "일반",   date: "2026.06.23", title: "6월 대체뭐야 세일 댓글 이벤트 당첨자 발표 지연 안내" },
  { id: 4, tag: "일반",   date: "2026.06.22", title: "AI 성분 분석 서비스 업데이트 안내" },
  { id: 5, tag: "일반",   date: "2026.06.20", title: "개인정보 처리방침 변경 안내" },
];

interface Props {
  onBack: () => void;
  onChatSupport: () => void;
  onInquiry: () => void;
}

export function CustomerServicePage({ onBack, onChatSupport, onInquiry }: Props) {
  const [searchText, setSearchText] = useState("");
  const [selectedType, setSelectedType] = useState("온라인몰");

  const types = ["온라인몰", "오늘드림"];

  return (
    <div style={{ minHeight: "100vh", background: "#fff", maxWidth: 375, margin: "0 auto", display: "flex", flexDirection: "column" }}>

      {/* 헤더 */}
      <div style={{ position: "sticky", top: 0, background: "#fff", zIndex: 40, borderBottom: "1px solid rgba(0,0,0,0.07)" }}>
        <div style={{ height: 48 }} />
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 16px 14px" }}>
          <button onClick={onBack}><ArrowLeft size={22} color="#1A1A1A" /></button>
          <span style={{ fontSize: 16, fontWeight: 700, color: "#1A1A1A" }}>고객센터</span>
          <div style={{ width: 22 }} />
        </div>
      </div>

      <div style={{ flex: 1, overflowY: "auto", scrollbarWidth: "none" }}>

        {/* ── FAQ ── */}
        <div style={{ padding: "20px 16px 0" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
            <span style={{ fontSize: 18, fontWeight: 800, color: "#1A1A1A" }}>FAQ</span>
            <button style={{ display: "flex", alignItems: "center", gap: 2, fontSize: 13, color: "#888" }}>
              더보기 <ChevronRight size={14} color="#888" />
            </button>
          </div>

          {/* 검색창 */}
          <div style={{
            display: "flex", alignItems: "center", gap: 10,
            border: "1.5px solid #E0E0E0", borderRadius: 24,
            padding: "11px 16px", marginBottom: 14,
          }}>
            <input
              value={searchText}
              onChange={e => setSearchText(e.target.value)}
              placeholder="질문 키워드를 입력해 주세요."
              style={{ flex: 1, border: "none", outline: "none", fontSize: 14, color: "#1A1A1A", background: "transparent" }}
            />
            <Search size={18} color="#AAAAAA" />
          </div>

          {/* 인기 질문 링크 */}
          <button style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 20, background: "#FFF0F3", borderRadius: 12, padding: "10px 14px", border: "1px solid #FFCDD8", width: "100%" }}>
            <img src={faqCharImg} alt="FAQ 캐릭터" style={{ width: 32, height: 32, objectFit: "contain", flexShrink: 0 }} />
            <span style={{ fontSize: 14, fontWeight: 700, color: "#E8527A", flex: 1, textAlign: "left" }}>가장 궁금해하시는 질문 10개</span>
            <ChevronRight size={14} color="#E8527A" />
          </button>

          {/* 구매 유형 아이콘 3개 */}
          <div style={{ display: "flex", justifyContent: "center", gap: 28, marginBottom: 20 }}>
            {types.map(t => (
              <button
                key={t}
                onClick={() => setSelectedType(t)}
                style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 8 }}
              >
                <div style={{
                  width: 64, height: 64, borderRadius: 20,
                  background: selectedType === t ? "#1A1A1A" : "#F2F2F2",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 28,
                }}>
                  {t === "온라인몰" ? "🛒" : "📦"}
                </div>
                <span style={{ fontSize: 12, fontWeight: selectedType === t ? 700 : 400, color: selectedType === t ? "#1A1A1A" : "#888" }}>
                  {t}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* 카테고리 6칸 그리드 */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", borderTop: "1px solid #F0F0F0", borderLeft: "1px solid #F0F0F0" }}>
          {categories.map(cat => (
            <button
              key={cat.label}
              style={{
                padding: "18px 8px",
                borderRight: "1px solid #F0F0F0", borderBottom: "1px solid #F0F0F0",
                display: "flex", flexDirection: "column", alignItems: "center", gap: 6,
                background: "#fff",
              }}
            >
              <span style={{ fontSize: 22 }}>{cat.emoji}</span>
              <span style={{ fontSize: 12, color: "#555", textAlign: "center", whiteSpace: "pre-line", lineHeight: 1.4 }}>
                {cat.label}
              </span>
            </button>
          ))}
        </div>

        {/* 인기 키워드 */}
        <div style={{ padding: "20px 16px 0" }}>
          <p style={{ fontSize: 16, fontWeight: 800, color: "#1A1A1A", marginBottom: 14 }}>인기 키워드</p>
          <div style={{ display: "flex", gap: 8, overflowX: "auto", scrollbarWidth: "none", paddingBottom: 4 }}>
            {keywords.map(kw => (
              <button key={kw} style={{
                padding: "8px 14px", borderRadius: 20, whiteSpace: "nowrap",
                border: "1.5px solid #E0E0E0", background: "#fff",
                fontSize: 13, color: "#555", flexShrink: 0,
              }}>{kw}</button>
            ))}
          </div>
        </div>

        {/* 채팅상담 / 1:1문의 버튼 */}
        <div style={{ margin: "20px 16px 0", display: "grid", gridTemplateColumns: "1fr 1fr", border: "1px solid #E8E8E8", borderRadius: 14, overflow: "hidden" }}>
          <button
            onClick={onChatSupport}
            style={{ padding: "18px 0", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, background: "#F8F8F8", borderRight: "1px solid #E8E8E8" }}
          >
            <MessageCircle size={18} color="#555" />
            <span style={{ fontSize: 14, fontWeight: 600, color: "#1A1A1A" }}>채팅 상담</span>
          </button>
          <button
            onClick={onInquiry}
            style={{ padding: "18px 0", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, background: "#F8F8F8" }}
          >
            <HelpCircle size={18} color="#555" />
            <span style={{ fontSize: 14, fontWeight: 600, color: "#1A1A1A" }}>1:1 문의</span>
          </button>
        </div>

        {/* 고객센터 전화번호 */}
        <div style={{ margin: "16px 16px 0", padding: "18px 16px", background: "#F8F8F8", borderRadius: 14 }}>
          <p style={{ fontSize: 13, color: "#888", marginBottom: 6 }}>고객센터</p>
          <p style={{ fontSize: 24, fontWeight: 800, color: "#1A1A1A", marginBottom: 8 }}>1577-0000</p>
          <p style={{ fontSize: 12, color: "#888", marginBottom: 3 }}>· 일반문의 : 09:00 ~ 18:00 (평일)</p>
          <p style={{ fontSize: 12, color: "#888" }}>· 성분/단종문의 : 09:00 ~ 22:00 (평일, 주말)</p>
        </div>

        {/* ── 공지사항 ── */}
        <div style={{ padding: "24px 16px 0" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 4 }}>
            <span style={{ fontSize: 18, fontWeight: 800, color: "#1A1A1A" }}>공지사항</span>
            <button style={{ display: "flex", alignItems: "center", gap: 2, fontSize: 13, color: "#888" }}>
              더보기 <ChevronRight size={14} color="#888" />
            </button>
          </div>
        </div>

        <div style={{ padding: "0 0 8px" }}>
          {notices.map((notice, idx) => (
            <button
              key={notice.id}
              style={{
                width: "100%", textAlign: "left",
                padding: "16px 16px",
                borderBottom: "1px solid #F2F2F2",
                background: "#fff",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                <span style={{
                  fontSize: 11, fontWeight: 600,
                  padding: "2px 8px", borderRadius: 4,
                  background: "#F0F0F0", color: "#666",
                }}>{notice.tag}</span>
                <span style={{ fontSize: 12, color: "#AAAAAA" }}>{notice.date}</span>
              </div>
              <p style={{ fontSize: 14, color: "#1A1A1A", lineHeight: 1.4 }}>{notice.title}</p>
            </button>
          ))}
        </div>

        {/* 하단 문의 바 */}
        <div style={{ borderTop: "1px solid rgba(0,0,0,0.07)", padding: "14px 0" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
            {[
              { Icon: Phone,         label: "대표전화" },
              { Icon: MessageCircle, label: "채팅 상담" },
              { Icon: HelpCircle,    label: "1:1문의"   },
              { Icon: Headphones,    label: "고객센터"  },
            ].map(({ Icon, label }, idx, arr) => (
              <React.Fragment key={label}>
                <button style={{ display: "flex", alignItems: "center", gap: 4, padding: "6px 10px" }}>
                  <Icon size={13} color="#888" strokeWidth={1.8} />
                  <span style={{ fontSize: 12, color: "#666", fontWeight: 500 }}>{label}</span>
                </button>
                {idx < arr.length - 1 && <span style={{ color: "#D8D8D8", fontSize: 12 }}>|</span>}
              </React.Fragment>
            ))}
          </div>
        </div>

        <div style={{ height: 20 }} />
      </div>
    </div>
  );
}
