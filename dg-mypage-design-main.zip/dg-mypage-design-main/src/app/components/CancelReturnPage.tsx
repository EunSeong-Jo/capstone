import React, { useState } from "react";
import { ArrowLeft, ShoppingBag, ChevronDown, ChevronRight, Phone, MessageCircle, HelpCircle, Headphones } from "lucide-react";

const G_DARK = "#3C7358";

type FilterType = "전체" | "취소" | "반품" | "교환";

const filterTabs: FilterType[] = ["전체", "취소", "반품", "교환"];

const sampleItems = [
  {
    id: 1,
    date: "2026.06.10",
    type: "취소" as FilterType,
    status: "취소완료",
    statusColor: "#888888",
    brand: "이니스프리",
    name: "수분 밸런싱 토너 200ml",
    option: "1개",
    price: "28,000원",
    bg: "#DFF0E8",
    canWithdraw: false,
  },
  {
    id: 2,
    date: "2026.06.05",
    type: "반품" as FilterType,
    status: "반품신청",
    statusColor: "#E85A2A",
    brand: "닥터자르트",
    name: "세라마이드 수분 크림 60ml",
    option: "1개",
    price: "42,000원",
    bg: "#FCE4E4",
    canWithdraw: true,
  },
  {
    id: 3,
    date: "2026.05.28",
    type: "교환" as FilterType,
    status: "교환완료",
    statusColor: G_DARK,
    brand: "코스알엑스",
    name: "히알루론산 에센스 50ml",
    option: "1개",
    price: "18,000원",
    bg: "#E0ECF8",
    canWithdraw: false,
  },
];

interface Props {
  onBack: () => void;
}

export function CancelReturnPage({ onBack }: Props) {
  const [activeFilter, setActiveFilter] = useState<FilterType>("전체");
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const filtered =
    activeFilter === "전체"
      ? sampleItems
      : sampleItems.filter((i) => i.type === activeFilter);

  return (
    <div
      className="flex flex-col"
      style={{ minHeight: "100vh", background: "#F4F6F4", maxWidth: 375, margin: "0 auto" }}
    >
      {/* ── 상단 헤더 ── */}
      <div
        style={{
          background: "#fff",
          borderBottom: "1px solid rgba(0,0,0,0.07)",
          position: "sticky",
          top: 0,
          zIndex: 40,
        }}
      >
        <div style={{ height: 48 }} />
        <div className="flex items-center justify-between px-4 pb-3.5">
          <button onClick={onBack} className="p-1">
            <ArrowLeft size={22} color="#1A1A1A" />
          </button>
          <span style={{ fontSize: 16, fontWeight: 700, color: "#1A1A1A" }}>
            취소/반품/교환 내역
          </span>
          <button className="p-1">
            <ShoppingBag size={22} color="#1A1A1A" />
          </button>
        </div>
      </div>

      {/* ── 필터 탭 ── */}
      <div
        style={{ background: "#fff", borderBottom: "1px solid rgba(0,0,0,0.08)" }}
      >
        {/* 기간 드롭다운 */}
        <div className="px-4 py-3 flex items-center justify-between">
          <button
            className="flex items-center gap-1.5"
            onClick={() => setDropdownOpen(!dropdownOpen)}
          >
            <span style={{ fontSize: 15, fontWeight: 600, color: "#1A1A1A" }}>전체 기간</span>
            <ChevronDown
              size={16}
              color="#555"
              style={{
                transform: dropdownOpen ? "rotate(180deg)" : "rotate(0deg)",
                transition: "transform 0.2s",
              }}
            />
          </button>
        </div>

        {/* 드롭다운 메뉴 */}
        {dropdownOpen && (
          <div
            style={{
              position: "absolute",
              top: 120,
              left: 16,
              background: "#fff",
              borderRadius: 12,
              boxShadow: "0 4px 20px rgba(0,0,0,0.12)",
              zIndex: 100,
              minWidth: 140,
              overflow: "hidden",
            }}
          >
            {["전체 기간", "최근 1개월", "최근 3개월", "최근 6개월"].map((opt) => (
              <button
                key={opt}
                className="w-full text-left px-4 py-3"
                style={{
                  fontSize: 14,
                  color: "#1A1A1A",
                  borderBottom: "1px solid rgba(0,0,0,0.05)",
                }}
                onClick={() => setDropdownOpen(false)}
              >
                {opt}
              </button>
            ))}
          </div>
        )}

        {/* 타입 필터 탭 */}
        <div className="flex px-4 pb-0 gap-1">
          {filterTabs.map((tab) => {
            const active = activeFilter === tab;
            return (
              <button
                key={tab}
                onClick={() => setActiveFilter(tab)}
                className="px-4 py-2"
                style={{
                  fontSize: 14,
                  fontWeight: active ? 700 : 400,
                  color: active ? G_DARK : "#888",
                  borderBottom: active ? `2px solid ${G_DARK}` : "2px solid transparent",
                  transition: "all 0.15s",
                }}
              >
                {tab}
              </button>
            );
          })}
        </div>
      </div>

      {/* ── 내역 목록 ── */}
      <div className="flex-1 overflow-y-auto pb-32" style={{ scrollbarWidth: "none" }}>
        {filtered.length === 0 ? (
          /* 빈 상태 */
          <div className="flex flex-col items-center justify-center py-24 gap-4">
            <div
              style={{
                width: 64, height: 64, borderRadius: "50%",
                border: "2px solid #D0D0D0",
                display: "flex", alignItems: "center", justifyContent: "center",
              }}
            >
              <span style={{ fontSize: 26, color: "#C0C0C0" }}>!</span>
            </div>
            <p style={{ fontSize: 14, color: "#999", textAlign: "center" }}>
              기간 내 취소/반품/교환 내역이 없습니다.
            </p>
          </div>
        ) : (
          <div className="flex flex-col gap-3 p-4">
            {filtered.map((item) => (
              <div
                key={item.id}
                style={{
                  background: "#fff",
                  borderRadius: 16,
                  overflow: "hidden",
                  boxShadow: "0 1px 8px rgba(0,0,0,0.06)",
                }}
              >
                {/* 상단: 날짜 + 상태 */}
                <div
                  className="flex items-center justify-between px-4 py-3"
                  style={{ borderBottom: "1px solid rgba(0,0,0,0.06)" }}
                >
                  <span style={{ fontSize: 13, color: "#888" }}>{item.date}</span>
                  <span
                    style={{
                      fontSize: 13, fontWeight: 700,
                      color: item.statusColor,
                    }}
                  >
                    {item.status}
                  </span>
                </div>

                {/* 상품 정보 */}
                <div className="flex gap-3 px-4 py-3.5">
                  {/* 상품 이미지 */}
                  <div
                    style={{
                      width: 72, height: 72, borderRadius: 12,
                      background: item.bg, flexShrink: 0,
                      display: "flex", alignItems: "center", justifyContent: "center",
                      fontSize: 28,
                    }}
                  >
                    🧴
                  </div>

                  {/* 텍스트 */}
                  <div className="flex-1 min-w-0">
                    <p style={{ fontSize: 12, color: "#999", marginBottom: 2 }}>{item.brand}</p>
                    <p
                      style={{ fontSize: 14, fontWeight: 600, color: "#1A1A1A", lineHeight: 1.4 }}
                      className="line-clamp-2"
                    >
                      {item.name}
                    </p>
                    <p style={{ fontSize: 12, color: "#aaa", marginTop: 2 }}>{item.option}</p>
                    <p style={{ fontSize: 15, fontWeight: 700, color: "#1A1A1A", marginTop: 4 }}>
                      {item.price}
                    </p>
                  </div>
                </div>

                {/* 하단 버튼 */}
                <div
                  className="flex gap-2 px-4 pb-3.5"
                  style={{ borderTop: "1px solid rgba(0,0,0,0.05)" }}
                >
                  {item.canWithdraw && (
                    <button
                      className="flex-1 py-2 rounded-lg"
                      style={{
                        border: `1.5px solid ${G_DARK}`,
                        color: G_DARK, fontSize: 13, fontWeight: 600,
                        marginTop: 10,
                      }}
                    >
                      {item.type} 철회
                    </button>
                  )}
                  <button
                    className="flex-1 py-2 rounded-lg flex items-center justify-center gap-1"
                    style={{
                      background: item.canWithdraw ? G_DARK : "#F2F3F2",
                      color: item.canWithdraw ? "#fff" : "#555",
                      fontSize: 13, fontWeight: 600,
                      marginTop: 10,
                    }}
                  >
                    상세보기 <ChevronRight size={13} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ── 안내 문구 박스 ── */}
        <div
          className="mx-4 mb-4 p-4 rounded-2xl"
          style={{ background: "#F6F6F6" }}
        >
          {[
            "취소/반품/교환 내역은 최근 1년 이내의 내역만 조회할 수 있습니다.",
            "단종 상품 환불의 경우 대체뭐야 고객센터로 문의해 주세요.",
          ].map((text, i) => (
            <div key={i} className="flex gap-2 mb-1.5">
              <span style={{ fontSize: 12, color: "#999", flexShrink: 0 }}>·</span>
              <span style={{ fontSize: 12, color: "#999", lineHeight: 1.5 }}>{text}</span>
            </div>
          ))}
        </div>
      </div>

      {/* ── 고정 하단 문의 바 ── */}
      <div
        style={{
          position: "fixed",
          bottom: 0,
          left: "50%",
          transform: "translateX(-50%)",
          width: "100%",
          maxWidth: 375,
          background: "#fff",
          borderTop: "1px solid rgba(0,0,0,0.08)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          paddingBottom: "env(safe-area-inset-bottom, 8px)",
          zIndex: 50,
        }}
      >
        {[
          { Icon: Phone,         label: "대표전화" },
          { Icon: MessageCircle, label: "채팅 상담" },
          { Icon: HelpCircle,    label: "1:1문의"   },
          { Icon: Headphones,    label: "고객센터"  },
        ].map(({ Icon, label }, idx, arr) => (
          <React.Fragment key={label}>
            <button className="flex items-center gap-1.5 px-3 py-3.5">
              <Icon size={14} color="#666" strokeWidth={1.8} />
              <span style={{ fontSize: 12, color: "#555", fontWeight: 500 }}>{label}</span>
            </button>
            {idx < arr.length - 1 && (
              <span style={{ color: "#D0D0D0", fontSize: 12 }}>|</span>
            )}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}
