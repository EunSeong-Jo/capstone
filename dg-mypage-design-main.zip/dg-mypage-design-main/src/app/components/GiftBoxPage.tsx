import React, { useState } from "react";
import { ArrowLeft, ShoppingBag, ChevronRight, Phone, MessageCircle, HelpCircle, Headphones, Gift } from "lucide-react";
import emptyGiftCharImg from "../../imports/KakaoTalk_20260625_022210725_08.png";

const G = "#3C7358";

type GiftTab = "받은 선물" | "보낸 선물";

const receivedGifts = [
  {
    id: 1,
    sender: "김지은",
    product: "이니스프리 수분 밸런싱 토너 200ml",
    brand: "이니스프리",
    date: "2026.06.10",
    status: "수락완료",
    statusColor: G,
    bg: "#DFF0E8",
    emoji: "🧴",
    price: "28,000원",
  },
  {
    id: 2,
    sender: "박서연",
    product: "닥터자르트 세라마이드 수분 크림 60ml",
    brand: "닥터자르트",
    date: "2026.05.22",
    status: "수락완료",
    statusColor: G,
    bg: "#FCE4E4",
    emoji: "🫙",
    price: "42,000원",
  },
];

const sentGifts = [
  {
    id: 1,
    receiver: "이수현",
    product: "코스알엑스 히알루론산 에센스 50ml",
    brand: "코스알엑스",
    date: "2026.06.15",
    status: "수락대기",
    statusColor: "#E8922A",
    bg: "#E0ECF8",
    emoji: "💧",
    price: "18,000원",
  },
  {
    id: 2,
    receiver: "최민지",
    product: "마녀공장 순식물성 클렌징 오일 200ml",
    brand: "마녀공장",
    date: "2026.05.30",
    status: "수락완료",
    statusColor: G,
    bg: "#FDF5DC",
    emoji: "🫧",
    price: "22,000원",
  },
];

interface Props { onBack: () => void; }

export function GiftBoxPage({ onBack }: Props) {
  const [tab, setTab] = useState<GiftTab>("받은 선물");
  const [showEmpty, setShowEmpty] = useState(false);

  const items = tab === "받은 선물" ? (showEmpty ? [] : receivedGifts) : sentGifts;
  const isEmpty = items.length === 0;

  return (
    <div style={{
      minHeight: "100vh", background: "#fff",
      maxWidth: 375, margin: "0 auto",
      display: "flex", flexDirection: "column",
    }}>

      {/* ── 헤더 ── */}
      <div style={{
        position: "sticky", top: 0, background: "#fff",
        zIndex: 40, borderBottom: "1px solid rgba(0,0,0,0.07)",
      }}>
        <div style={{ height: 48 }} />
        <div style={{
          display: "flex", alignItems: "center", justifyContent: "space-between",
          padding: "0 16px 0",
        }}>
          <button onClick={onBack}><ArrowLeft size={22} color="#1A1A1A" /></button>
          <span style={{ fontSize: 16, fontWeight: 700, color: "#1A1A1A" }}>선물함</span>
          <button><ShoppingBag size={22} color="#1A1A1A" /></button>
        </div>

        {/* ── 탭 ── */}
        <div style={{ display: "flex", marginTop: 2 }}>
          {(["받은 선물", "보낸 선물"] as GiftTab[]).map(t => (
            <div key={t} style={{ flex: 1, position: "relative", paddingBottom: 0 }}>
              <button
                onClick={() => setTab(t)}
                style={{
                  width: "100%", padding: "14px 0",
                  fontSize: 15, fontWeight: 700,
                  color: tab === t ? "#1A1A1A" : "#BBBBBB",
                  background: "transparent", border: "none",
                }}
              >{t}</button>
              {tab === t && (
                <div style={{
                  position: "absolute", bottom: 0, left: 0, right: 0,
                  height: 2, background: "#1A1A1A",
                }} />
              )}
            </div>
          ))}
        </div>
        <div style={{ height: 1, background: "#EBEBEB" }} />
      </div>

      {/* ── 스크롤 바디 ── */}
      <div style={{ flex: 1, overflowY: "auto", scrollbarWidth: "none", display: "flex", flexDirection: "column" }}>

        {isEmpty ? (
          /* ── 빈 상태 ── */
          <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "60px 32px 40px" }}>
            <img src={emptyGiftCharImg} alt="빈 선물함 캐릭터" style={{ width: 110, height: 110, objectFit: "contain", marginBottom: 8 }} />

            <p style={{ fontSize: 18, fontWeight: 700, color: "#1A1A1A", marginBottom: 10, textAlign: "center" }}>
              {tab === "받은 선물" ? "받은 선물이 없습니다" : "보낸 선물이 없습니다"}
            </p>
            <p style={{ fontSize: 13, color: "#999", textAlign: "center", lineHeight: 1.7, marginBottom: 28 }}>
              {tab === "받은 선물"
                ? "선물을 수락하시면\n선물함에서 내역을 확인하실 수 있어요"
                : "소중한 분께 화장품 선물을\n보내보세요"}
            </p>

            {/* 선물하러 가기 버튼 */}
            <button style={{
              display: "flex", alignItems: "center", gap: 6,
              padding: "12px 28px", borderRadius: 10,
              border: `1.5px solid ${G}`,
              background: "#fff", color: G,
              fontSize: 14, fontWeight: 700,
            }}>
              <Gift size={16} color={G} />
              선물하러 가기
            </button>
          </div>
        ) : (
          /* ── 선물 목록 ── */
          <div style={{ flex: 1 }}>
            {items.map((item: typeof receivedGifts[0] & { sender?: string; receiver?: string }, idx) => (
              <div key={item.id} style={{ borderBottom: "1px solid #F2F2F2" }}>
                {/* 날짜 + 상태 */}
                <div style={{
                  display: "flex", alignItems: "center", justifyContent: "space-between",
                  padding: "14px 16px 8px",
                }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                    <span style={{ fontSize: 12, color: "#aaa" }}>{item.date}</span>
                    <span style={{ fontSize: 11, color: "#ccc" }}>·</span>
                    <span style={{ fontSize: 12, color: "#888" }}>
                      {tab === "받은 선물" ? `${item.sender}님` : `→ ${item.receiver}님`}
                    </span>
                  </div>
                  <span style={{ fontSize: 12, fontWeight: 700, color: item.statusColor }}>
                    {item.status}
                  </span>
                </div>

                {/* 상품 정보 */}
                <div style={{ display: "flex", gap: 12, padding: "0 16px 12px" }}>
                  <div style={{
                    width: 72, height: 72, borderRadius: 10, flexShrink: 0,
                    background: item.bg,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 32, border: "1px solid rgba(0,0,0,0.05)",
                  }}>
                    {item.emoji}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ fontSize: 12, color: "#888", marginBottom: 2 }}>{item.brand}</p>
                    <p style={{
                      fontSize: 13, fontWeight: 600, color: "#1A1A1A",
                      lineHeight: 1.4, marginBottom: 6,
                    }}>{item.product}</p>
                    <p style={{ fontSize: 14, fontWeight: 700, color: "#1A1A1A" }}>{item.price}</p>
                  </div>
                </div>

                {/* 액션 버튼 */}
                <div style={{ padding: "0 16px 16px", display: "grid", gridTemplateColumns: tab === "받은 선물" ? "1fr 1fr" : "1fr", gap: 8 }}>
                  {tab === "받은 선물" && item.status === "수락완료" && (
                    <>
                      <button style={{
                        padding: "10px 0", borderRadius: 8,
                        border: "1px solid #CCCCCC", background: "#fff",
                        fontSize: 13, fontWeight: 600, color: "#1A1A1A",
                      }}>후기 작성</button>
                      <button style={{
                        padding: "10px 0", borderRadius: 8,
                        border: "none", background: G,
                        fontSize: 13, fontWeight: 600, color: "#fff",
                      }}>재구매</button>
                    </>
                  )}
                  {tab === "보낸 선물" && item.status === "수락대기" && (
                    <button style={{
                      padding: "10px 0", borderRadius: 8,
                      border: `1.5px solid ${G}`, background: "#fff",
                      fontSize: 13, fontWeight: 600, color: G,
                    }}>선물 취소</button>
                  )}
                  {tab === "보낸 선물" && item.status === "수락완료" && (
                    <button style={{
                      padding: "10px 0", borderRadius: 8,
                      border: "1px solid #CCCCCC", background: "#fff",
                      fontSize: 13, fontWeight: 600, color: "#1A1A1A",
                    }}>다시 선물하기</button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ── 선물하기 가이드 배너 ── */}
        <div style={{ padding: "16px 16px 20px", marginTop: "auto" }}>
          <button style={{
            width: "100%", borderRadius: 14,
            background: "#F4F8F5",
            border: `1px solid ${G}22`,
            padding: "16px 18px",
            display: "flex", alignItems: "center", justifyContent: "space-between",
            overflow: "hidden",
          }}>
            <div style={{ textAlign: "left" }}>
              <p style={{ fontSize: 12, color: "#888", marginBottom: 4 }}>
                대체뭐야 선물하기 어렵지 않아요!
              </p>
              <p style={{ fontSize: 15, fontWeight: 800, color: "#1A1A1A" }}>
                선물하기 가이드 바로가기
              </p>
            </div>
            <div style={{ display: "flex", gap: -4, marginLeft: 8 }}>
              {["💄", "🧴", "🫙", "🌸"].map((e, i) => (
                <div key={i} style={{
                  width: 36, height: 36, borderRadius: "50%",
                  background: ["#FFE4B5", "#DFF0E8", "#FCE4E4", "#E8F0FE"][i],
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 18, marginLeft: i > 0 ? -8 : 0,
                  border: "2px solid #fff",
                  boxShadow: "0 1px 4px rgba(0,0,0,0.08)",
                }}>{e}</div>
              ))}
            </div>
          </button>
        </div>

        <div style={{ height: 70 }} />
      </div>

      {/* ── 고정 하단 문의 바 ── */}
      <div style={{
        position: "fixed", bottom: 0,
        left: "50%", transform: "translateX(-50%)",
        width: "100%", maxWidth: 375,
        background: "#fff", borderTop: "1px solid rgba(0,0,0,0.08)",
        display: "flex", alignItems: "center", justifyContent: "center",
        paddingBottom: "env(safe-area-inset-bottom, 8px)",
        zIndex: 50,
      }}>
        {[
          { Icon: Phone,         label: "대표전화" },
          { Icon: MessageCircle, label: "채팅 상담" },
          { Icon: HelpCircle,    label: "1:1문의"   },
          { Icon: Headphones,    label: "고객센터"  },
        ].map(({ Icon, label }, idx, arr) => (
          <React.Fragment key={label}>
            <button style={{
              display: "flex", alignItems: "center", gap: 4,
              padding: "12px 10px",
            }}>
              <Icon size={13} color="#666" strokeWidth={1.8} />
              <span style={{ fontSize: 12, color: "#555", fontWeight: 500 }}>{label}</span>
            </button>
            {idx < arr.length - 1 && (
              <span style={{ color: "#D8D8D8", fontSize: 12 }}>|</span>
            )}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}
