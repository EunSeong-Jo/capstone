import React, { useState } from "react";
import waterDropCharImg from "../imports/KakaoTalk_20260625_022210725_14.png";
import {
  ChevronRight,
  Home,
  Search,
  MessageCircle,
  User,
  Headphones,
  HelpCircle,
  LogOut,
  RefreshCw,
  Truck,
  Bell,
  Phone,
} from "lucide-react";
import { CancelReturnPage } from "./components/CancelReturnPage";
import { OrderHistoryPage } from "./components/OrderHistoryPage";
import { PointsPage } from "./components/PointsPage";
import { MoneyPage } from "./components/MoneyPage";
import { CouponPage } from "./components/CouponPage";
import { ReviewPage } from "./components/ReviewPage";
import { GiftBoxPage } from "./components/GiftBoxPage";
import { ShippingPage } from "./components/ShippingPage";
import { RestockPage } from "./components/RestockPage";
import { CustomerServicePage } from "./components/CustomerServicePage";
import { ChatSupportPage } from "./components/ChatSupportPage";
import { InquiryPage } from "./components/InquiryPage";

/* ─── colour tokens ─── */
const G_DARK = "#3C7358";
const G_NUM  = "#3BA068";

type Tab = "home" | "search" | "chatbot" | "mypage";

/* ─── order steps ─── */
const orderSteps = [
  { label: "주문접수",  count: 0 },
  { label: "결제완료",  count: 0 },
  { label: "배송준비중", count: 0 },
  { label: "배송중",    count: 1 },
  { label: "배송완료",  count: 3 },
];

/* ─── shopping activity items ─── */
const shoppingItems = [
  { Icon: RefreshCw, label: "취소/반품/교환 내역" },
  { Icon: Truck,     label: "배송지 관리"          },
  { Icon: Bell,      label: "재입고 알림"          },
];

/* ─── thin divider ─── */
function Divider({ thick = false }: { thick?: boolean }) {
  return (
    <div
      style={{
        height: thick ? 8 : 1,
        background: thick ? "#EBEBEB" : "rgba(0,0,0,0.07)",
        margin: thick ? "0" : "0",
      }}
    />
  );
}

/* ─── section title ─── */
function SectionTitle({ title, action }: { title: string; action?: string }) {
  return (
    <div className="flex items-center justify-between px-5 pt-5 pb-3">
      <span style={{ fontSize: 16, fontWeight: 700, color: "#1A1A1A" }}>{title}</span>
      {action && (
        <button className="flex items-center gap-0.5" style={{ color: "#888", fontSize: 13 }}>
          {action} <ChevronRight size={14} />
        </button>
      )}
    </div>
  );
}

type Page = "mypage" | "cancel-return" | "order-history" | "points" | "money" | "coupon" | "review" | "giftbox" | "shipping" | "restock" | "customer-service" | "chat-support" | "inquiry";

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>("mypage");
  const [currentPage, setCurrentPage] = useState<Page>("mypage");

  if (currentPage === "cancel-return") {
    return (
      <div className="flex justify-center min-h-screen" style={{ background: "#F4F6F4" }}>
        <CancelReturnPage onBack={() => setCurrentPage("mypage")} />
      </div>
    );
  }

  if (currentPage === "order-history") {
    return (
      <div className="flex justify-center min-h-screen" style={{ background: "#F4F6F4" }}>
        <OrderHistoryPage onBack={() => setCurrentPage("mypage")} />
      </div>
    );
  }

  if (currentPage === "points") {
    return (
      <div className="flex justify-center min-h-screen" style={{ background: "#fff" }}>
        <PointsPage onBack={() => setCurrentPage("mypage")} />
      </div>
    );
  }

  if (currentPage === "money") {
    return (
      <div className="flex justify-center min-h-screen" style={{ background: "#fff" }}>
        <MoneyPage onBack={() => setCurrentPage("mypage")} />
      </div>
    );
  }

  if (currentPage === "coupon") {
    return (
      <div className="flex justify-center min-h-screen" style={{ background: "#F4F6F4" }}>
        <CouponPage onBack={() => setCurrentPage("mypage")} />
      </div>
    );
  }

  if (currentPage === "review") {
    return (
      <div className="flex justify-center min-h-screen" style={{ background: "#fff" }}>
        <ReviewPage onBack={() => setCurrentPage("mypage")} />
      </div>
    );
  }

  if (currentPage === "giftbox") {
    return (
      <div className="flex justify-center min-h-screen" style={{ background: "#fff" }}>
        <GiftBoxPage onBack={() => setCurrentPage("mypage")} />
      </div>
    );
  }

  if (currentPage === "shipping") {
    return (
      <div className="flex justify-center min-h-screen" style={{ background: "#F4F6F4" }}>
        <ShippingPage onBack={() => setCurrentPage("mypage")} />
      </div>
    );
  }

  if (currentPage === "restock") {
    return (
      <div className="flex justify-center min-h-screen" style={{ background: "#fff" }}>
        <RestockPage onBack={() => setCurrentPage("mypage")} />
      </div>
    );
  }

  if (currentPage === "customer-service") {
    return (
      <div className="flex justify-center min-h-screen" style={{ background: "#fff" }}>
        <CustomerServicePage
          onBack={() => setCurrentPage("mypage")}
          onChatSupport={() => setCurrentPage("chat-support")}
          onInquiry={() => setCurrentPage("inquiry")}
        />
      </div>
    );
  }

  if (currentPage === "chat-support") {
    return (
      <div className="flex justify-center min-h-screen" style={{ background: "#F4F6F4" }}>
        <ChatSupportPage onBack={() => setCurrentPage("customer-service")} />
      </div>
    );
  }

  if (currentPage === "inquiry") {
    return (
      <div className="flex justify-center min-h-screen" style={{ background: "#fff" }}>
        <InquiryPage onBack={() => setCurrentPage("customer-service")} />
      </div>
    );
  }

  return (
    <div className="flex justify-center min-h-screen" style={{ background: "#F4F6F4" }}>
      <div className="w-full max-w-sm relative flex flex-col" style={{ minHeight: "100vh" }}>

        {/* ══════════════════════════════════════
            1. GREEN GRADIENT PROFILE CARD
        ══════════════════════════════════════ */}
        <div
          style={{
            background: `linear-gradient(160deg, #2E6B4A 0%, ${G_DARK} 45%, #4A9A6A 100%)`,
            paddingBottom: 22,
          }}
        >
          {/* status bar gap */}
          <div style={{ height: 48 }} />

          {/* avatar + name + email */}
          <div className="flex items-center gap-3 px-5">
            <div
              style={{
                width: 54, height: 54, borderRadius: 18,
                background: "rgba(255,255,255,0.20)",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 28, flexShrink: 0,
              }}
            >
              😊
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <p style={{ color: "#fff", fontSize: 18, fontWeight: 700 }}>닉네임</p>
                <ChevronRight size={16} color="rgba(255,255,255,0.55)" />
              </div>
              <p style={{ color: "rgba(255,255,255,0.65)", fontSize: 12, marginTop: 1 }}>
                user@email.com
              </p>
              {/* skin badges */}
              <div className="flex gap-1.5 mt-2 flex-wrap">
                {["건성", "민감성"].map(t => (
                  <span
                    key={t}
                    style={{
                      fontSize: 10, fontWeight: 700,
                      background: "rgba(255,255,255,0.20)",
                      color: "#fff",
                      padding: "2px 9px", borderRadius: 20,
                      border: "1px solid rgba(255,255,255,0.35)",
                    }}
                  >{t}</span>
                ))}
              </div>
            </div>
          </div>

          {/* skin type panel */}
          <div
            className="mx-4 mt-4 flex items-center gap-2.5 px-4 py-3 rounded-2xl"
            style={{ background: "rgba(255,255,255,0.14)" }}
          >
            <img src={waterDropCharImg} alt="수분팡팡 옹달샘" style={{ width: 36, height: 36, objectFit: "contain", flexShrink: 0 }} />
            <div className="flex-1">
              <p style={{ color: "rgba(255,255,255,0.60)", fontSize: 10 }}>내 피부타입</p>
              <p style={{ color: "#fff", fontSize: 15, fontWeight: 700 }}>수분팡팡 옹달샘</p>
            </div>
            <button
              style={{
                background: "#fff", color: G_DARK,
                fontSize: 11, fontWeight: 700,
                padding: "5px 13px", borderRadius: 20,
                flexShrink: 0, border: "none",
              }}
            >
              재진단
            </button>
          </div>
        </div>

        {/* ══════════════════════════════════════
            SCROLLABLE BODY
        ══════════════════════════════════════ */}
        <div
          className="flex-1 overflow-y-auto pb-28"
          style={{ background: "#F4F6F4", scrollbarWidth: "none" }}
        >

          {/* ── 2. 적립금 / 대체뭐야머니 / 쿠폰 ── */}
          <div style={{ background: "#fff", marginTop: 0 }}>
            {/* 3-split row */}
            <div className="grid grid-cols-3" style={{ borderBottom: "1px solid rgba(0,0,0,0.07)" }}>
              {[
                { label: "적립금",       value: "2,885원", page: "points"  as Page },
                { label: "대체뭐야머니",  value: "3,450원", page: "money"   as Page },
                { label: "쿠폰",         value: "5장",     page: "coupon"  as Page },
              ].map(({ label, value, page }, idx) => (
                <button
                  key={label}
                  className="flex flex-col items-start px-4 py-4"
                  style={{
                    borderRight: idx < 2 ? "1px solid rgba(0,0,0,0.07)" : "none",
                  }}
                  onClick={() => setCurrentPage(page)}
                >
                  <div className="flex items-center gap-0.5 mb-1">
                    <span style={{ fontSize: 12, color: "#888" }}>{label}</span>
                    <ChevronRight size={12} color="#888" />
                  </div>
                  <span style={{ fontSize: 17, fontWeight: 700, color: "#1A1A1A" }}>{value}</span>
                </button>
              ))}
            </div>

            {/* review prompt */}
            <button
              className="w-full flex items-center justify-between px-4 py-3.5"
              style={{ borderBottom: "none" }}
              onClick={() => setCurrentPage("review")}
            >
              <span style={{ fontSize: 13, color: "#1A1A1A" }}>
                작성 가능한 후기{" "}
                <span style={{ fontWeight: 700 }}>14개</span>{" "}
                <span style={{ color: G_NUM, fontWeight: 600 }}>19,000원 적립 가능</span>
              </span>
              <ChevronRight size={15} color="#AAAAAA" />
            </button>
          </div>

          <Divider thick />

          {/* ── 3. 주문/배송 조회 ── */}
          <div style={{ background: "#fff" }}>
            <div className="flex items-center justify-between px-5 pt-5 pb-3">
              <span style={{ fontSize: 16, fontWeight: 700, color: "#1A1A1A" }}>주문/배송 조회</span>
              <button
                className="flex items-center gap-0.5"
                style={{ color: "#888", fontSize: 13 }}
                onClick={() => setCurrentPage("order-history")}
              >
                전체보기 <ChevronRight size={14} />
              </button>
            </div>

            {/* 5-step tracker */}
            <div className="flex items-start px-3 pb-5">
              {orderSteps.map((step, idx) => (
                <React.Fragment key={step.label}>
                  {/* step column */}
                  <div className="flex flex-col items-center" style={{ flex: 1 }}>
                    <p
                      style={{
                        fontSize: 22,
                        fontWeight: 700,
                        color: step.count > 0 ? "#1A1A1A" : "#CCCCCC",
                        lineHeight: 1,
                      }}
                    >
                      {step.count}
                    </p>
                    <p
                      style={{
                        fontSize: 10,
                        color: "#999",
                        marginTop: 5,
                        textAlign: "center",
                        whiteSpace: "pre-wrap",
                        lineHeight: 1.35,
                      }}
                    >
                      {step.label.replace("배송준비중", "배송\n준비중")}
                    </p>
                  </div>
                  {/* arrow */}
                  {idx < orderSteps.length - 1 && (
                    <div
                      className="flex items-center justify-center"
                      style={{ paddingTop: 4, flexShrink: 0, width: 14 }}
                    >
                      <ChevronRight size={13} color="#CCCCCC" />
                    </div>
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>

          <Divider thick />

          {/* ── 4. 쇼핑 활동 ── */}
          <div style={{ background: "#fff" }}>
            <SectionTitle title="쇼핑 활동" />

            {shoppingItems.map(({ Icon, label }, idx) => (
              <button
                key={label}
                className="w-full flex items-center gap-4 px-5 py-4 text-left"
                style={{
                  borderTop: idx === 0 ? "1px solid rgba(0,0,0,0.06)" : "none",
                  borderBottom: "1px solid rgba(0,0,0,0.06)",
                }}
                onClick={() => {
                  if (label === "취소/반품/교환 내역") setCurrentPage("cancel-return");
                  if (label === "선물함") setCurrentPage("giftbox");
                  if (label === "배송지 관리") setCurrentPage("shipping");
                  if (label === "재입고 알림") setCurrentPage("restock");
                }}
              >
                <Icon size={20} color="#555" strokeWidth={1.6} />
                <span style={{ flex: 1, fontSize: 15, color: "#1A1A1A", fontWeight: 500 }}>
                  {label}
                </span>
                <ChevronRight size={16} color="#CCCCCC" />
              </button>
            ))}
          </div>


          <Divider thick />

          {/* ── 7. 로그아웃 ── */}
          <div style={{ background: "#fff" }}>
            <button
              className="w-full flex items-center gap-4 px-5 py-4 text-left"
              style={{ borderBottom: "1px solid rgba(0,0,0,0.06)" }}
            >
              <LogOut size={20} color="#555" strokeWidth={1.6} />
              <span style={{ flex: 1, fontSize: 15, color: "#1A1A1A", fontWeight: 500 }}>
                로그아웃
              </span>
            </button>
          </div>

          <Divider thick />

          {/* ── 문의 바 ── */}
          <div style={{ background: "#fff" }}>
            <div
              style={{
                display: "flex", alignItems: "center", justifyContent: "center",
                padding: "14px 0",
              }}
            >
              {[
                { Icon: Phone,         label: "대표전화",  page: null                   },
                { Icon: MessageCircle, label: "채팅 상담", page: "chat-support" as Page },
                { Icon: HelpCircle,    label: "1:1문의",   page: "inquiry"      as Page },
                { Icon: Headphones,    label: "고객센터",  page: "customer-service" as Page },
              ].map(({ Icon, label, page }, idx, arr) => (
                <React.Fragment key={label}>
                  <button
                    style={{ display: "flex", alignItems: "center", gap: 4, padding: "6px 10px" }}
                    onClick={() => { if (page) setCurrentPage(page); }}
                  >
                    <Icon size={13} color="#888" strokeWidth={1.8} />
                    <span style={{ fontSize: 12, color: "#666", fontWeight: 500 }}>{label}</span>
                  </button>
                  {idx < arr.length - 1 && (
                    <span style={{ color: "#D8D8D8", fontSize: 12 }}>|</span>
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>

          <div style={{ height: 24 }} />
        </div>

        {/* ══════════════════════════════════════
            FIXED BOTTOM NAV
        ══════════════════════════════════════ */}
        <nav
          style={{
            position: "fixed",
            bottom: 0,
            left: "50%",
            transform: "translateX(-50%)",
            width: "100%",
            maxWidth: 384,
            background: "#fff",
            borderTop: "1px solid rgba(0,0,0,0.08)",
            display: "flex",
            paddingBottom: "env(safe-area-inset-bottom, 6px)",
            zIndex: 50,
          }}
        >
          {(
            [
              { id: "home"    as Tab, Icon: Home,          label: "홈"  },
              { id: "search"  as Tab, Icon: Search,        label: "검색" },
              { id: "chatbot" as Tab, Icon: MessageCircle, label: "챗봇" },
              { id: "mypage"  as Tab, Icon: User,          label: "MY"  },
            ]
          ).map(({ id, Icon, label }) => {
            const active = activeTab === id;
            return (
              <button
                key={id}
                className="flex-1 flex flex-col items-center gap-1 py-3"
                onClick={() => setActiveTab(id)}
              >
                <Icon
                  size={22}
                  color={active ? "#1A1A1A" : "#AAAAAA"}
                  strokeWidth={active ? 2.5 : 1.8}
                  fill={active ? "#1A1A1A" : "none"}
                />
                <span
                  style={{
                    fontSize: 10,
                    fontWeight: active ? 700 : 400,
                    color: active ? "#1A1A1A" : "#AAAAAA",
                  }}
                >
                  {label}
                </span>
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
