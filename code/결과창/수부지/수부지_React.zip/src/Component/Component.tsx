import { LiquidGlassRegularSmallModeLightStateDefault } from "../LiquidGlassRegularSmallModeLightStateDefault/LiquidGlassRegularSmallModeLightStateDefault";
import { ChevronBackward } from "../ChevronBackward/ChevronBackward";
import { X } from "../X/X";
import { BuildingBlocksStatusBar } from "../BuildingBlocksStatusBar/BuildingBlocksStatusBar";

export interface IComponentProps {
  className?: string;
}

export const Component = ({
  className,
  ...props
}: IComponentProps): JSX.Element => {
  return (
    <div
      className={"bg-[#ffffff] h-[833px] relative overflow-hidden " + className}
    >
      <LiquidGlassRegularSmallModeLightStateDefault className="!absolute !right-[18px] !left-[19px] !bottom-[19px] !top-[766px] !w-[unset] !h-[unset]"></LiquidGlassRegularSmallModeLightStateDefault>
      <div className="text-[#ffffff] text-left font-['HankenGrotesk-Medium',_sans-serif] text-lg font-medium absolute left-[107px] top-[778px]">
        맞춤 스킨케어 추천 받기{" "}
      </div>
      <div className="text-[#000000] text-center font-['HankenGrotesk-Medium',_sans-serif] text-[15px] font-medium absolute left-1 top-[601px] w-[218px] h-[35px]">
        (캐릭터 이름) 추천하는 성분{" "}
      </div>
      <img
        className="rounded-[20px] border-solid border-[#b1d8b1] border-[1.5px] w-[342.81px] h-[416px] absolute left-[26px] top-36"
        style={{ objectFit: "cover" }}
        src="chat-gpt-image-2026-7-13-04-00-13-10.png"
      />
      <div className="bg-[#ecf4e6] w-[89px] h-[95px] absolute left-[273px] top-[154px]"></div>
      <div className="bg-[#40a140] rounded-[20px] w-[119px] h-[21px] absolute left-[137px] top-[164px]"></div>
      <div className="text-[#ffffff] text-left font-['HankenGrotesk-Medium',_sans-serif] text-xs font-medium absolute left-36 top-[167px] w-[113.63px] h-[33.7px]">
        겉바속촉 수부지 타입{" "}
      </div>
      <img
        className="w-[190.67px] h-[165.63px] absolute left-[102.07px] top-[249.93px]"
        style={{ objectFit: "cover", aspectRatio: "190.67/165.63" }}
        src="kakao-talk-20260525-194504321-05-10.png"
      />
      <div className="text-center font-['HankenGrotesk-Medium',_sans-serif] text-[15px] leading-normal font-medium absolute left-[57px] top-[489px] w-[279.26px] h-[33.7px]">
        <span>
          <span className="div-6-span">
            겉은 번들번들, 속은 메말랐어요! <br />
            수분 충전이 시급한
          </span>
          <span className="div-6-span2">수부지 타입</span>
          <span className="div-6-span">이에요.</span>
        </span>{" "}
      </div>
      <div className="bg-[#dbe8f8] rounded-[15px] w-[71.26px] h-[25.04px] absolute left-[118px] top-[448px]"></div>
      <div className="bg-[#feedc5] rounded-[15px] w-[71.26px] h-[25.04px] absolute left-[204.67px] top-[448px]"></div>
      <div className="text-[#005bcb] text-center font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[130.59px] top-[453px] w-[45.26px] h-[14.44px]">
        #속건조{" "}
      </div>
      <div className="text-[#cc8f00] text-center font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[209.59px] top-[453px] w-[61px] h-3.5">
        #겉번들{" "}
      </div>
      <div className="text-[#40a140] text-left font-['ClimateCrisis-1990',_sans-serif] text-[25px] font-normal absolute left-[116px] top-48 w-[197px] h-[33px]">
        수부지 피부{" "}
      </div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Bold',_sans-serif] text-[19px] font-bold absolute left-[113px] top-[104px]">
        당신의 피부 타입은....{" "}
      </div>
      <div
        className="bg-[#eb9298] rounded-[50%] w-[29px] h-[29px] absolute left-[342px] top-[55px]"
        style={{ boxShadow: "0px 0px 3.8px 0px rgba(235, 146, 152, 1.00)" }}
      ></div>
      <div
        className="bg-[#eb9298] rounded-[50%] w-[29px] h-[29px] absolute left-[22px] top-[55px]"
        style={{ boxShadow: "0px 0px 3.8px 0px rgba(235, 146, 152, 1.00)" }}
      ></div>
      <ChevronBackward className="!h-[23px] !absolute !left-6 !top-[58px]"></ChevronBackward>
      <X className="!w-[17px] !h-[17px] !absolute !left-[348px] !top-[61px]"></X>
      <BuildingBlocksStatusBar
        cameraCutout={false}
        className="!w-[396px] !h-[37px] !absolute !left-[-2px] !top-0"
      ></BuildingBlocksStatusBar>
      <div
        className="bg-[#ffffff] rounded-[10px] w-[93px] h-[113px] absolute left-[38px] top-[632px]"
        style={{ boxShadow: "0px 0px 13px -2px rgba(0, 0, 0, 0.25)" }}
      ></div>
      <div
        className="bg-[#ffffff] rounded-[10px] w-[93px] h-[113px] absolute left-36 top-[632px]"
        style={{ boxShadow: "0px 0px 13px -2px rgba(0, 0, 0, 0.25)" }}
      ></div>
      <div
        className="bg-[#ffffff] rounded-[10px] w-[93px] h-[113px] absolute left-[250px] top-[632px]"
        style={{ boxShadow: "0px 0px 13px -2px rgba(0, 0, 0, 0.25)" }}
      ></div>
      <img
        className="rounded-[10px] w-[42px] h-[61px] absolute left-[42px] top-[639px]"
        style={{ objectFit: "cover", aspectRatio: "42/61" }}
        src="gemini-generated-image-e-2-h-3-e-2-h-3-e-2-h-3-e-2-h-3-40.png"
      />
      <img
        className="rounded-[10px] w-[43px] h-[55px] absolute left-[255px] top-[641px]"
        style={{ objectFit: "cover", aspectRatio: "43/55" }}
        src="gemini-generated-image-e-2-h-3-e-2-h-3-e-2-h-3-e-2-h-3-50.png"
      />
      <img
        className="rounded-[10px] w-[43px] h-[55px] absolute left-[148px] top-[641px]"
        style={{ objectFit: "cover" }}
        src="gemini-generated-image-e-2-h-3-e-2-h-3-e-2-h-3-e-2-h-3-41.png"
      />
      <div className="text-[#000000] text-center font-['AsapCondensed-Medium',_sans-serif] text-[10px] font-medium absolute left-[45px] top-[697px]">
        Hyaluronic Acid{" "}
      </div>
      <div className="text-[#000000] text-center font-['AsapCondensed-Medium',_sans-serif] text-[11px] font-medium absolute left-[151px] top-[696px]">
        Panthenol{" "}
      </div>
      <div className="text-[#000000] text-center font-['AsapCondensed-Medium',_sans-serif] text-[11px] font-medium absolute left-64 top-[696px]">
        Squalane{" "}
      </div>
      <div className="bg-[#c8e6ff] rounded-[30px] w-[18px] h-[9px] absolute left-[106px] top-[698px]"></div>
      <div className="text-[#017ce3] text-center font-['AsapCondensed-Medium',_sans-serif] text-[6px] font-medium absolute left-[109px] top-[699px]">
        수분{" "}
      </div>
      <div className="bg-[#9ad5a5] rounded-[30px] w-[18px] h-[9px] absolute left-[198px] top-[698px]"></div>
      <div className="text-[#0d6d1e] text-center font-['AsapCondensed-Medium',_sans-serif] text-[6px] font-medium absolute left-[201px] top-[699px]">
        보습{" "}
      </div>
      <div className="bg-[#ffe378] rounded-[30px] w-[23px] h-[9px] absolute left-[299px] top-[698px]"></div>
      <div className="text-[#7c6a25] text-center font-['AsapCondensed-Medium',_sans-serif] text-[6px] font-medium absolute left-[302px] top-[699px]">
        유수분{" "}
      </div>
      <div className="text-[#aaaaaa] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[6px] font-medium absolute left-[45px] top-[718px]">
        피부 깊숙이 <br />
        강력한 수분을 충전해 줘요.{" "}
      </div>
      <div className="text-[#aaaaaa] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[6px] font-medium absolute left-[151px] top-[718px]">
        수분을 채우고
        <br />
        무너진 피부 장벽을 강화해요.{" "}
      </div>
      <div className="text-[#aaaaaa] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[6px] font-medium absolute left-[257px] top-[718px]">
        모공을 막지 않고 <br />
        산뜻하게 수분막을 지켜줘요.{" "}
      </div>
    </div>
  );
};
