import { LiquidGlassRegularSmallModeLightStateDefault } from "../LiquidGlassRegularSmallModeLightStateDefault/LiquidGlassRegularSmallModeLightStateDefault";
import { ChevronBackward } from "../ChevronBackward/ChevronBackward";
import { X } from "../X/X";
import { BuildingBlocksStatusBar } from "../BuildingBlocksStatusBar/BuildingBlocksStatusBar";

export interface IComponentProps {
  className?: string;
}

export const Component = ({
  className,
  ...props
}: IComponentProps): JSX.Element => {
  return (
    <div
      className={"bg-[#ffffff] h-[833px] relative overflow-hidden " + className}
    >
      <LiquidGlassRegularSmallModeLightStateDefault className="!absolute !right-[18px] !left-[19px] !bottom-[19px] !top-[766px] !w-[unset] !h-[unset]"></LiquidGlassRegularSmallModeLightStateDefault>
      <div className="text-[#ffffff] text-left font-['HankenGrotesk-Medium',_sans-serif] text-lg font-medium absolute left-[107px] top-[778px]">
        맞춤 스킨케어 추천 받기{" "}
      </div>
      <div className="text-[#000000] text-center font-['HankenGrotesk-Medium',_sans-serif] text-[15px] font-medium absolute left-1 top-[601px] w-[218px] h-[35px]">
        (캐릭터 이름) 추천하는 성분{" "}
      </div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Bold',_sans-serif] text-[19px] font-bold absolute left-[113px] top-[104px]">
        당신의 피부 타입은....{" "}
      </div>
      <div
        className="bg-[#eb9298] rounded-[50%] w-[29px] h-[29px] absolute left-[342px] top-[55px]"
        style={{ boxShadow: "0px 0px 3.8px 0px rgba(235, 146, 152, 1.00)" }}
      ></div>
      <div
        className="bg-[#eb9298] rounded-[50%] w-[29px] h-[29px] absolute left-[22px] top-[55px]"
        style={{ boxShadow: "0px 0px 3.8px 0px rgba(235, 146, 152, 1.00)" }}
      ></div>
      <ChevronBackward className="!h-[23px] !absolute !left-6 !top-[58px]"></ChevronBackward>
      <X className="!w-[17px] !h-[17px] !absolute !left-[348px] !top-[61px]"></X>
      <BuildingBlocksStatusBar
        cameraCutout={false}
        className="!w-[396px] !h-[37px] !absolute !left-[-2px] !top-0"
      ></BuildingBlocksStatusBar>
      <img
        className="rounded-[20px] border-solid border-[#ffa292] border-[1.5px] w-[343px] h-[416px] absolute left-[26px] top-36"
        style={{ objectFit: "cover" }}
        src="chat-gpt-image-2026-7-13-04-00-13-40.png"
      />
      <img
        className="w-[245.76px] h-[138.83px] absolute left-[71px] top-[270px]"
        style={{ objectFit: "cover", aspectRatio: "245.76/138.83" }}
        src="kakao-talk-20260525-194504321-09-20.png"
      />
      <div className="bg-[#fee9e8] w-[67.56px] h-[94.72px] absolute left-[296.16px] top-[176.19px]"></div>
      <div className="text-[#e24e34] text-left font-['ClimateCrisis-1990',_sans-serif] text-[25px] font-normal absolute left-[114px] top-48 w-[164px] h-[33px]">
        트러블 피부{" "}
      </div>
      <div className="bg-[#e24e34] rounded-[20px] w-[117px] h-[21px] absolute left-[137px] top-[164px]"></div>
      <div className="text-[#ffffff] text-left font-['HankenGrotesk-Medium',_sans-serif] text-xs font-medium absolute left-[149px] top-[167px] w-[110.72px] h-[32.82px]">
        울긋불긋 화산 타입{" "}
      </div>
      <div className="text-center font-['HankenGrotesk-Medium',_sans-serif] text-[15px] font-medium absolute left-[58px] top-[491px] w-[279.26px] h-[33.7px]">
        <span>
          <span className="div-8-span">
            툭하면 뾰루지가 뾱! 피지와 각질이 <br />
            뭉쳐서 쉽게 성이 나는
          </span>
          <span className="div-8-span2">화산 타입</span>
          <span className="div-8-span">이에요</span>
        </span>{" "}
      </div>
      <div className="bg-[#ffdbd4] rounded-[15px] w-[71.26px] h-[25.04px] absolute left-[119px] top-[439px]"></div>
      <div className="bg-[rgba(255,178,164,0.62)] rounded-[15px] w-[71.26px] h-[25.04px] absolute left-[205.67px] top-[439px]"></div>
      <div className="text-[#ff4a4a] text-center font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[131px] top-[443px] w-[45.26px] h-[14.44px]">
        #과피지{" "}
      </div>
      <div className="text-[#ff0000] text-center font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[218px] top-[443px] w-[46px] h-3.5">
        #붉은기{" "}
      </div>
      <div
        className="bg-[#ffffff] rounded-[10px] w-[93px] h-[113px] absolute left-[38px] top-[632px]"
        style={{ boxShadow: "0px 0px 13px -2px rgba(0, 0, 0, 0.25)" }}
      ></div>
      <div
        className="bg-[#ffffff] rounded-[10px] w-[93px] h-[113px] absolute left-36 top-[632px]"
        style={{ boxShadow: "0px 0px 13px -2px rgba(0, 0, 0, 0.25)" }}
      ></div>
      <div
        className="bg-[#ffffff] rounded-[10px] w-[93px] h-[113px] absolute left-[250px] top-[632px]"
        style={{ boxShadow: "0px 0px 13px -2px rgba(0, 0, 0, 0.25)" }}
      ></div>
      <img
        className="rounded-[10px] w-11 h-[57px] absolute left-[42px] top-[641px]"
        style={{ objectFit: "cover" }}
        src="gemini-generated-image-e-2-h-3-e-2-h-3-e-2-h-3-e-2-h-3-60.png"
      />
      <img
        className="rounded-[10px] w-[47px] h-[61px] absolute left-[253px] top-[641px]"
        style={{ objectFit: "cover", aspectRatio: "47/61" }}
        src="gemini-generated-image-e-2-h-3-e-2-h-3-e-2-h-3-e-2-h-3-50.png"
      />
      <img
        className="rounded-[10px] w-12 h-[60px] absolute left-[147px] top-[641px]"
        style={{ objectFit: "cover", aspectRatio: "48/60" }}
        src="gemini-generated-image-e-2-h-3-e-2-h-3-e-2-h-3-e-2-h-3-40.png"
      />
      <div className="text-[#000000] text-center font-['AsapCondensed-Medium',_sans-serif] text-[11px] font-medium absolute left-[255px] top-[696px]">
        Cica{" "}
      </div>
      <div className="text-[#000000] text-center font-['AsapCondensed-Medium',_sans-serif] text-[11px] font-medium absolute left-[149px] top-[696px]">
        Tea Tree{" "}
      </div>
      <div className="text-[#000000] text-center font-['AsapCondensed-Medium',_sans-serif] text-[11px] font-medium absolute left-[42px] top-[696px]">
        Salicylic Acid{" "}
      </div>
      <div className="bg-[#a5bfd0] rounded-[30px] w-[18px] h-[9px] absolute left-[99px] top-[697px]"></div>
      <div className="text-[#262d32] text-center font-['AsapCondensed-Medium',_sans-serif] text-[6px] font-medium absolute left-[102px] top-[698px]">
        각질{" "}
      </div>
      <div className="bg-[#b1e466] rounded-[30px] w-[18px] h-[9px] absolute left-[187px] top-[698px]"></div>
      <div className="text-[#465b28] text-center font-['AsapCondensed-Medium',_sans-serif] text-[6px] font-medium absolute left-[190px] top-[699px]">
        진정{" "}
      </div>
      <div className="bg-[#b2e661] rounded-[30px] w-[18px] h-[9px] absolute left-[275px] top-[698px]"></div>
      <div className="text-[#465b28] text-center font-['AsapCondensed-Medium',_sans-serif] text-[6px] font-medium absolute left-[278px] top-[699px]">
        재생{" "}
      </div>
      <div className="text-[#aaaaaa] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[6px] font-medium absolute left-[45px] top-[718px]">
        모공 속 피지와 <br />
        묵은 각질을 부드럽게 녹여줘요.{" "}
      </div>
      <div className="text-[#aaaaaa] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[6px] font-medium absolute left-[151px] top-[718px]">
        자극받은 염증 부위를 <br />
        빠르고 시원하게 진정시켜 줘요.{" "}
      </div>
      <div className="text-[#aaaaaa] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[6px] font-medium absolute left-[257px] top-[718px]">
        손상된 트러블 흔적과 <br />
        붉어진 장벽을 케어해 줘요.{" "}
      </div>
    </div>
  );
};
