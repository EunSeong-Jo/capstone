export interface IXProps {
  className?: string;
}

export const X = ({ className, ...props }: IXProps): JSX.Element => {
  return (
    <img
      className={"w-[17px] h-[17px] relative overflow-visible " + className}
      src="x.svg"
    />
  );
};
