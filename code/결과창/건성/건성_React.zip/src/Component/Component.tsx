import { LiquidGlassRegularSmallModeLightStateDefault } from "../LiquidGlassRegularSmallModeLightStateDefault/LiquidGlassRegularSmallModeLightStateDefault";
import { ChevronBackward } from "../ChevronBackward/ChevronBackward";
import { X } from "../X/X";
import { BuildingBlocksStatusBar } from "../BuildingBlocksStatusBar/BuildingBlocksStatusBar";

export interface IComponentProps {
  className?: string;
}

export const Component = ({
  className,
  ...props
}: IComponentProps): JSX.Element => {
  return (
    <div
      className={"bg-[#ffffff] h-[833px] relative overflow-hidden " + className}
    >
      <LiquidGlassRegularSmallModeLightStateDefault className="!absolute !right-[18px] !left-[19px] !bottom-[19px] !top-[766px] !w-[unset] !h-[unset]"></LiquidGlassRegularSmallModeLightStateDefault>
      <div className="text-[#ffffff] text-left font-['HankenGrotesk-Medium',_sans-serif] text-lg font-medium absolute left-[107px] top-[778px]">
        맞춤 스킨케어 추천 받기{" "}
      </div>
      <div className="text-[#000000] text-center font-['HankenGrotesk-Medium',_sans-serif] text-[15px] font-medium absolute left-1 top-[601px] w-[218px] h-[35px]">
        (캐릭터 이름) 추천하는 성분{" "}
      </div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Bold',_sans-serif] text-[19px] font-bold absolute left-[113px] top-[104px]">
        당신의 피부 타입은....{" "}
      </div>
      <div
        className="bg-[#eb9298] rounded-[50%] w-[29px] h-[29px] absolute left-[342px] top-[55px]"
        style={{ boxShadow: "0px 0px 3.8px 0px rgba(235, 146, 152, 1.00)" }}
      ></div>
      <div
        className="bg-[#eb9298] rounded-[50%] w-[29px] h-[29px] absolute left-[22px] top-[55px]"
        style={{ boxShadow: "0px 0px 3.8px 0px rgba(235, 146, 152, 1.00)" }}
      ></div>
      <ChevronBackward className="!h-[23px] !absolute !left-6 !top-[58px]"></ChevronBackward>
      <X className="!w-[17px] !h-[17px] !absolute !left-[348px] !top-[61px]"></X>
      <BuildingBlocksStatusBar
        cameraCutout={false}
        className="!w-[396px] !h-[37px] !absolute !left-[-2px] !top-0"
      ></BuildingBlocksStatusBar>
      <img
        className="rounded-[20px] border-solid border-[#d0ae91] border-[1.5px] w-[343px] h-[415px] absolute left-[26px] top-36"
        style={{ objectFit: "cover" }}
        src="chat-gpt-image-2026-7-13-04-00-13-20.png"
      />
      <div className="text-[#c98956] text-left font-['ClimateCrisis-1990',_sans-serif] text-[25px] font-normal absolute left-[133px] top-[193px] w-[130px] h-[33px]">
        건성피부{" "}
      </div>
      <img
        className="w-[154.89px] h-[142.39px] absolute left-[116.54px] top-[262.61px]"
        style={{ objectFit: "cover", aspectRatio: "154.89/142.39" }}
        src="kakao-talk-20260525-194504321-06-10.png"
      />
      <div className="bg-[#fcf6e9] w-[76.12px] h-[78.77px] absolute left-[277.32px] top-[180.7px]"></div>
      <div className="bg-[#c98956] rounded-[20px] w-[104px] h-[21px] absolute left-[146px] top-[164px]"></div>
      <div className="text-[#ffffff] text-left font-['HankenGrotesk-Medium',_sans-serif] text-xs font-medium absolute left-[156px] top-[167px] w-[113.69px] h-[33.62px]">
        바스락 사막 타입{" "}
      </div>
      <div className="bg-[#eff9b5] rounded-[15px] w-[79.01px] h-[24.88px] absolute left-[118px] top-[445px]"></div>
      <div className="bg-[#afafaf] rounded-[15px] w-[68.41px] h-[24.88px] absolute left-[207.6px] top-[445px]"></div>
      <div className="text-[#72b509] text-center font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[121px] top-[449px] w-[74px] h-[13.81px]">
        #유수분고갈{" "}
      </div>
      <div className="text-[#ffffff] text-center font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[209px] top-[449px] w-[65px] h-[13.81px]">
        #하얀각질{" "}
      </div>
      <div className="text-center font-['HankenGrotesk-Medium',_sans-serif] text-[15px] font-medium absolute left-[59px] top-[489px] w-[270.74px] h-[33.62px]">
        <span>
          <span className="div-10-span">
            아이고 목말라! 수분과 유분이 <br />
            모두 부족해
          </span>
          <span className="div-10-span2">영양이 필요한 타입</span>
          <span className="div-10-span">이에요</span>
        </span>{" "}
      </div>
      <div
        className="bg-[#ffffff] rounded-[10px] w-[93px] h-[113px] absolute left-10 top-[633px]"
        style={{ boxShadow: "0px 0px 13px -2px rgba(0, 0, 0, 0.25)" }}
      ></div>
      <div
        className="bg-[#ffffff] rounded-[10px] w-[93px] h-[113px] absolute left-36 top-[632px]"
        style={{ boxShadow: "0px 0px 13px -2px rgba(0, 0, 0, 0.25)" }}
      ></div>
      <div
        className="bg-[#ffffff] rounded-[10px] w-[93px] h-[113px] absolute left-[250px] top-[632px]"
        style={{ boxShadow: "0px 0px 13px -2px rgba(0, 0, 0, 0.25)" }}
      ></div>
      <img
        className="rounded-[10px] w-12 h-[59px] absolute left-[43px] top-[642px]"
        style={{ objectFit: "cover", aspectRatio: "48/59" }}
        src="gemini-generated-image-e-2-h-3-e-2-h-3-e-2-h-3-e-2-h-3-60.png"
      />
      <img
        className="rounded-[10px] w-[45px] h-[57px] absolute left-[149px] top-[642px]"
        style={{ objectFit: "cover" }}
        src="gemini-generated-image-e-2-h-3-e-2-h-3-e-2-h-3-e-2-h-3-40.png"
      />
      <div className="bg-[#b0d8f8] rounded-[30px] w-[27px] h-[9px] absolute left-[81px] top-[699px]"></div>
      <div className="text-[#017ce3] text-center font-['AsapCondensed-Medium',_sans-serif] text-[6px] font-medium absolute left-[83px] top-[700px]">
        강력보습{" "}
      </div>
      <div className="bg-[#f7de95] rounded-[30px] w-[27px] h-[9px] absolute left-[200px] top-[699px]"></div>
      <div className="text-[#7e620f] text-center font-['AsapCondensed-Medium',_sans-serif] text-[6px] font-medium absolute left-[202px] top-[700px]">
        영양공급{" "}
      </div>
      <img
        className="rounded-[10px] w-12 h-[61px] absolute left-64 top-[642px]"
        style={{ objectFit: "cover" }}
        src="gemini-generated-image-gaxc-9-sgaxc-9-sgaxc-20.png"
      />
      <div className="text-[#000000] text-center font-['AsapCondensed-Medium',_sans-serif] text-[11px] font-medium absolute left-[150px] top-[697px]">
        Shea Butter{" "}
      </div>
      <div className="text-[#000000] text-center font-['AsapCondensed-Medium',_sans-serif] text-[11px] font-medium absolute left-[45px] top-[697px]">
        Glycerin{" "}
      </div>
      <div className="text-[#000000] text-center font-['AsapCondensed-Medium',_sans-serif] text-[11px] font-medium absolute left-64 top-[697px]">
        Jojoba Oil{" "}
      </div>
      <div className="bg-[#fee475] rounded-[30px] w-[21px] h-[9px] absolute left-[300px] top-[699px]"></div>
      <div className="text-[#504100] text-center font-['AsapCondensed-Medium',_sans-serif] text-[6px] font-medium absolute left-[302px] top-[700px]">
        보습막{" "}
      </div>
      <div className="text-[#aaaaaa] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[6px] font-medium absolute left-11 top-[718px]">
        공기 중의 수분까지 끌어당겨
        <br />
        촉촉하고 깊은 보습을 줘요.{" "}
      </div>
      <div className="text-[#aaaaaa] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[6px] font-medium absolute left-[150px] top-[718px]">
        거친 각질을 부드럽게 잠재우고 <br />
        풍부한 영양을 채워줘요.{" "}
      </div>
      <div className="text-[#aaaaaa] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[6px] font-medium absolute left-64 top-[718px]">
        수분이 날아가지 않도록
        <br />
        든든한 유분 코팅막을 씌워줘요.{" "}
      </div>
    </div>
  );
};
