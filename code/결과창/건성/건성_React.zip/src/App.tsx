import "./styles.css";
import "./tailwind.css";
import { Component } from "./Component/Component";

export default function App() {
  return (
    <div>
      <Component />
    </div>
  );
}
