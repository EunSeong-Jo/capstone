export interface IBuildingBlocksStatusBarProps {
  cameraCutout?: boolean;
  className?: string;
}

export const BuildingBlocksStatusBar = ({
  cameraCutout = true,
  className,
  ...props
}: IBuildingBlocksStatusBarProps): JSX.Element => {
  return (
    <div
      className={
        "pt-2.5 pr-6 pb-2.5 pl-6 flex flex-row items-end justify-between h-[52px] relative " +
        className
      }
    >
      <div
        className="text-schemes-on-surface text-left font-['Roboto-Medium',_sans-serif] text-sm leading-5 font-medium relative flex items-center justify-start"
        style={{ letterSpacing: "0.01em" }}
      >
        9:30{" "}
      </div>
      <img
        className="shrink-0 w-[46px] h-[17px] relative overflow-visible"
        src="right-icons0.svg"
      />
      {cameraCutout && (
        <>
          <img
            className="shrink-0 w-6 h-6 absolute left-[50%] top-[18px] overflow-visible"
            style={{ translate: "-50%" }}
            src="camera-cutout0.svg"
          />
        </>
      )}
    </div>
  );
};
