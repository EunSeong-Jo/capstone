export interface ILiquidGlassRegularSmallModeLightStateDefaultProps {
  mode?: "light" | "dark";
  state?: "default" | "primary";
  className?: string;
}

export const LiquidGlassRegularSmallModeLightStateDefault = ({
  mode = "light",
  state = "default",
  className,
  ...props
}: ILiquidGlassRegularSmallModeLightStateDefaultProps): JSX.Element => {
  const variantsClassName = "mode-" + mode + " state-" + state;

  return (
    <div
      className={"w-12 h-12 relative " + className + " " + variantsClassName}
    >
      <div
        className="rounded-[296px] absolute right-0 left-0 bottom-0 top-0 overflow-hidden"
        style={{
          background:
            "linear-gradient(to left, #f7f7f7, #f7f7f7), linear-gradient(to left, #dddddd, #dddddd), linear-gradient(to left, rgba(255, 255, 255, 0.65), rgba(255, 255, 255, 0.65))",
          boxShadow: "0px 8px 40px 0px rgba(0, 0, 0, 0.12)",
        }}
      ></div>
      <div className="bg-[rgba(0,0,0,0.00)] rounded-[296px] absolute right-0 left-0 bottom-0 top-0 overflow-hidden"></div>
    </div>
  );
};
