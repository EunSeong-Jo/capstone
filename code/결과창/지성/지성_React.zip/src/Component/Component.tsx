import { LiquidGlassRegularSmallModeLightStateDefault } from "../LiquidGlassRegularSmallModeLightStateDefault/LiquidGlassRegularSmallModeLightStateDefault";
import { ChevronBackward } from "../ChevronBackward/ChevronBackward";
import { X } from "../X/X";
import { BuildingBlocksStatusBar } from "../BuildingBlocksStatusBar/BuildingBlocksStatusBar";

export interface IComponentProps {
  className?: string;
}

export const Component = ({
  className,
  ...props
}: IComponentProps): JSX.Element => {
  return (
    <div
      className={"bg-[#ffffff] h-[833px] relative overflow-hidden " + className}
    >
      <LiquidGlassRegularSmallModeLightStateDefault className="!absolute !right-[18px] !left-[19px] !bottom-[19px] !top-[766px] !w-[unset] !h-[unset]"></LiquidGlassRegularSmallModeLightStateDefault>
      <div className="text-[#ffffff] text-left font-['HankenGrotesk-Medium',_sans-serif] text-lg font-medium absolute left-[107px] top-[778px]">
        맞춤 스킨케어 추천 받기{" "}
      </div>
      <div className="text-[#000000] text-center font-['HankenGrotesk-Medium',_sans-serif] text-[15px] font-medium absolute left-1 top-[601px] w-[218px] h-[35px]">
        (캐릭터 이름) 추천하는 성분{" "}
      </div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Bold',_sans-serif] text-[19px] font-bold absolute left-[113px] top-[104px]">
        당신의 피부 타입은....{" "}
      </div>
      <div
        className="bg-[#eb9298] rounded-[50%] w-[29px] h-[29px] absolute left-[342px] top-[55px]"
        style={{ boxShadow: "0px 0px 3.8px 0px rgba(235, 146, 152, 1.00)" }}
      ></div>
      <div
        className="bg-[#eb9298] rounded-[50%] w-[29px] h-[29px] absolute left-[22px] top-[55px]"
        style={{ boxShadow: "0px 0px 3.8px 0px rgba(235, 146, 152, 1.00)" }}
      ></div>
      <ChevronBackward className="!h-[23px] !absolute !left-6 !top-[58px]"></ChevronBackward>
      <X className="!w-[17px] !h-[17px] !absolute !left-[348px] !top-[61px]"></X>
      <BuildingBlocksStatusBar
        cameraCutout={false}
        className="!w-[396px] !h-[37px] !absolute !left-[-2px] !top-0"
      ></BuildingBlocksStatusBar>
      <img
        className="rounded-[20px] border-solid border-[#ffd788] border-[1.5px] w-[343px] h-[416px] absolute left-[26px] top-36"
        style={{ objectFit: "cover" }}
        src="chat-gpt-image-2026-7-13-04-00-13-80.png"
      />
      <div className="text-[#ffa900] text-left font-['ClimateCrisis-1990',_sans-serif] text-[25px] font-normal absolute left-[131px] top-48 w-[132px] h-[34px]">
        지성피부{" "}
      </div>
      <img
        className="w-[175.06px] h-[142.36px] absolute left-[103px] top-[266px]"
        style={{ objectFit: "cover", aspectRatio: "175.06/142.36" }}
        src="kakao-talk-20260525-194504321-08-10.png"
      />
      <div className="bg-[#fefbeb] w-[75.9px] h-[85.7px] absolute left-[282.49px] top-[176.81px]"></div>
      <div className="bg-[#ffa900] rounded-[20px] w-[120px] h-[21px] absolute left-[137px] top-[164px]"></div>
      <div className="text-[#ffffff] text-left font-['HankenGrotesk-Medium',_sans-serif] text-xs font-medium absolute left-[145.14px] top-[167.11px] w-[113.37px] h-[15.41px]">
        반질반질 산유국 타입{" "}
      </div>
      <div className="text-center font-['HankenGrotesk-Medium',_sans-serif] text-[15px] font-medium absolute left-[58px] top-[488px] w-[279.26px] h-[33.7px]">
        <span>
          <span className="div-8-span">
            유전이 터졌다! 피지 분비가 활발해서 <br />
            언제나 얼굴에 광이 도는
          </span>
          <span className="div-8-span2">산유국 타입</span>
          <span className="div-8-span">이에요</span>
        </span>{" "}
      </div>
      <div className="bg-[#fff2b3] rounded-[15px] w-[71.26px] h-[25.04px] absolute left-[119px] top-[443px]"></div>
      <div className="bg-[#d9d9d9] rounded-[15px] w-[71.26px] h-[25.04px] absolute left-[205.67px] top-[443px]"></div>
      <div className="text-[#b59e06] text-center font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[125.59px] top-[447px] w-[59px] h-3.5">
        #유전폭발{" "}
      </div>
      <div className="text-[#4a4a4a] text-center font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[211px] top-[447px] w-[61px] h-3.5">
        #모공확장{" "}
      </div>
      <div
        className="bg-[#ffffff] rounded-[10px] w-[93px] h-[113px] absolute left-[38px] top-[632px]"
        style={{ boxShadow: "0px 0px 13px -2px rgba(0, 0, 0, 0.25)" }}
      ></div>
      <div
        className="bg-[#ffffff] rounded-[10px] w-[93px] h-[113px] absolute left-36 top-[632px]"
        style={{ boxShadow: "0px 0px 13px -2px rgba(0, 0, 0, 0.25)" }}
      ></div>
      <div
        className="bg-[#ffffff] rounded-[10px] w-[93px] h-[113px] absolute left-[250px] top-[632px]"
        style={{ boxShadow: "0px 0px 13px -2px rgba(0, 0, 0, 0.25)" }}
      ></div>
      <img
        className="rounded-[10px] w-[45px] h-[57px] absolute left-[41px] top-[641px]"
        style={{ objectFit: "cover", aspectRatio: "45/57" }}
        src="gemini-generated-image-e-2-h-3-e-2-h-3-e-2-h-3-e-2-h-3-60.png"
      />
      <img
        className="rounded-[10px] w-[47px] h-[61px] absolute left-[253px] top-[641px]"
        style={{ objectFit: "cover", aspectRatio: "47/61" }}
        src="gemini-generated-image-e-2-h-3-e-2-h-3-e-2-h-3-e-2-h-3-50.png"
      />
      <img
        className="rounded-[10px] w-[45px] h-[60px] absolute left-[147px] top-[641px]"
        style={{ objectFit: "cover", aspectRatio: "45/60" }}
        src="gemini-generated-image-e-2-h-3-e-2-h-3-e-2-h-3-e-2-h-3-40.png"
      />
      <div className="text-[#000000] text-center font-['AsapCondensed-Medium',_sans-serif] text-[11px] font-medium absolute left-[43px] top-[696px]">
        Niacinamide{" "}
      </div>
      <div className="text-[#000000] text-center font-['AsapCondensed-Medium',_sans-serif] text-[11px] font-medium absolute left-[148px] top-[696px]">
        Zinc PCA{" "}
      </div>
      <div className="text-[#000000] text-center font-['AsapCondensed-Medium',_sans-serif] text-[11px] font-medium absolute left-[253px] top-[695px]">
        Green Tea{" "}
      </div>
      <div className="bg-[#a9d7fa] rounded-[30px] w-[27px] h-[9px] absolute left-[98px] top-[698px]"></div>
      <div className="text-[#017ce3] text-center font-['AsapCondensed-Medium',_sans-serif] text-[6px] font-medium absolute left-[100px] top-[699px]">
        피지조절{" "}
      </div>
      <div className="bg-[#c3c8ce] rounded-[30px] w-8 h-[9px] absolute left-[186px] top-[698px]"></div>
      <div className="text-[#272728] text-center font-['AsapCondensed-Medium',_sans-serif] text-[6px] font-medium absolute left-[188px] top-[699px]">
        유분컨트롤{" "}
      </div>
      <div className="bg-[#9bdcd2] rounded-[30px] w-[27px] h-[9px] absolute left-[298px] top-[697px]"></div>
      <div className="text-[#00473c] text-center font-['AsapCondensed-Medium',_sans-serif] text-[6px] font-medium absolute left-[300px] top-[698px]">
        산뜻수분{" "}
      </div>
      <div className="text-[#aaaaaa] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[6px] font-medium absolute left-[45px] top-[718px]">
        과도한 유분 분비를 <br />
        줄이고 넓어진 모공을 케어해요.{" "}
      </div>
      <div className="text-[#aaaaaa] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[6px] font-medium absolute left-[151px] top-[718px]">
        번들거리는 피지를
        <br />
        잡아 피부를 보송하게 만들어요.{" "}
      </div>
      <div className="text-[#aaaaaa] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[6px] font-medium absolute left-[257px] top-[718px]">
        무겁지 않게 수분을
        <br />
        채우고 유분을 맑게 정돈해요.{" "}
      </div>
    </div>
  );
};
