import { LiquidGlassRegularSmallModeLightStateDefault } from "../LiquidGlassRegularSmallModeLightStateDefault/LiquidGlassRegularSmallModeLightStateDefault";
import { ChevronBackward } from "../ChevronBackward/ChevronBackward";
import { X } from "../X/X";
import { BuildingBlocksStatusBar } from "../BuildingBlocksStatusBar/BuildingBlocksStatusBar";

export interface IComponentProps {
  className?: string;
}

export const Component = ({
  className,
  ...props
}: IComponentProps): JSX.Element => {
  return (
    <div
      className={"bg-[#ffffff] h-[833px] relative overflow-hidden " + className}
    >
      <LiquidGlassRegularSmallModeLightStateDefault className="!absolute !right-[18px] !left-[19px] !bottom-[19px] !top-[766px] !w-[unset] !h-[unset]"></LiquidGlassRegularSmallModeLightStateDefault>
      <div className="text-[#ffffff] text-left font-['HankenGrotesk-Medium',_sans-serif] text-lg font-medium absolute left-[107px] top-[778px]">
        맞춤 스킨케어 추천 받기{" "}
      </div>
      <div className="text-[#000000] text-center font-['HankenGrotesk-Medium',_sans-serif] text-[15px] font-medium absolute left-1 top-[601px] w-[218px] h-[35px]">
        (캐릭터 이름) 추천하는 성분{" "}
      </div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Bold',_sans-serif] text-[19px] font-bold absolute left-[113px] top-[104px]">
        당신의 피부 타입은....{" "}
      </div>
      <div
        className="bg-[#eb9298] rounded-[50%] w-[29px] h-[29px] absolute left-[342px] top-[55px]"
        style={{ boxShadow: "0px 0px 3.8px 0px rgba(235, 146, 152, 1.00)" }}
      ></div>
      <div
        className="bg-[#eb9298] rounded-[50%] w-[29px] h-[29px] absolute left-[22px] top-[55px]"
        style={{ boxShadow: "0px 0px 3.8px 0px rgba(235, 146, 152, 1.00)" }}
      ></div>
      <ChevronBackward className="!h-[23px] !absolute !left-6 !top-[58px]"></ChevronBackward>
      <X className="!w-[17px] !h-[17px] !absolute !left-[348px] !top-[61px]"></X>
      <BuildingBlocksStatusBar
        cameraCutout={false}
        className="!w-[396px] !h-[37px] !absolute !left-[-2px] !top-0"
      ></BuildingBlocksStatusBar>
      <img
        className="rounded-[20px] border-solid border-[#ffa693] border-[1.5px] w-[343px] h-[416px] absolute left-[26px] top-36"
        style={{ objectFit: "cover" }}
        src="chat-gpt-image-2026-7-13-04-00-13-50.png"
      />
      <img
        className="w-[168.56px] h-[156.04px] absolute left-[116.81px] top-[258.9px]"
        style={{ objectFit: "cover", aspectRatio: "168.56/156.04" }}
        src="kakao-talk-20260525-194504321-07-10.png"
      />
      <div className="text-[#ff7063] text-left font-['ClimateCrisis-1990',_sans-serif] text-[25px] font-normal absolute left-[121px] top-48 w-[164px] h-[34px]">
        민감성 피부{" "}
      </div>
      <div className="bg-[#ff7063] rounded-[20px] w-[130px] h-[21px] absolute left-[137px] top-[164px]"></div>
      <div className="text-[#ffffff] text-left font-['HankenGrotesk-Medium',_sans-serif] text-xs font-medium absolute left-[143px] top-[167px] w-[119px] h-[33px]">
        조심조심 유리구슬 타입{" "}
      </div>
      <div className="bg-[#fdf4f3] w-[76.12px] h-[97.26px] absolute left-[281px] top-[151px]"></div>
      <div className="text-center font-['HankenGrotesk-Medium',_sans-serif] text-[15px] font-medium absolute left-[59px] top-[487px] w-[279.26px] h-[33.7px]">
        <span>
          <span className="div-8-span">
            앗 차가워, 앗 뜨거워! 작은 자극에도
            <br /> 쉽게 깜짝 놀라는
          </span>
          <span className="div-8-span2">예민한 타입</span>
          <span className="div-8-span">이에요</span>
        </span>{" "}
      </div>
      <div className="bg-[rgba(255,220,187,0.97)] rounded-[15px] w-[71.26px] h-[25.04px] absolute left-[123px] top-[442px]"></div>
      <div className="bg-[#ffdbd4] rounded-[15px] w-[71.26px] h-[25.04px] absolute left-[209.67px] top-[442px]"></div>
      <div className="text-[#ff8c00] text-center font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[129.26px] top-[446.59px] w-[59px] h-[15px]">
        #장벽붕괴{" "}
      </div>
      <div className="text-[#ff4a4a] text-center font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[221px] top-[446px] w-12 h-3.5">
        #따가움{" "}
      </div>
      <div
        className="bg-[#ffffff] rounded-[10px] w-[93px] h-[113px] absolute left-[38px] top-[632px]"
        style={{ boxShadow: "0px 0px 13px -2px rgba(0, 0, 0, 0.25)" }}
      ></div>
      <div
        className="bg-[#ffffff] rounded-[10px] w-[93px] h-[113px] absolute left-36 top-[632px]"
        style={{ boxShadow: "0px 0px 13px -2px rgba(0, 0, 0, 0.25)" }}
      ></div>
      <div
        className="bg-[#ffffff] rounded-[10px] w-[93px] h-[113px] absolute left-[250px] top-[632px]"
        style={{ boxShadow: "0px 0px 13px -2px rgba(0, 0, 0, 0.25)" }}
      ></div>
      <img
        className="rounded-[10px] w-[46px] h-[54px] absolute left-10 top-[641px]"
        style={{ objectFit: "cover", aspectRatio: "46/54" }}
        src="gemini-generated-image-e-2-h-3-e-2-h-3-e-2-h-3-e-2-h-3-60.png"
      />
      <img
        className="rounded-[10px] w-[46px] h-[62px] absolute left-[253px] top-[641px]"
        style={{ objectFit: "cover", aspectRatio: "46/62" }}
        src="gemini-generated-image-e-2-h-3-e-2-h-3-e-2-h-3-e-2-h-3-50.png"
      />
      <img
        className="rounded-[10px] w-[45px] h-[60px] absolute left-[147px] top-[641px]"
        style={{ objectFit: "cover", aspectRatio: "45/60" }}
        src="gemini-generated-image-e-2-h-3-e-2-h-3-e-2-h-3-e-2-h-3-40.png"
      />
      <div className="text-[#000000] text-center font-['AsapCondensed-Medium',_sans-serif] text-[11px] font-medium absolute left-[149px] top-[696px]">
        Allantoin{" "}
      </div>
      <div className="text-[#000000] text-center font-['AsapCondensed-Medium',_sans-serif] text-[11px] font-medium absolute left-[43px] top-[696px]">
        Ceramide{" "}
      </div>
      <div className="text-[#000000] text-center font-['AsapCondensed-Medium',_sans-serif] text-[10px] font-medium absolute left-[254px] top-[696px]">
        Madecassoside{" "}
      </div>
      <div className="bg-[#fddf6d] rounded-[30px] w-[29px] h-[9px] absolute left-[84px] top-[698px]"></div>
      <div className="text-[#856900] text-center font-['AsapCondensed-Medium',_sans-serif] text-[6px] font-medium absolute left-[87px] top-[699px]">
        장벽강화{" "}
      </div>
      <div className="bg-[#d798f7] rounded-[30px] w-[27px] h-[9px] absolute left-[190px] top-[698px]"></div>
      <div className="text-[#5b2278] text-center font-['AsapCondensed-Medium',_sans-serif] text-[6px] font-medium absolute left-48 top-[699px]">
        자극완화{" "}
      </div>
      <div className="bg-[#bbed7c] rounded-[30px] w-[27px] h-[9px] absolute left-[314px] top-[697px]"></div>
      <div className="text-[#355c04] text-center font-['AsapCondensed-Medium',_sans-serif] text-[6px] font-medium absolute left-[316px] top-[698px]">
        자극케어{" "}
      </div>
      <div className="text-[#aaaaaa] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[6px] font-medium absolute left-[43px] top-[718px]">
        무너진 피부 장벽 사이를 <br />
        촘촘하게 메워 보호막을 세워줘요.{" "}
      </div>
      <div className="text-[#aaaaaa] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[6px] font-medium absolute left-[149px] top-[718px]">
        예민해진 피부 자극을 <br />
        완화하고 부드럽게 진정시켜요.{" "}
      </div>
      <div className="text-[#aaaaaa] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[6px] font-medium absolute left-[255px] top-[718px]">
        외부 자극으로 붉어진 피부를 <br />
        편안하고 평온하게 만들어요.{" "}
      </div>
    </div>
  );
};
