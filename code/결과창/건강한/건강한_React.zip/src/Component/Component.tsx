import { LiquidGlassRegularSmallModeLightStateDefault } from "../LiquidGlassRegularSmallModeLightStateDefault/LiquidGlassRegularSmallModeLightStateDefault";
import { ChevronBackward } from "../ChevronBackward/ChevronBackward";
import { X } from "../X/X";
import { BuildingBlocksStatusBar } from "../BuildingBlocksStatusBar/BuildingBlocksStatusBar";

export interface IComponentProps {
  className?: string;
}

export const Component = ({
  className,
  ...props
}: IComponentProps): JSX.Element => {
  return (
    <div
      className={"bg-[#ffffff] h-[833px] relative overflow-hidden " + className}
    >
      <LiquidGlassRegularSmallModeLightStateDefault className="!absolute !right-[18px] !left-[19px] !bottom-[19px] !top-[766px] !w-[unset] !h-[unset]"></LiquidGlassRegularSmallModeLightStateDefault>
      <div className="text-[#ffffff] text-left font-['HankenGrotesk-Medium',_sans-serif] text-lg font-medium absolute left-[107px] top-[778px]">
        맞춤 스킨케어 추천 받기{" "}
      </div>
      <div className="text-[#000000] text-center font-['HankenGrotesk-Medium',_sans-serif] text-[15px] font-medium absolute left-1 top-[601px] w-[218px] h-[35px]">
        (캐릭터 이름) 추천하는 성분{" "}
      </div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Bold',_sans-serif] text-[19px] font-bold absolute left-[113px] top-[104px]">
        당신의 피부 타입은....{" "}
      </div>
      <div
        className="bg-[#eb9298] rounded-[50%] w-[29px] h-[29px] absolute left-[342px] top-[55px]"
        style={{ boxShadow: "0px 0px 3.8px 0px rgba(235, 146, 152, 1.00)" }}
      ></div>
      <div
        className="bg-[#eb9298] rounded-[50%] w-[29px] h-[29px] absolute left-[22px] top-[55px]"
        style={{ boxShadow: "0px 0px 3.8px 0px rgba(235, 146, 152, 1.00)" }}
      ></div>
      <ChevronBackward className="!h-[23px] !absolute !left-6 !top-[58px]"></ChevronBackward>
      <X className="!w-[17px] !h-[17px] !absolute !left-[348px] !top-[61px]"></X>
      <BuildingBlocksStatusBar
        cameraCutout={false}
        className="!w-[396px] !h-[37px] !absolute !left-[-2px] !top-0"
      ></BuildingBlocksStatusBar>
      <img
        className="rounded-[20px] border-solid border-[#bad8f3] border-[1.5px] w-[343px] h-[416px] absolute left-[26px] top-36"
        style={{ objectFit: "cover" }}
        src="chat-gpt-image-2026-7-13-04-00-13-40.png"
      />
      <img
        className="w-[185px] h-[170px] absolute left-[100px] top-[248px]"
        style={{ objectFit: "cover", aspectRatio: "185/170" }}
        src="kakao-talk-20260525-194504321-04-10.png"
      />
      <div className="bg-[#ecf4fd] w-[63px] h-[82px] absolute left-[289px] top-[170px]"></div>
      <div className="bg-[#0088ff] rounded-[20px] w-[124px] h-[21px] absolute left-[135px] top-[164px]"></div>
      <div className="text-[#ffffff] text-left font-['HankenGrotesk-Medium',_sans-serif] text-xs font-medium absolute left-[143px] top-[167px] w-[118px] h-[35px]">
        수분 팡팡 옹달샘 타입{" "}
      </div>
      <div className="text-[#0088ff] text-left font-['ClimateCrisis-1990',_sans-serif] text-[25px] font-normal absolute left-[116px] top-48 w-[169px] h-[35px]">
        건강한 피부{" "}
      </div>
      <div className="bg-[#f4dfa6] rounded-[15px] w-[71px] h-[25px] absolute left-[118px] top-[451px]"></div>
      <div className="bg-[#9ceafc] rounded-[15px] w-[71px] h-[25px] absolute left-[205px] top-[451px]"></div>
      <div className="text-[#edad00] text-center font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[125px] top-[455px] w-[57px] h-[14.17px]">
        #황금비율{" "}
      </div>
      <div className="text-[#11505e] text-center font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[212px] top-[455px] w-[57px] h-[14.17px]">
        #맑은피부{" "}
      </div>
      <div className="text-center font-['HankenGrotesk-Medium',_sans-serif] text-[15px] font-medium absolute left-[57px] top-[493px] w-[281px] h-[35px]">
        <span>
          <span className="div-10-span">
            축하합니다! 유수분 밸런스가 완벽해 <br />
          </span>
          <span className="div-10-span2">촉촉함을 머금고 있는 타입이에요</span>
        </span>{" "}
      </div>
      <div
        className="bg-[#ffffff] rounded-[10px] w-[93px] h-[113px] absolute left-[38px] top-[632px]"
        style={{ boxShadow: "0px 0px 13px -2px rgba(0, 0, 0, 0.25)" }}
      ></div>
      <div
        className="bg-[#ffffff] rounded-[10px] w-[93px] h-[113px] absolute left-36 top-[632px]"
        style={{ boxShadow: "0px 0px 13px -2px rgba(0, 0, 0, 0.25)" }}
      ></div>
      <div
        className="bg-[#ffffff] rounded-[10px] w-[93px] h-[113px] absolute left-[250px] top-[632px]"
        style={{ boxShadow: "0px 0px 13px -2px rgba(0, 0, 0, 0.25)" }}
      ></div>
      <div className="text-[#000000] text-center font-['AsapCondensed-Medium',_sans-serif] text-[11px] font-medium absolute left-[43px] top-[696px]">
        Beta-Glucan{" "}
      </div>
      <div className="text-[#000000] text-center font-['AsapCondensed-Medium',_sans-serif] text-[11px] font-medium absolute left-[150px] top-[696px]">
        Tocopherol{" "}
      </div>
      <div className="text-[#000000] text-center font-['AsapCondensed-Medium',_sans-serif] text-[10px] font-medium absolute left-[255px] top-[696px]">
        Thermal Water{" "}
      </div>
      <div className="bg-[#b7d4f0] rounded-[30px] w-[25px] h-[9px] absolute left-[95px] top-[698px]"></div>
      <div className="text-[#017ce3] text-center font-['AsapCondensed-Medium',_sans-serif] text-[6px] font-medium absolute left-24 top-[699px]">
        기초건강{" "}
      </div>
      <div className="bg-[#9fd6c3] rounded-[30px] w-[21px] h-[9px] absolute left-[199px] top-[698px]"></div>
      <div className="text-[#0d6d1e] text-center font-['AsapCondensed-Medium',_sans-serif] text-[6px] font-medium absolute left-[201px] top-[699px]">
        향산화{" "}
      </div>
      <img
        className="rounded-none w-[27px] h-[9px] absolute left-[313px] top-[697px] overflow-visible"
        src="rectangle-1292.svg"
      />
      <div className="text-[#2b7372] text-center font-['AsapCondensed-Medium',_sans-serif] text-[6px] font-medium absolute left-[315px] top-[698px]">
        수분공급{" "}
      </div>
      <img
        className="rounded-[10px] w-[42px] h-[53px] absolute left-[42px] top-[641px]"
        style={{ objectFit: "cover" }}
        src="gemini-generated-image-6-rzepv-6-rzepv-6-rze-10.png"
      />
      <img
        className="rounded-[10px] w-11 h-14 absolute left-[148px] top-[640px]"
        style={{ objectFit: "cover" }}
        src="gemini-generated-image-6-rzepv-6-rzepv-6-rze-20.png"
      />
      <img
        className="rounded-[10px] w-[46px] h-[59px] absolute left-[254px] top-[640px]"
        style={{ objectFit: "cover" }}
        src="gemini-generated-image-6-rzepv-6-rzepv-6-rze-30.png"
      />
      <div className="text-[#aaaaaa] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[6px] font-medium absolute left-[42px] top-[718px]">
        수분 보존력을 높이고
        <br />
        외부 방어력을 탄탄하게 키워줘요.{" "}
      </div>
      <div className="text-[#aaaaaa] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[6px] font-medium absolute left-[148px] top-[718px]">
        생기 있는 맑은 피부 컨디션을 <br />
        오래오래 유지해 줘요.{" "}
      </div>
      <div className="text-[#aaaaaa] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[6px] font-medium absolute left-[254px] top-[718px]">
        자극 없이 편안한 <br />
        미네랄 수분을 촉촉하게 공급해요.{" "}
      </div>
    </div>
  );
};
