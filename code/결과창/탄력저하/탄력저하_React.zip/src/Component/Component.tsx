import { LiquidGlassRegularSmallModeLightStateDefault } from "../LiquidGlassRegularSmallModeLightStateDefault/LiquidGlassRegularSmallModeLightStateDefault";
import { ChevronBackward } from "../ChevronBackward/ChevronBackward";
import { X } from "../X/X";
import { BuildingBlocksStatusBar } from "../BuildingBlocksStatusBar/BuildingBlocksStatusBar";

export interface IComponentProps {
  className?: string;
}

export const Component = ({
  className,
  ...props
}: IComponentProps): JSX.Element => {
  return (
    <div
      className={"bg-[#ffffff] h-[833px] relative overflow-hidden " + className}
    >
      <LiquidGlassRegularSmallModeLightStateDefault className="!absolute !right-[18px] !left-[19px] !bottom-[19px] !top-[766px] !w-[unset] !h-[unset]"></LiquidGlassRegularSmallModeLightStateDefault>
      <div className="text-[#ffffff] text-left font-['HankenGrotesk-Medium',_sans-serif] text-lg font-medium absolute left-[107px] top-[778px]">
        맞춤 스킨케어 추천 받기{" "}
      </div>
      <div className="text-[#000000] text-center font-['HankenGrotesk-Medium',_sans-serif] text-[15px] font-medium absolute left-1 top-[601px] w-[218px] h-[35px]">
        (캐릭터 이름) 추천하는 성분{" "}
      </div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Bold',_sans-serif] text-[19px] font-bold absolute left-[113px] top-[104px]">
        당신의 피부 타입은....{" "}
      </div>
      <div
        className="bg-[#eb9298] rounded-[50%] w-[29px] h-[29px] absolute left-[342px] top-[55px]"
        style={{ boxShadow: "0px 0px 3.8px 0px rgba(235, 146, 152, 1.00)" }}
      ></div>
      <div
        className="bg-[#eb9298] rounded-[50%] w-[29px] h-[29px] absolute left-[22px] top-[55px]"
        style={{ boxShadow: "0px 0px 3.8px 0px rgba(235, 146, 152, 1.00)" }}
      ></div>
      <ChevronBackward className="!h-[23px] !absolute !left-6 !top-[58px]"></ChevronBackward>
      <X className="!w-[17px] !h-[17px] !absolute !left-[348px] !top-[61px]"></X>
      <BuildingBlocksStatusBar
        cameraCutout={false}
        className="!w-[396px] !h-[37px] !absolute !left-[-2px] !top-0"
      ></BuildingBlocksStatusBar>
      <img
        className="rounded-[20px] border-solid border-[#ffc978] border-[1.5px] w-[344px] h-[416px] absolute left-[26px] top-36"
        style={{ objectFit: "cover" }}
        src="chat-gpt-image-2026-7-13-04-00-13-60.png"
      />
      <img
        className="w-[182.31px] h-[153.38px] absolute left-[106.39px] top-[251.94px]"
        style={{ objectFit: "cover", aspectRatio: "182.31/153.38" }}
        src="kakao-talk-20260525-194504321-10-10.png"
      />
      <div className="bg-[#fef8eb] w-[65.71px] h-[78.96px] absolute left-[294.66px] top-[160.81px]"></div>
      <div className="bg-[#ff9c00] rounded-[20px] w-[120px] h-[21px] absolute left-[138px] top-[164px]"></div>
      <div className="text-[#ffffff] text-left font-['HankenGrotesk-Medium',_sans-serif] text-xs font-medium absolute left-[149.62px] top-[167.11px] w-[114.02px] h-[33.7px]">
        축 처진 인절미 타입{" "}
      </div>
      <div className="bg-[#d4e6f4] rounded-[15px] w-[68.61px] h-[25px] absolute left-[121px] top-[451px]"></div>
      <div className="bg-[#ded1e1] rounded-[15px] w-[68.61px] h-[25px] absolute left-[205.07px] top-[451px]"></div>
      <div className="text-[#047ad7] text-center font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[124px] top-[455px] w-[62px] h-[14.71px]">
        #탄력저하{" "}
      </div>
      <div className="text-[#9166ff] text-center font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[202px] top-[455px] w-[74px] h-[14.71px]">
        #미세주름{" "}
      </div>
      <div className="text-center font-['HankenGrotesk-Medium',_sans-serif] text-[15px] font-medium absolute left-[60px] top-[492px] w-[271.53px] h-[33.7px]">
        <span>
          <span className="div-9-span">
            탱탱함이 필요해! 중력의 영향을 받아 <br />
          </span>
          <span className="div-9-span2">
            탄력이 떨어지고 주름이 고민인 타입
          </span>
          <span className="div-9-span">이에요</span>
        </span>{" "}
      </div>
      <div className="text-[#ff9c00] text-left font-['ClimateCrisis-1990',_sans-serif] text-[25px] font-normal absolute left-[109px] top-48 w-[194px] h-[34px]">
        탄력저하피부{" "}
      </div>
      <div
        className="bg-[#ffffff] rounded-[10px] w-[93px] h-[113px] absolute left-[38px] top-[632px]"
        style={{ boxShadow: "0px 0px 13px -2px rgba(0, 0, 0, 0.25)" }}
      ></div>
      <div
        className="bg-[#ffffff] rounded-[10px] w-[93px] h-[113px] absolute left-36 top-[632px]"
        style={{ boxShadow: "0px 0px 13px -2px rgba(0, 0, 0, 0.25)" }}
      ></div>
      <div
        className="bg-[#ffffff] rounded-[10px] w-[93px] h-[113px] absolute left-[250px] top-[632px]"
        style={{ boxShadow: "0px 0px 13px -2px rgba(0, 0, 0, 0.25)" }}
      ></div>
      <div className="text-[#000000] text-center font-['AsapCondensed-Medium',_sans-serif] text-[11px] font-medium absolute left-11 top-[697px]">
        Retinol{" "}
      </div>
      <div className="text-[#000000] text-center font-['AsapCondensed-Medium',_sans-serif] text-[11px] font-medium absolute left-[150px] top-[697px]">
        Peptide{" "}
      </div>
      <div className="text-[#000000] text-center font-['AsapCondensed-Medium',_sans-serif] text-[11px] font-medium absolute left-[257px] top-[697px]">
        Adenosine{" "}
      </div>
      <div className="bg-[#f7d89a] rounded-[30px] w-[27px] h-[9px] absolute left-[77px] top-[699px]"></div>
      <div className="text-[#6c5c3d] text-center font-['AsapCondensed-Medium',_sans-serif] text-[6px] font-medium absolute left-[79px] top-[700px]">
        주름개선{" "}
      </div>
      <div className="bg-[#bac9d5] rounded-[30px] w-8 h-[9px] absolute left-[184px] top-[699px]"></div>
      <div className="text-[#497599] text-center font-['AsapCondensed-Medium',_sans-serif] text-[6px] font-medium absolute left-[186px] top-[700px]">
        탄력부스팅{" "}
      </div>
      <div className="bg-[#c2bbdd] rounded-[30px] w-[27px] h-[9px] absolute left-[304px] top-[699px]"></div>
      <div className="text-[#544688] text-center font-['AsapCondensed-Medium',_sans-serif] text-[6px] font-medium absolute left-[306px] top-[700px]">
        링클케어{" "}
      </div>
      <img
        className="rounded-[10px] w-11 h-14 absolute left-[42px] top-[641px]"
        style={{ objectFit: "cover" }}
        src="gemini-generated-image-6-rzepv-6-rzepv-6-rze-10.png"
      />
      <img
        className="rounded-[10px] w-11 h-14 absolute left-[148px] top-[640px]"
        style={{ objectFit: "cover" }}
        src="gemini-generated-image-6-rzepv-6-rzepv-6-rze-20.png"
      />
      <img
        className="rounded-[10px] w-11 h-14 absolute left-[254px] top-[640px]"
        style={{ objectFit: "cover" }}
        src="gemini-generated-image-6-rzepv-6-rzepv-6-rze-30.png"
      />
      <div className="text-[#aaaaaa] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[6px] font-medium absolute left-[42px] top-[718px]">
        피부 턴오버를 촉진해 눈가와 입가 <br />
        잔주름을 팽팽하게 케어해요.{" "}
      </div>
      <div className="text-[#aaaaaa] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[6px] font-medium absolute left-[149px] top-[718px]">
        느슨해진 피부 조직에 <br />
        쫀쫀하고 탄탄한 힘을 채워줘요.{" "}
      </div>
      <div className="text-[#aaaaaa] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[6px] font-medium absolute left-[255px] top-[718px]">
        피부 스스로의 자생력을 높여 <br />
        처진 페이스라인을 잡아줘요.{" "}
      </div>
    </div>
  );
};
