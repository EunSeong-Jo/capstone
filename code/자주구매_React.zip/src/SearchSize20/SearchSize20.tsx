export interface ISearchSize20Props {
  size?: "20" | "24" | "32" | "40" | "48" | "16";
  className?: string;
}

export const SearchSize20 = ({
  size = "48",
  className,
  ...props
}: ISearchSize20Props): JSX.Element => {
  const variantsClassName = "size-" + size;

  return (
    <img
      className={
        "w-[23px] h-[23px] relative overflow-visible " +
        className +
        " " +
        variantsClassName
      }
      src="search-size-20.svg"
    />
  );
};
