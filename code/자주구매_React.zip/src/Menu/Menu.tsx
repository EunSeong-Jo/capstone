export interface IMenuProps {
  className?: string;
}

export const Menu = ({ className, ...props }: IMenuProps): JSX.Element => {
  return (
    <img
      className={"w-[30px] h-[30px] relative overflow-visible " + className}
      src="menu.svg"
    />
  );
};
