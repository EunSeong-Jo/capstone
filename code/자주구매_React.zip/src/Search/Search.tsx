export interface ISearchProps {
  className?: string;
}

export const Search = ({ className, ...props }: ISearchProps): JSX.Element => {
  return (
    <img
      className={"w-[30px] h-[30px] relative overflow-visible " + className}
      src="search.svg"
    />
  );
};
