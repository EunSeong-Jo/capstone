import { BuildingBlocksStatusBar } from "../BuildingBlocksStatusBar/BuildingBlocksStatusBar";
import { ShoppingCartSize20 } from "../ShoppingCartSize20/ShoppingCartSize20";
import { SearchSize20 } from "../SearchSize20/SearchSize20";
import { LiquidGlassRegularSmallModeLightStateDefault } from "../LiquidGlassRegularSmallModeLightStateDefault/LiquidGlassRegularSmallModeLightStateDefault";
import { Search } from "../Search/Search";
import { HomeSize20 } from "../HomeSize20/HomeSize20";
import { Menu } from "../Menu/Menu";
import { Stars } from "../Stars/Stars";
import { AccountCircle } from "../AccountCircle/AccountCircle";

export interface IComponentProps {
  className?: string;
}

export const Component = ({
  className,
  ...props
}: IComponentProps): JSX.Element => {
  return (
    <div
      className={
        "bg-[#ffffff] h-[1163px] relative overflow-hidden " + className
      }
    >
      <div className="bg-[#ffffff] rounded-[18px] border-solid border-[#cecece] border-[0.5px] w-[43px] h-[22px] absolute left-[13px] top-[145px]"></div>
      <div className="bg-[#ffffff] rounded-[18px] border-solid border-[#cecece] border-[0.5px] w-[59px] h-[22px] absolute left-[63px] top-[145px]"></div>
      <div className="bg-[#ffffff] rounded-[18px] border-solid border-[#cecece] border-[0.5px] w-[59px] h-[22px] absolute left-[129px] top-[145px]"></div>
      <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[9px] font-light absolute left-[26px] top-[151px]">
        전체{" "}
      </div>
      <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[9px] font-light absolute left-[76px] top-[151px]">
        마스크팩{" "}
      </div>
      <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[9px] font-light absolute left-[142px] top-[151px]">
        뷰티소품{" "}
      </div>
      <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[10px] font-light absolute left-[13px] top-[189px] w-[25px] h-[11px]">
        총 1개{" "}
      </div>
      <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[10px] font-light absolute left-[341px] top-[189px] w-10 h-[11px]">
        정렬{" "}
      </div>
      <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[10px] font-light absolute left-[343px] top-[362px] w-[29px] h-[11px]">
        더보기{" "}
      </div>
      <img
        className="w-[13px] h-[13px] absolute left-[361px] top-[188px]"
        style={{ objectFit: "cover", aspectRatio: "1" }}
        src="image-420.png"
      />
      <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[9px] font-light absolute left-[100px] top-56">
        피카소 FB14파운데이션 브러쉬{" "}
      </div>
      <div className="text-[#2c00ca] text-left font-['Geom-Bold',_sans-serif] text-[7px] font-bold absolute left-[100px] top-[242px]">
        24%{" "}
      </div>
      <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[10px] font-semibold absolute left-[120px] top-60">
        24,300원{" "}
      </div>
      <div
        className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[170px] top-[243px] w-[45px] h-[9px]"
        style={{ textDecoration: "line-through" }}
      >
        32,000원{" "}
      </div>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[75px] h-[75px] absolute left-[15px] top-[220px]"></div>
      <img
        className="w-[17px] h-4 absolute left-[355px] top-[235px]"
        style={{ objectFit: "cover", aspectRatio: "17/16" }}
        src="image-260.png"
      />
      <div className="bg-[#d9d9d9] w-[18px] h-[5px] absolute left-[100px] top-[257px]"></div>
      <div className="text-[#565656] text-left font-['Geom-Regular',_sans-serif] text-[4px] font-normal absolute left-[101px] top-[257px] w-[21px] h-1">
        모야 쿠폰{" "}
      </div>
      <img
        className="w-[23px] h-[22px] absolute left-[352px] top-[262px]"
        style={{ objectFit: "cover", aspectRatio: "23/22" }}
        src="image-380.png"
      />
      <div className="text-[#000000] text-left font-['-',_sans-serif] text-[6px] font-normal absolute left-[100px] top-[275px]">
        <span>
          <span className="_3-span">3회</span>
          <span className="_3-span2">구매</span>
        </span>{" "}
      </div>
      <div className="text-[#000000] text-left font-['Geom-Medium',_sans-serif] text-[13px] font-medium absolute left-[13px] top-[357px]">
        재구매가 많은 다른 상품도 있어요!{" "}
      </div>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[83px] h-[83px] absolute left-2.5 top-[387px]"></div>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[83px] h-[83px] absolute left-2.5 top-[387px]"></div>
      <div className="w-[82.8px] h-[32.99px] static">
        <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[7px] font-semibold absolute left-[12.2px] top-[499.68px] w-[50.19px] h-[9.51px]">
          24,300원{" "}
        </div>
        <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[12.2px] top-[476.21px] w-[82.8px] h-[11.42px]">
          [촉촉밀착] 더툴랩 촉촉 베이스 메이크업{" "}
        </div>
      </div>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[83px] h-[83px] absolute left-[377px] top-[387px]"></div>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[83px] h-[83px] absolute left-[377px] top-[387px]"></div>
      <div className="w-[82.8px] h-[32.99px] static">
        <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[7px] font-semibold absolute left-[379.2px] top-[499.68px] w-[50.19px] h-[9.51px]">
          24,300원{" "}
        </div>
        <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[379.2px] top-[476.21px] w-[82.8px] h-[11.42px]">
          [촉촉밀착] 더툴랩 촉촉 베이스 메이크업{" "}
        </div>
      </div>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[83px] h-[83px] absolute left-[103px] top-[387px]"></div>
      <div className="w-[82.8px] h-[32.99px] static">
        <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[7px] font-semibold absolute left-[105.2px] top-[499.68px] w-[50.19px] h-[9.51px]">
          24,300원{" "}
        </div>
        <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[105.2px] top-[476.21px] w-[82.8px] h-[11.42px]">
          [촉촉밀착] 더툴랩 촉촉 베이스 메이크업{" "}
        </div>
      </div>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[83px] h-[83px] absolute left-[194px] top-[387px]"></div>
      <div className="w-[173.8px] h-[122.2px] static">
        <div className="w-[82.8px] h-[32.99px] static">
          <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[7px] font-semibold absolute left-[196.2px] top-[499.68px] w-[50.19px] h-[9.51px]">
            24,300원{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[196.2px] top-[476.21px] w-[82.8px] h-[11.42px]">
            [촉촉밀착] 더툴랩 촉촉 베이스 메이크업{" "}
          </div>
        </div>
        <div className="bg-[#b4b4b4] rounded-[3px] w-[83px] h-[83px] absolute left-[285px] top-[387px]"></div>
        <div className="w-[82.8px] h-[32.99px] static">
          <div className="w-[82.8px] h-[32.99px] static">
            <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[7px] font-semibold absolute left-[287.2px] top-[499.68px] w-[50.19px] h-[9.51px]">
              24,300원{" "}
            </div>
            <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[287.2px] top-[476.21px] w-[82.8px] h-[11.42px]">
              [촉촉밀착] 더툴랩 촉촉 베이스 메이크업{" "}
            </div>
          </div>
        </div>
      </div>
      <img
        className="w-2.5 h-[9px] absolute left-3 top-[515px]"
        style={{ objectFit: "cover", aspectRatio: "10/9" }}
        src="image-250.png"
      />
      <img
        className="w-2.5 h-[9px] absolute left-[105px] top-[513px]"
        style={{ objectFit: "cover", aspectRatio: "10/9" }}
        src="image-430.png"
      />
      <img
        className="w-2.5 h-[9px] absolute left-[123px] top-[513px]"
        style={{ objectFit: "cover", aspectRatio: "10/9" }}
        src="image-450.png"
      />
      <img
        className="w-2.5 h-[9px] absolute left-[197px] top-[513px]"
        style={{ objectFit: "cover", aspectRatio: "10/9" }}
        src="image-460.png"
      />
      <img
        className="w-2.5 h-[9px] absolute left-[215px] top-[513px]"
        style={{ objectFit: "cover", aspectRatio: "10/9" }}
        src="image-440.png"
      />
      <img
        className="w-2.5 h-[9px] absolute left-[379px] top-[511px]"
        style={{ objectFit: "cover", aspectRatio: "10/9" }}
        src="image-470.png"
      />
      <img
        className="w-2.5 h-[9px] absolute left-[397px] top-[511px]"
        style={{ objectFit: "cover", aspectRatio: "10/9" }}
        src="image-480.png"
      />
      <img
        className="w-2.5 h-[9px] absolute left-[287px] top-[511px]"
        style={{ objectFit: "cover", aspectRatio: "10/9" }}
        src="image-490.png"
      />
      <img
        className="w-2.5 h-[9px] absolute left-[305px] top-[511px]"
        style={{ objectFit: "cover", aspectRatio: "10/9" }}
        src="image-500.png"
      />
      <div
        className="bg-[#ffffff] w-[395px] h-[126px] absolute left-[-2px] top-0"
        style={{ boxShadow: "0px 4px 4px 0px rgba(0, 0, 0, 0.10)" }}
      ></div>
      <BuildingBlocksStatusBar
        cameraCutout={false}
        className="!w-[396px] !h-[37px] !absolute !left-[-2px] !top-0"
      ></BuildingBlocksStatusBar>
      <div
        className="text-[#000000] text-left font-['Inter-BoldItalic',_sans-serif] text-xl font-bold absolute left-[19px] top-[50px]"
        style={{ fontStyle: "italic" }}
      >
        History{" "}
      </div>
      <ShoppingCartSize20
        size="20"
        className="!absolute !left-[350px] !top-14 !shrink-[unset]"
      ></ShoppingCartSize20>
      <div className="bg-[#ffffff] w-[79px] h-[33px] absolute left-10 top-[92px]"></div>
      <div className="text-[#a2a2a2] text-left font-['Aubrey-Regular',_sans-serif] text-xs font-normal absolute left-[61px] top-[102px]">
        최근 본{" "}
      </div>
      <div className="bg-[#ffffff] w-[114.56px] h-[33px] absolute left-[137px] top-[92px]"></div>
      <div className="text-[#a2a2a2] text-center font-['Aubrey-Regular',_sans-serif] text-xs font-normal absolute left-[138.33px] top-[104px] w-[109.23px]">
        나의 좋아요 상품{" "}
      </div>
      <div className="bg-[#ffffff] border-solid border-[#519288] border-b-2 w-[79px] h-[33px] absolute left-[269px] top-[92px]"></div>
      <div className="text-[#519288] text-left font-['Aubrey-Regular',_sans-serif] text-xs font-normal absolute left-[285px] top-[102px]">
        자주 구매{" "}
      </div>
      <SearchSize20
        size="20"
        className="!w-[23px] !h-[23px] !absolute !left-[312px] !top-[55px] !shrink-[unset]"
      ></SearchSize20>
      <LiquidGlassRegularSmallModeLightStateDefault className="!absolute !right-[21px] !left-4 !bottom-[19px] !top-[1096px] !w-[unset] !h-[unset]"></LiquidGlassRegularSmallModeLightStateDefault>
      <div className="w-[30px] h-[38px] static">
        <Search className="!w-[30px] !h-[30px] !absolute !left-[179px] !top-[1101px]"></Search>
        <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-[180px] top-[1131px]">
          SEARCH{" "}
        </div>
      </div>
      <div className="w-[29px] h-[39px] static">
        <HomeSize20
          size="20"
          className="!w-[29px] !h-[29px] !absolute !left-11 !top-[1101px] !shrink-[unset]"
        ></HomeSize20>
        <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-12 top-[1132px]">
          HOME{" "}
        </div>
      </div>
      <div className="w-[38px] h-[38px] static">
        <Menu className="!w-[30px] !h-[30px] !absolute !left-[111px] !top-[1101px]"></Menu>
        <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-[107px] top-[1131px]">
          CATEGORY{" "}
        </div>
      </div>
      <div className="w-[31px] h-[37px] static">
        <Stars className="!w-[30px] !h-[30px] !absolute !left-[245px] !top-[1101px]"></Stars>
        <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-[245px] top-[1130px]">
          HISOTRY{" "}
        </div>
      </div>
      <div className="w-[30px] h-[39px] static">
        <AccountCircle className="!w-[30px] !h-[30px] !absolute !left-[315px] !top-[1101px]"></AccountCircle>
        <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-[324px] top-[1132px]">
          MY{" "}
        </div>
      </div>
    </div>
  );
};
