export interface IAccountCircleProps {
  className?: string;
}

export const AccountCircle = ({
  className,
  ...props
}: IAccountCircleProps): JSX.Element => {
  return (
    <img
      className={"w-[30px] h-[30px] relative overflow-visible " + className}
      src="account-circle.svg"
    />
  );
};
