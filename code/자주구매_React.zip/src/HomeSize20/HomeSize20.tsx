export interface IHomeSize20Props {
  size?: "20" | "24" | "32" | "40" | "48" | "16";
  className?: string;
}

export const HomeSize20 = ({
  size = "48",
  className,
  ...props
}: IHomeSize20Props): JSX.Element => {
  const variantsClassName = "size-" + size;

  return (
    <img
      className={
        "w-[29px] h-[29px] relative overflow-visible " +
        className +
        " " +
        variantsClassName
      }
      src="home-size-20.svg"
    />
  );
};
