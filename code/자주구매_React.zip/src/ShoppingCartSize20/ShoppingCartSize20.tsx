export interface IShoppingCartSize20Props {
  size?: "20" | "24" | "32" | "40" | "48" | "16";
  className?: string;
}

export const ShoppingCartSize20 = ({
  size = "48",
  className,
  ...props
}: IShoppingCartSize20Props): JSX.Element => {
  const variantsClassName = "size-" + size;

  return (
    <img
      className={
        "w-5 h-5 relative overflow-visible " +
        className +
        " " +
        variantsClassName
      }
      src="shopping-cart-size-20.svg"
    />
  );
};
