export interface IStarsProps {
  className?: string;
}

export const Stars = ({ className, ...props }: IStarsProps): JSX.Element => {
  return (
    <img
      className={"w-[30px] h-[30px] relative overflow-visible " + className}
      src="stars.svg"
    />
  );
};
