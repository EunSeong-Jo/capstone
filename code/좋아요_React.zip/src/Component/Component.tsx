import { BuildingBlocksStatusBar } from "../BuildingBlocksStatusBar/BuildingBlocksStatusBar";
import { ShoppingCartSize20 } from "../ShoppingCartSize20/ShoppingCartSize20";
import { SearchSize20 } from "../SearchSize20/SearchSize20";
import { Heart } from "../Heart/Heart";
import { ShoppingBag } from "../ShoppingBag/ShoppingBag";
import { LiquidGlassRegularSmallModeLightStateDefault } from "../LiquidGlassRegularSmallModeLightStateDefault/LiquidGlassRegularSmallModeLightStateDefault";
import { Search } from "../Search/Search";
import { HomeSize20 } from "../HomeSize20/HomeSize20";
import { Menu } from "../Menu/Menu";
import { Stars } from "../Stars/Stars";
import { AccountCircle } from "../AccountCircle/AccountCircle";

export interface IComponentProps {
  className?: string;
}

export const Component = ({
  className,
  ...props
}: IComponentProps): JSX.Element => {
  return (
    <div
      className={
        "bg-[#ffffff] h-[1163px] relative overflow-hidden " + className
      }
    >
      <div
        className="bg-[#ffffff] w-[395px] h-[126px] absolute left-[-2px] top-0"
        style={{ boxShadow: "0px 4px 4px 0px rgba(0, 0, 0, 0.10)" }}
      ></div>
      <BuildingBlocksStatusBar
        cameraCutout={false}
        className="!w-[396px] !h-[37px] !absolute !left-[-2px] !top-0"
      ></BuildingBlocksStatusBar>
      <div
        className="text-[#000000] text-left font-['Inter-BoldItalic',_sans-serif] text-xl font-bold absolute left-[19px] top-[50px]"
        style={{ fontStyle: "italic" }}
      >
        History{" "}
      </div>
      <div className="bg-[#ffffff] rounded-[18px] border-solid border-[#cecece] border-[0.5px] w-[43px] h-[22px] absolute left-3.5 top-[146px]"></div>
      <div className="bg-[#ffffff] rounded-[18px] border-solid border-[#cecece] border-[0.5px] w-[59px] h-[22px] absolute left-16 top-[146px]"></div>
      <div className="bg-[#ffffff] rounded-[18px] border-solid border-[#cecece] border-[0.5px] w-[59px] h-[22px] absolute left-[130px] top-[146px]"></div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#cecece] border-[0.5px] w-[11px] h-[11px] absolute left-[53px] top-[181px]"></div>
      <div className="text-[#000000] text-left font-['Geom-Medium',_sans-serif] text-[13px] font-medium absolute left-[18px] top-[435px]">
        이런 상품도 있어요!{" "}
      </div>
      <div className="bg-[#ffffff] rounded-[106px] border-solid border-[#bababa] border-[0.5px] w-[83px] h-[26px] absolute left-[155px] top-[1028px]"></div>
      <div className="text-[#9e9d9d] text-left font-['Inter-Bold',_sans-serif] text-[8px] font-bold absolute left-[169px] top-[1036px]">
        상품 더 보기{" "}
      </div>
      <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[9px] font-light absolute left-[18px] top-[181px]">
        총 2개{" "}
      </div>
      <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[9px] font-light absolute left-[68px] top-[181px]">
        할인 상품{" "}
      </div>
      <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[9px] font-light absolute left-[340px] top-[181px]">
        전체삭제{" "}
      </div>
      <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[9px] font-light absolute left-[27px] top-[152px]">
        전체{" "}
      </div>
      <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[9px] font-light absolute left-[77px] top-[152px]">
        마스크팩{" "}
      </div>
      <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[9px] font-light absolute left-[143px] top-[152px]">
        뷰티소품{" "}
      </div>
      <div className="bg-[#ffffff] w-[79px] h-[33px] absolute left-10 top-[92px]"></div>
      <div className="text-[#a2a2a2] text-left font-['Aubrey-Regular',_sans-serif] text-xs font-normal absolute left-[61px] top-[102px]">
        최근 본{" "}
      </div>
      <div className="bg-[#ffffff] border-solid border-[#40cda0] border-b-2 w-[114.56px] h-[33px] absolute left-[137px] top-[92px]"></div>
      <div className="text-[#40cda0] text-center font-['Aubrey-Regular',_sans-serif] text-xs font-normal absolute left-[138.33px] top-[104px] w-[109.23px]">
        나의 좋아요 상품{" "}
      </div>
      <div className="bg-[#ffffff] w-[79px] h-[33px] absolute left-[269px] top-[92px]"></div>
      <div className="text-[#a2a2a2] text-left font-['Aubrey-Regular',_sans-serif] text-xs font-normal absolute left-[285px] top-[102px]">
        자주 구매{" "}
      </div>
      <ShoppingCartSize20
        size="20"
        className="!absolute !left-[350px] !top-14 !shrink-[unset]"
      ></ShoppingCartSize20>
      <div
        className="bg-[#ffffff] w-[395px] h-[126px] absolute left-[-2px] top-0"
        style={{ boxShadow: "0px 4px 4px 0px rgba(0, 0, 0, 0.10)" }}
      ></div>
      <BuildingBlocksStatusBar
        cameraCutout={false}
        className="!w-[396px] !h-[37px] !absolute !left-[-2px] !top-0"
      ></BuildingBlocksStatusBar>
      <div
        className="text-[#000000] text-left font-['Inter-BoldItalic',_sans-serif] text-xl font-bold absolute left-[19px] top-[50px]"
        style={{ fontStyle: "italic" }}
      >
        History{" "}
      </div>
      <ShoppingCartSize20
        size="20"
        className="!absolute !left-[350px] !top-14 !shrink-[unset]"
      ></ShoppingCartSize20>
      <div className="bg-[#ffffff] w-[79px] h-[33px] absolute left-10 top-[92px]"></div>
      <div className="text-[#a2a2a2] text-left font-['Aubrey-Regular',_sans-serif] text-xs font-normal absolute left-[61px] top-[102px]">
        최근 본{" "}
      </div>
      <div className="bg-[#ffffff] border-solid border-[#519288] border-b-2 w-[114.56px] h-[33px] absolute left-[137px] top-[92px]"></div>
      <div className="text-[#519288] text-center font-['Aubrey-Regular',_sans-serif] text-xs font-normal absolute left-[138.33px] top-[104px] w-[109.23px]">
        나의 좋아요 상품{" "}
      </div>
      <div className="bg-[#ffffff] w-[79px] h-[33px] absolute left-[269px] top-[92px]"></div>
      <div className="text-[#a2a2a2] text-left font-['Aubrey-Regular',_sans-serif] text-xs font-normal absolute left-[285px] top-[102px]">
        자주 구매{" "}
      </div>
      <SearchSize20
        size="20"
        className="!w-[23px] !h-[23px] !absolute !left-[312px] !top-[55px] !shrink-[unset]"
      ></SearchSize20>
      <div className="w-[119px] h-[29px] static">
        <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[9px] font-light absolute left-[104px] top-[233px]">
          피카소 FB14파운데이션 브러쉬{" "}
        </div>
        <div className="text-[#2c00ca] text-left font-['Geom-Bold',_sans-serif] text-[7px] font-bold absolute left-[104px] top-[251px]">
          24%{" "}
        </div>
        <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[10px] font-semibold absolute left-[124px] top-[249px]">
          24,300원{" "}
        </div>
        <div
          className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[174px] top-[252px] w-[45px] h-[9px]"
          style={{ textDecoration: "line-through" }}
        >
          32,000원{" "}
        </div>
      </div>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[75px] h-[75px] absolute left-5 top-[218px]"></div>
      <div className="bg-[#d9d9d9] w-4 h-1.5 absolute left-[104px] top-[264px]"></div>
      <div className="text-[#565656] text-left font-['Geom-Regular',_sans-serif] text-[3px] font-normal absolute left-[106px] top-[265px] w-[13px] h-1">
        모야 쿠폰{" "}
      </div>
      <Heart className="!absolute !left-[354px] !top-[231px]"></Heart>
      <ShoppingBag className="!absolute !left-[354px] !top-[265px]"></ShoppingBag>
      <div className="w-[119px] h-[29px] static">
        <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[9px] font-light absolute left-[104px] top-[328px]">
          피카소 FB14파운데이션 브러쉬{" "}
        </div>
        <div className="text-[#2c00ca] text-left font-['Geom-Bold',_sans-serif] text-[7px] font-bold absolute left-[104px] top-[346px]">
          24%{" "}
        </div>
        <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[10px] font-semibold absolute left-[124px] top-[344px]">
          24,300원{" "}
        </div>
        <div
          className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[174px] top-[347px] w-[45px] h-[9px]"
          style={{ textDecoration: "line-through" }}
        >
          32,000원{" "}
        </div>
      </div>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[75px] h-[75px] absolute left-5 top-[313px]"></div>
      <div className="bg-[#d9d9d9] w-4 h-1.5 absolute left-[104px] top-[359px]"></div>
      <div className="text-[#565656] text-left font-['Geom-Regular',_sans-serif] text-[3px] font-normal absolute left-[106px] top-[360px] w-[13px] h-1">
        모야 쿠폰{" "}
      </div>
      <Heart className="!absolute !left-[354px] !top-[326px]"></Heart>
      <ShoppingBag className="!absolute !left-[354px] !top-[360px]"></ShoppingBag>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[115.96px] h-[110.09px] absolute left-2 top-[466px]"></div>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[115.96px] h-[110.09px] absolute left-2 top-[466px]"></div>
      <div className="w-[116.43px] h-[46.25px] static">
        <div className="w-[116.43px] h-[46.25px] static">
          <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[8px] font-semibold absolute left-[45px] top-[604px] w-[70.57px] h-[13.76px]">
            24,300원{" "}
          </div>
          <div className="text-[#ff0202] text-left font-['Geom-SemiBold',_sans-serif] text-[8px] font-semibold absolute left-2 top-[614px] w-[32.34px] h-[13.76px]">
            30%{" "}
          </div>
          <div
            className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[6px] font-light absolute left-2 top-[606px] w-[99.13px] h-[5.98px]"
            style={{ textDecoration: "line-through" }}
          >
            32,000원{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[8px] font-light absolute left-2 top-[581.5px] w-[116.43px] h-[16.51px]">
            [촉촉밀찰] 더툴랩 촉촉 베이스 메이크업{" "}
          </div>
        </div>
      </div>
      <Heart className="!w-[11.18px] !h-[11.18px] !absolute !left-[110.46px] !top-[562.87px]"></Heart>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[115.96px] h-[110.09px] absolute left-[269px] top-[466px]"></div>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[115.96px] h-[110.09px] absolute left-[269px] top-[466px]"></div>
      <div className="w-[116.43px] h-[46.25px] static">
        <div className="w-[116.43px] h-[46.25px] static">
          <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[8px] font-semibold absolute left-[306px] top-[604px] w-[70.57px] h-[13.76px]">
            24,300원{" "}
          </div>
          <div className="text-[#ff0202] text-left font-['Geom-SemiBold',_sans-serif] text-[8px] font-semibold absolute left-[269px] top-[614px] w-[32.34px] h-[13.76px]">
            30%{" "}
          </div>
          <div
            className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[6px] font-light absolute left-[269px] top-[606px] w-[99.13px] h-[5.98px]"
            style={{ textDecoration: "line-through" }}
          >
            32,000원{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[8px] font-light absolute left-[269px] top-[581.5px] w-[116.43px] h-[16.51px]">
            [촉촉밀찰] 더툴랩 촉촉 베이스 메이크업{" "}
          </div>
        </div>
      </div>
      <Heart className="!w-[11.18px] !h-[11.18px] !absolute !left-[371.46px] !top-[562.87px]"></Heart>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[115.96px] h-[110.09px] absolute left-[139px] top-[466px]"></div>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[115.96px] h-[110.09px] absolute left-[139px] top-[466px]"></div>
      <div className="w-[116.43px] h-[46.25px] static">
        <div className="w-[116.43px] h-[46.25px] static">
          <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[8px] font-semibold absolute left-44 top-[604px] w-[70.57px] h-[13.76px]">
            24,300원{" "}
          </div>
          <div className="text-[#ff0202] text-left font-['Geom-SemiBold',_sans-serif] text-[8px] font-semibold absolute left-[139px] top-[614px] w-[32.34px] h-[13.76px]">
            30%{" "}
          </div>
          <div
            className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[6px] font-light absolute left-[139px] top-[606px] w-[99.13px] h-[5.98px]"
            style={{ textDecoration: "line-through" }}
          >
            32,000원{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[8px] font-light absolute left-[139px] top-[581.5px] w-[116.43px] h-[16.51px]">
            [촉촉밀찰] 더툴랩 촉촉 베이스 메이크업{" "}
          </div>
        </div>
      </div>
      <Heart className="!w-[11.18px] !h-[11.18px] !absolute !left-[241.46px] !top-[562.87px]"></Heart>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[115.96px] h-[110.09px] absolute left-2 top-[830px]"></div>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[115.96px] h-[110.09px] absolute left-2 top-[830px]"></div>
      <div className="w-[116.43px] h-[46.25px] static">
        <div className="w-[116.43px] h-[46.25px] static">
          <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[8px] font-semibold absolute left-[45px] top-[968px] w-[70.57px] h-[13.76px]">
            24,300원{" "}
          </div>
          <div className="text-[#ff0202] text-left font-['Geom-SemiBold',_sans-serif] text-[8px] font-semibold absolute left-2 top-[978px] w-[32.34px] h-[13.76px]">
            30%{" "}
          </div>
          <div
            className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[6px] font-light absolute left-2 top-[970px] w-[99.13px] h-[5.98px]"
            style={{ textDecoration: "line-through" }}
          >
            32,000원{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[8px] font-light absolute left-2 top-[945.5px] w-[116.43px] h-[16.51px]">
            [촉촉밀찰] 더툴랩 촉촉 베이스 메이크업{" "}
          </div>
        </div>
      </div>
      <Heart className="!w-[11.18px] !h-[11.18px] !absolute !left-[110.46px] !top-[926.87px]"></Heart>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[115.96px] h-[110.09px] absolute left-[269px] top-[830px]"></div>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[115.96px] h-[110.09px] absolute left-[269px] top-[830px]"></div>
      <div className="w-[116.43px] h-[46.25px] static">
        <div className="w-[116.43px] h-[46.25px] static">
          <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[8px] font-semibold absolute left-[306px] top-[968px] w-[70.57px] h-[13.76px]">
            24,300원{" "}
          </div>
          <div className="text-[#ff0202] text-left font-['Geom-SemiBold',_sans-serif] text-[8px] font-semibold absolute left-[269px] top-[978px] w-[32.34px] h-[13.76px]">
            30%{" "}
          </div>
          <div
            className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[6px] font-light absolute left-[269px] top-[970px] w-[99.13px] h-[5.98px]"
            style={{ textDecoration: "line-through" }}
          >
            32,000원{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[8px] font-light absolute left-[269px] top-[945.5px] w-[116.43px] h-[16.51px]">
            [촉촉밀찰] 더툴랩 촉촉 베이스 메이크업{" "}
          </div>
        </div>
      </div>
      <Heart className="!w-[11.18px] !h-[11.18px] !absolute !left-[371.46px] !top-[926.87px]"></Heart>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[115.96px] h-[110.09px] absolute left-[139px] top-[830px]"></div>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[115.96px] h-[110.09px] absolute left-[139px] top-[830px]"></div>
      <div className="w-[116.43px] h-[46.25px] static">
        <div className="w-[116.43px] h-[46.25px] static">
          <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[8px] font-semibold absolute left-44 top-[968px] w-[70.57px] h-[13.76px]">
            24,300원{" "}
          </div>
          <div className="text-[#ff0202] text-left font-['Geom-SemiBold',_sans-serif] text-[8px] font-semibold absolute left-[139px] top-[978px] w-[32.34px] h-[13.76px]">
            30%{" "}
          </div>
          <div
            className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[6px] font-light absolute left-[139px] top-[970px] w-[99.13px] h-[5.98px]"
            style={{ textDecoration: "line-through" }}
          >
            32,000원{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[8px] font-light absolute left-[139px] top-[945.5px] w-[116.43px] h-[16.51px]">
            [촉촉밀찰] 더툴랩 촉촉 베이스 메이크업{" "}
          </div>
        </div>
      </div>
      <Heart className="!w-[11.18px] !h-[11.18px] !absolute !left-[241.46px] !top-[926.87px]"></Heart>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[115.96px] h-[110.09px] absolute left-2 top-[648px]"></div>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[115.96px] h-[110.09px] absolute left-2 top-[648px]"></div>
      <div className="w-[116.43px] h-[46.25px] static">
        <div className="w-[116.43px] h-[46.25px] static">
          <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[8px] font-semibold absolute left-[45px] top-[786px] w-[70.57px] h-[13.76px]">
            24,300원{" "}
          </div>
          <div className="text-[#ff0202] text-left font-['Geom-SemiBold',_sans-serif] text-[8px] font-semibold absolute left-2 top-[796px] w-[32.34px] h-[13.76px]">
            30%{" "}
          </div>
          <div
            className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[6px] font-light absolute left-2 top-[788px] w-[99.13px] h-[5.98px]"
            style={{ textDecoration: "line-through" }}
          >
            32,000원{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[8px] font-light absolute left-2 top-[763.5px] w-[116.43px] h-[16.51px]">
            [촉촉밀찰] 더툴랩 촉촉 베이스 메이크업{" "}
          </div>
        </div>
      </div>
      <Heart className="!w-[11.18px] !h-[11.18px] !absolute !left-[110.46px] !top-[744.87px]"></Heart>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[115.96px] h-[110.09px] absolute left-[269px] top-[648px]"></div>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[115.96px] h-[110.09px] absolute left-[269px] top-[648px]"></div>
      <div className="w-[116.43px] h-[46.25px] static">
        <div className="w-[116.43px] h-[46.25px] static">
          <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[8px] font-semibold absolute left-[306px] top-[786px] w-[70.57px] h-[13.76px]">
            24,300원{" "}
          </div>
          <div className="text-[#ff0202] text-left font-['Geom-SemiBold',_sans-serif] text-[8px] font-semibold absolute left-[269px] top-[796px] w-[32.34px] h-[13.76px]">
            30%{" "}
          </div>
          <div
            className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[6px] font-light absolute left-[269px] top-[788px] w-[99.13px] h-[5.98px]"
            style={{ textDecoration: "line-through" }}
          >
            32,000원{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[8px] font-light absolute left-[269px] top-[763.5px] w-[116.43px] h-[16.51px]">
            [촉촉밀찰] 더툴랩 촉촉 베이스 메이크업{" "}
          </div>
        </div>
      </div>
      <Heart className="!w-[11.18px] !h-[11.18px] !absolute !left-[371.46px] !top-[744.87px]"></Heart>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[115.96px] h-[110.09px] absolute left-[139px] top-[648px]"></div>
      <div className="bg-[#b4b4b4] rounded-[3px] w-[115.96px] h-[110.09px] absolute left-[139px] top-[648px]"></div>
      <div className="w-[116.43px] h-[46.25px] static">
        <div className="w-[116.43px] h-[46.25px] static">
          <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[8px] font-semibold absolute left-44 top-[786px] w-[70.57px] h-[13.76px]">
            24,300원{" "}
          </div>
          <div className="text-[#ff0202] text-left font-['Geom-SemiBold',_sans-serif] text-[8px] font-semibold absolute left-[139px] top-[796px] w-[32.34px] h-[13.76px]">
            30%{" "}
          </div>
          <div
            className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[6px] font-light absolute left-[139px] top-[788px] w-[99.13px] h-[5.98px]"
            style={{ textDecoration: "line-through" }}
          >
            32,000원{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[8px] font-light absolute left-[139px] top-[763.5px] w-[116.43px] h-[16.51px]">
            [촉촉밀찰] 더툴랩 촉촉 베이스 메이크업{" "}
          </div>
        </div>
      </div>
      <Heart className="!w-[11.18px] !h-[11.18px] !absolute !left-[241.46px] !top-[744.87px]"></Heart>
      <LiquidGlassRegularSmallModeLightStateDefault className="!absolute !right-4 !left-[21px] !bottom-[25px] !top-[1090px] !w-[unset] !h-[unset]"></LiquidGlassRegularSmallModeLightStateDefault>
      <div className="w-[30px] h-[38px] static">
        <Search className="!w-[30px] !h-[30px] !absolute !left-[184px] !top-[1095px]"></Search>
        <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-[185px] top-[1125px]">
          SEARCH{" "}
        </div>
      </div>
      <div className="w-[29px] h-[39px] static">
        <HomeSize20
          size="20"
          className="!w-[29px] !h-[29px] !absolute !left-[49px] !top-[1095px] !shrink-[unset]"
        ></HomeSize20>
        <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-[53px] top-[1126px]">
          HOME{" "}
        </div>
      </div>
      <div className="w-[38px] h-[38px] static">
        <Menu className="!w-[30px] !h-[30px] !absolute !left-[116px] !top-[1095px]"></Menu>
        <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-28 top-[1125px]">
          CATEGORY{" "}
        </div>
      </div>
      <div className="w-[31px] h-[37px] static">
        <Stars className="!w-[30px] !h-[30px] !absolute !left-[250px] !top-[1095px]"></Stars>
        <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-[250px] top-[1124px]">
          HISOTRY{" "}
        </div>
      </div>
      <div className="w-[30px] h-[39px] static">
        <AccountCircle className="!w-[30px] !h-[30px] !absolute !left-80 !top-[1095px]"></AccountCircle>
        <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-[329px] top-[1126px]">
          MY{" "}
        </div>
      </div>
    </div>
  );
};
