import { LiquidGlassRegularSmallModeLightStateDefault } from "../LiquidGlassRegularSmallModeLightStateDefault/LiquidGlassRegularSmallModeLightStateDefault";
import { ChevronLeftSize48 } from "../ChevronLeftSize48/ChevronLeftSize48";
import { BuildingBlocksStatusBar } from "../BuildingBlocksStatusBar/BuildingBlocksStatusBar";

export interface IOneProps {
  className?: string;
}

export const One = ({ className, ...props }: IOneProps): JSX.Element => {
  return (
    <div
      className={"bg-[#ffffff] h-[787px] relative overflow-hidden " + className}
    >
      <div className="w-[356px] h-12 static">
        <LiquidGlassRegularSmallModeLightStateDefault className="!absolute !right-[18px] !left-[19px] !bottom-[27px] !top-[712px] !w-[unset] !h-[unset]"></LiquidGlassRegularSmallModeLightStateDefault>
      </div>
      <div className="text-[#ffffff] text-left font-['HankenGrotesk-Medium',_sans-serif] text-lg font-medium absolute left-[163px] top-[724px]">
        다음으로{" "}
      </div>
      <img
        className="w-[25px] h-0 absolute left-[323px] top-[736px] overflow-visible"
        src="arrow-10.svg"
      />
      <div
        className="bg-[#ffffff] rounded-lg w-[323px] h-[79px] absolute left-[35px] top-[566px]"
        style={{ boxShadow: "2px 3px 15px 2px rgba(45, 122, 79, 1.00)" }}
      ></div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[51px] top-[585px]">
        당김도 없고 기름지지도 않아요{" "}
      </div>
      <div className="text-[#9d9d9d] text-left font-['HankenGrotesk-Regular',_sans-serif] text-[8px] font-normal absolute left-[51px] top-[614px]">
        유수분 균형이 완벽하게 잡혀있어 아무것도 바르지 않아도 부드러워요.{" "}
      </div>
      <div className="rounded-[50%] border-solid border-[#d3d3d3] border w-[26px] h-[26px] absolute left-[315px] top-[593px]"></div>
      <div
        className="bg-[#ffffff] rounded-lg w-[323px] h-[79px] absolute left-[35px] top-[473px]"
        style={{ boxShadow: "2px 3px 15px 2px rgba(45, 122, 79, 1.00)" }}
      ></div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[51px] top-[492px]">
        얼굴 전체적으로 기름기가 올라와요{" "}
      </div>
      <div className="text-[#9d9d9d] text-left font-['HankenGrotesk-Regular',_sans-serif] text-[8px] font-normal absolute left-[51px] top-[521px]">
        세안 후 얼마 지나지 않아도 얼굴 전반에 피지 분비가 왕성해져요.{" "}
      </div>
      <div className="rounded-[50%] border-solid border-[#d3d3d3] border w-[26px] h-[26px] absolute left-[315px] top-[500px]"></div>
      <div
        className="bg-[#ffffff] rounded-lg w-[323px] h-[79px] absolute left-[35px] top-[380px]"
        style={{ boxShadow: "2px 3px 15px 2px rgba(45, 122, 79, 1.00)" }}
      ></div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[50px] top-[398px]">
        T존은 번들거리는데, 볼이나 입가는 당겨요{" "}
      </div>
      <div className="text-[#9d9d9d] text-left font-['HankenGrotesk-Regular',_sans-serif] text-[8px] font-normal absolute left-[50px] top-[431px]">
        이마와 코에는 기름기가 돌지만 뺨 주변은 건조해 부위별 밸런스가 달라요.{" "}
      </div>
      <div className="rounded-[50%] border-solid border-[#d3d3d3] border w-[26px] h-[26px] absolute left-[315px] top-[407px]"></div>
      <div
        className="bg-[#ffffff] rounded-lg w-[323px] h-[79px] absolute left-[35px] top-[287px]"
        style={{ boxShadow: "2px 3px 15px 2px rgba(45, 122, 79, 1.00)" }}
      ></div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[50px] top-[301px]">
        전체적으로 당김이 심하고 푸석해요{" "}
      </div>
      <div className="text-[#9d9d9d] text-left font-['HankenGrotesk-Regular',_sans-serif] text-[8px] font-normal absolute left-[51px] top-[330px]">
        피부 속 유수분이 모두 부족해 얼굴이 팽팽하게 <br />
        당기는 느낌이 들어요.{" "}
      </div>
      <div className="rounded-[50%] border-solid border-[#d3d3d3] border w-[26px] h-[26px] absolute left-[315px] top-[314px]"></div>
      <div className="text-[#b3b3b3] text-left font-['HankenGrotesk-SemiBold',_sans-serif] text-[10px] font-semibold absolute left-[37px] top-[225px]">
        자신의 피부 상태에 가장 가까운 것을 선택해 주세요.{" "}
      </div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Bold',_sans-serif] text-[19px] font-bold absolute left-[38px] top-[166px]">
        아침에 물로만 세수하고 1시간이 지났을 때, <br />내 피부 상태와 가장
        가까운 것은?{" "}
      </div>
      <div className="text-[#2d7a4f] text-left font-['HankenGrotesk-SemiBold',_sans-serif] text-xl font-semibold absolute left-[37px] top-[133px]">
        Q1.{" "}
      </div>
      <div
        className="text-[#2d7a4f] text-left font-['Inter-BoldItalic',_sans-serif] text-[13px] font-bold absolute left-[324px] top-[58px]"
        style={{ fontStyle: "italic" }}
      >
        01{" "}
      </div>
      <div
        className="text-[#000000] text-left font-['HankenGrotesk-BoldItalic',_sans-serif] text-[10px] font-bold absolute left-[342px] top-[60px]"
        style={{ fontStyle: "italic" }}
      >
        /{" "}
      </div>
      <div
        className="text-[#000000] text-left font-['HankenGrotesk-BoldItalic',_sans-serif] text-[10px] font-bold absolute left-[348px] top-[61px]"
        style={{ fontStyle: "italic" }}
      >
        06{" "}
      </div>
      <div className="bg-[#d9d9d9] rounded-[20px] w-[222px] h-1 absolute left-[84px] top-16"></div>
      <div className="bg-[#2d7a4f] rounded-[20px] w-[37px] h-1 absolute left-[84px] top-16"></div>
      <div className="bg-[#d9d9d9] rounded-[50%] w-[29px] h-[29px] absolute left-[23px] top-[50px]"></div>
      <ChevronLeftSize48 className="!w-[21px] !h-[21px] !absolute !left-[26px] !top-[54px] !shrink-[unset]"></ChevronLeftSize48>
      <BuildingBlocksStatusBar
        cameraCutout={false}
        className="!w-[396px] !h-[37px] !absolute !left-[-2px] !top-0"
      ></BuildingBlocksStatusBar>
    </div>
  );
};
