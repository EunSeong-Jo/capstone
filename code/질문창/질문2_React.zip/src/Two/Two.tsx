import { LiquidGlassRegularSmallModeLightStateDefault } from "../LiquidGlassRegularSmallModeLightStateDefault/LiquidGlassRegularSmallModeLightStateDefault";
import { ChevronLeftSize48 } from "../ChevronLeftSize48/ChevronLeftSize48";
import { BuildingBlocksStatusBar } from "../BuildingBlocksStatusBar/BuildingBlocksStatusBar";

export interface ITwoProps {
  className?: string;
}

export const Two = ({ className, ...props }: ITwoProps): JSX.Element => {
  return (
    <div
      className={"bg-[#ffffff] h-[787px] relative overflow-hidden " + className}
    >
      <div className="w-[356px] h-12 static">
        <LiquidGlassRegularSmallModeLightStateDefault className="!absolute !right-[18px] !left-[19px] !bottom-[27px] !top-[712px] !w-[unset] !h-[unset]"></LiquidGlassRegularSmallModeLightStateDefault>
      </div>
      <div className="text-[#ffffff] text-left font-['HankenGrotesk-Medium',_sans-serif] text-lg font-medium absolute left-[163px] top-[724px]">
        다음으로{" "}
      </div>
      <img
        className="w-[25px] h-0 absolute left-[323px] top-[736px] overflow-visible"
        src="arrow-10.svg"
      />
      <div
        className="bg-[#ffffff] rounded-lg w-[323px] h-[79px] absolute left-[35px] top-[566px]"
        style={{ boxShadow: "2px 3px 15px 2px rgba(45, 122, 79, 1.00)" }}
      ></div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[51px] top-[585px]">
        외부 자극이나 화장품 변경에도 늘 평온하다.{" "}
      </div>
      <div className="text-[#9d9d9d] text-left font-['HankenGrotesk-Regular',_sans-serif] text-[8px] font-normal absolute left-[51px] top-[614px]">
        피부 장벽이 튼튼해 웬만한 자극이나 환경 변화에도 늘 안정적이에요.{" "}
      </div>
      <div className="rounded-[50%] border-solid border-[#d3d3d3] border w-[26px] h-[26px] absolute left-[315px] top-[593px]"></div>
      <div
        className="bg-[#ffffff] rounded-lg w-[323px] h-[79px] absolute left-[35px] top-[473px]"
        style={{ boxShadow: "2px 3px 15px 2px rgba(45, 122, 79, 1.00)" }}
      ></div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[12.5px] font-medium absolute left-[51px] top-[492px]">
        계절이 바뀔 때 만 일시적으로 각질이 일어난다.{" "}
      </div>
      <div className="text-[#9d9d9d] text-left font-['HankenGrotesk-Regular',_sans-serif] text-[8px] font-normal absolute left-[51px] top-[521px]">
        평소엔 튼튼하지만 급격한 기온 변화나 환절기에는 조금 거칠어져요.{" "}
      </div>
      <div className="rounded-[50%] border-solid border-[#d3d3d3] border w-[26px] h-[26px] absolute left-[315px] top-[500px]"></div>
      <div
        className="bg-[#ffffff] rounded-lg w-[323px] h-[79px] absolute left-[35px] top-[380px]"
        style={{ boxShadow: "2px 3px 15px 2px rgba(45, 122, 79, 1.00)" }}
      ></div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[51px] top-[399px]">
        컨디션이 나쁘면 간지럽거나 뾰루지가 올라온다.{" "}
      </div>
      <div className="text-[#9d9d9d] text-left font-['HankenGrotesk-Regular',_sans-serif] text-[8px] font-normal absolute left-[51px] top-[428px]">
        평소엔 무난하지만 피부 컨디션이 떨어지면 뾰루지가 한두 개씩 생겨요.{" "}
      </div>
      <div className="rounded-[50%] border-solid border-[#d3d3d3] border w-[26px] h-[26px] absolute left-[315px] top-[407px]"></div>
      <div
        className="bg-[#ffffff] rounded-lg w-[323px] h-[79px] absolute left-[35px] top-[287px]"
        style={{ boxShadow: "2px 3px 15px 2px rgba(45, 122, 79, 1.00)" }}
      ></div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[51px] top-[306px]">
        쉽게 붉어지고 가렵거나 따가운 통증이 있다.{" "}
      </div>
      <div className="text-[#9d9d9d] text-left font-['HankenGrotesk-Regular',_sans-serif] text-[8px] font-normal absolute left-[51px] top-[335px]">
        새로운 제품이나 외부 환경에 피부가 즉각적이고 민감하게 반응해요.{" "}
      </div>
      <div className="rounded-[50%] border-solid border-[#d3d3d3] border w-[26px] h-[26px] absolute left-[315px] top-[314px]"></div>
      <div className="text-[#b3b3b3] text-left font-['HankenGrotesk-SemiBold',_sans-serif] text-[10px] font-semibold absolute left-[38px] top-[225px]">
        자신의 피부 상태에 가장 가까운 것을 선택해 주세요.{" "}
      </div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Bold',_sans-serif] text-[19px] font-bold absolute left-[38px] top-[166px]">
        화장품을 바꾸거나, 미세먼지가 심한 날<br />내 피부는 어떻게 반응하나요?{" "}
      </div>
      <div className="text-[#2d7a4f] text-left font-['HankenGrotesk-SemiBold',_sans-serif] text-xl font-semibold absolute left-[37px] top-[133px]">
        Q2.{" "}
      </div>
      <div
        className="text-[#2d7a4f] text-left font-['Inter-BoldItalic',_sans-serif] text-[13px] font-bold absolute left-[324px] top-[58px]"
        style={{ fontStyle: "italic" }}
      >
        02{" "}
      </div>
      <div
        className="text-[#000000] text-left font-['HankenGrotesk-BoldItalic',_sans-serif] text-[10px] font-bold absolute left-[342px] top-[60px]"
        style={{ fontStyle: "italic" }}
      >
        /{" "}
      </div>
      <div
        className="text-[#000000] text-left font-['HankenGrotesk-BoldItalic',_sans-serif] text-[10px] font-bold absolute left-[348px] top-[61px]"
        style={{ fontStyle: "italic" }}
      >
        06{" "}
      </div>
      <div className="bg-[#d9d9d9] rounded-[20px] w-[222px] h-1 absolute left-[84px] top-16"></div>
      <div className="bg-[#2d7a4f] rounded-[20px] w-[74px] h-1 absolute left-[84px] top-16"></div>
      <div className="bg-[#d9d9d9] rounded-[50%] w-[29px] h-[29px] absolute left-[23px] top-[50px]"></div>
      <ChevronLeftSize48 className="!w-[21px] !h-[21px] !absolute !left-[26px] !top-[54px] !shrink-[unset]"></ChevronLeftSize48>
      <BuildingBlocksStatusBar
        cameraCutout={false}
        className="!w-[396px] !h-[37px] !absolute !left-[-2px] !top-0"
      ></BuildingBlocksStatusBar>
    </div>
  );
};
