import "./styles.css";
import "./tailwind.css";
import { Five } from "./Five/Five";

export default function App() {
  return (
    <div>
      <Five />
    </div>
  );
}
