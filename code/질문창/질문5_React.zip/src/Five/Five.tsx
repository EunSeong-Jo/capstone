import { LiquidGlassRegularSmallModeLightStateDefault } from "../LiquidGlassRegularSmallModeLightStateDefault/LiquidGlassRegularSmallModeLightStateDefault";
import { ChevronLeftSize48 } from "../ChevronLeftSize48/ChevronLeftSize48";
import { BuildingBlocksStatusBar } from "../BuildingBlocksStatusBar/BuildingBlocksStatusBar";

export interface IFiveProps {
  className?: string;
}

export const Five = ({ className, ...props }: IFiveProps): JSX.Element => {
  return (
    <div
      className={"bg-[#ffffff] h-[787px] relative overflow-hidden " + className}
    >
      <div className="w-[356px] h-12 static">
        <LiquidGlassRegularSmallModeLightStateDefault className="!absolute !right-[18px] !left-[19px] !bottom-[27px] !top-[712px] !w-[unset] !h-[unset]"></LiquidGlassRegularSmallModeLightStateDefault>
      </div>
      <div className="text-[#ffffff] text-left font-['HankenGrotesk-Medium',_sans-serif] text-lg font-medium absolute left-[163px] top-[724px]">
        다음으로{" "}
      </div>
      <img
        className="w-[25px] h-0 absolute left-[323px] top-[736px] overflow-visible"
        src="arrow-10.svg"
      />
      <div
        className="bg-[#ffffff] rounded-lg w-[323px] h-[79px] absolute left-[35px] top-[566px]"
        style={{ boxShadow: "2px 3px 15px 2px rgba(45, 122, 79, 1.00)" }}
      ></div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[51px] top-[585px]">
        유분 때문에 화장이 무너지지 않고 유지된다{" "}
      </div>
      <div className="text-[#9d9d9d] text-left font-['HankenGrotesk-Regular',_sans-serif] text-[8px] font-normal absolute left-[51px] top-[614px]">
        유분 과다로 인한 메이크업 무너짐이 없으며 보습력이 하루 종일 편안해요.{" "}
      </div>
      <div className="rounded-[50%] border-solid border-[#d3d3d3] border w-[26px] h-[26px] absolute left-[315px] top-[593px]"></div>
      <div
        className="bg-[#ffffff] rounded-lg w-[323px] h-[79px] absolute left-[35px] top-[473px]"
        style={{ boxShadow: "2px 3px 15px 2px rgba(45, 122, 79, 1.00)" }}
      ></div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[51px] top-[492px]">
        시간이 지나면 코 주변만 살짝 지워지는 정도다{" "}
      </div>
      <div className="text-[#9d9d9d] text-left font-['HankenGrotesk-Regular',_sans-serif] text-[8px] font-normal absolute left-[51px] top-[521px]">
        T존 부위에만 약간의 유분이 돌 뿐, 전반적으로 무너짐이 심하지 않아요.{" "}
      </div>
      <div className="rounded-[50%] border-solid border-[#d3d3d3] border w-[26px] h-[26px] absolute left-[315px] top-[500px]"></div>
      <div
        className="bg-[#ffffff] rounded-lg w-[323px] h-[79px] absolute left-[35px] top-[380px]"
        style={{ boxShadow: "2px 3px 15px 2px rgba(45, 122, 79, 1.00)" }}
      ></div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[51px] top-[399px]">
        겉은 번들거리는데 속은 당겨서 화장이 뜬다{" "}
      </div>
      <div className="text-[#9d9d9d] text-left font-['HankenGrotesk-Regular',_sans-serif] text-[8px] font-normal absolute left-[51px] top-[428px]">
        유분 때문에 겉은 번들거리지만 속은 건조해 메이크업이 갈라지고 들떠요.{" "}
      </div>
      <div className="rounded-[50%] border-solid border-[#d3d3d3] border w-[26px] h-[26px] absolute left-[315px] top-[407px]"></div>
      <div
        className="bg-[#ffffff] rounded-lg w-[323px] h-[79px] absolute left-[35px] top-[287px]"
        style={{ boxShadow: "2px 3px 15px 2px rgba(45, 122, 79, 1.00)" }}
      ></div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[50px] top-[306px]">
        기름이 올라와 지워지듯 온 동네가 번들거린다{" "}
      </div>
      <div className="text-[#9d9d9d] text-left font-['HankenGrotesk-Regular',_sans-serif] text-[8px] font-normal absolute left-[51px] top-[334px]">
        과도한 피지 분비로 인해 화장이 밀리거나 얼굴이 기름으로 번들해져요.{" "}
      </div>
      <div className="rounded-[50%] border-solid border-[#d3d3d3] border w-[26px] h-[26px] absolute left-[315px] top-[314px]"></div>
      <div className="text-[#b3b3b3] text-left font-['HankenGrotesk-SemiBold',_sans-serif] text-[10px] font-semibold absolute left-[39px] top-[225px]">
        자신의 피부 상태에 가장 가까운 것을 선택해 주세요.{" "}
      </div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Bold',_sans-serif] text-[19px] font-bold absolute left-[38px] top-[166px]">
        기름종이를 쓰거나 메이크업을 했을 때<br />
        무너지는 스타일은 어떤가요?{" "}
      </div>
      <div className="text-[#2d7a4f] text-left font-['HankenGrotesk-SemiBold',_sans-serif] text-xl font-semibold absolute left-[37px] top-[133px]">
        Q5.{" "}
      </div>
      <div
        className="text-[#2d7a4f] text-left font-['Inter-BoldItalic',_sans-serif] text-[13px] font-bold absolute left-[324px] top-[58px]"
        style={{ fontStyle: "italic" }}
      >
        05{" "}
      </div>
      <div
        className="text-[#000000] text-left font-['HankenGrotesk-BoldItalic',_sans-serif] text-[10px] font-bold absolute left-[342px] top-[60px]"
        style={{ fontStyle: "italic" }}
      >
        /{" "}
      </div>
      <div
        className="text-[#000000] text-left font-['HankenGrotesk-BoldItalic',_sans-serif] text-[10px] font-bold absolute left-[348px] top-[61px]"
        style={{ fontStyle: "italic" }}
      >
        06{" "}
      </div>
      <div className="bg-[#d9d9d9] rounded-[20px] w-[222px] h-1 absolute left-[84px] top-16"></div>
      <div className="bg-[#2d7a4f] rounded-[20px] w-[185px] h-1 absolute left-[84px] top-16"></div>
      <div className="bg-[#d9d9d9] rounded-[50%] w-[29px] h-[29px] absolute left-[23px] top-[50px]"></div>
      <ChevronLeftSize48 className="!w-[21px] !h-[21px] !absolute !left-[26px] !top-[54px] !shrink-[unset]"></ChevronLeftSize48>
      <BuildingBlocksStatusBar
        cameraCutout={false}
        className="!w-[396px] !h-[37px] !absolute !left-[-2px] !top-0"
      ></BuildingBlocksStatusBar>
    </div>
  );
};
