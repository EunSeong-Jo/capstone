import "./styles.css";
import "./tailwind.css";
import { Four } from "./Four/Four";

export default function App() {
  return (
    <div>
      <Four />
    </div>
  );
}
