export interface IChevronLeftSize48Props {
  size?: "20" | "24" | "32" | "40" | "48" | "16";
  className?: string;
}

export const ChevronLeftSize48 = ({
  size = "48",
  className,
  ...props
}: IChevronLeftSize48Props): JSX.Element => {
  const variantsClassName = "size-" + size;

  return (
    <img
      className={
        "w-[21px] h-[21px] relative overflow-visible " +
        className +
        " " +
        variantsClassName
      }
      src="chevron-left-size-48.svg"
    />
  );
};
