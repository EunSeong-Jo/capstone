import "./styles.css";
import "./tailwind.css";
import { Six } from "./Six/Six";

export default function App() {
  return (
    <div>
      <Six />
    </div>
  );
}
