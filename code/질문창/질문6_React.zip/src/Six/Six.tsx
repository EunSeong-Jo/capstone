import { LiquidGlassRegularSmallModeLightStateDefault } from "../LiquidGlassRegularSmallModeLightStateDefault/LiquidGlassRegularSmallModeLightStateDefault";
import { ChevronLeftSize48 } from "../ChevronLeftSize48/ChevronLeftSize48";
import { BuildingBlocksStatusBar } from "../BuildingBlocksStatusBar/BuildingBlocksStatusBar";

export interface ISixProps {
  className?: string;
}

export const Six = ({ className, ...props }: ISixProps): JSX.Element => {
  return (
    <div
      className={"bg-[#ffffff] h-[787px] relative overflow-hidden " + className}
    >
      <div className="w-[356px] h-12 static">
        <LiquidGlassRegularSmallModeLightStateDefault className="!absolute !right-[18px] !left-[19px] !bottom-[27px] !top-[712px] !w-[unset] !h-[unset]"></LiquidGlassRegularSmallModeLightStateDefault>
      </div>
      <div className="text-[#ffffff] text-left font-['HankenGrotesk-Medium',_sans-serif] text-lg font-medium absolute left-[147px] top-[724px]">
        결과보러가기{" "}
      </div>
      <img
        className="w-[25px] h-0 absolute left-[323px] top-[736px] overflow-visible"
        src="arrow-10.svg"
      />
      <div
        className="bg-[#ffffff] rounded-lg w-[323px] h-[79px] absolute left-[35px] top-[566px]"
        style={{ boxShadow: "2px 3px 15px 2px rgba(45, 122, 79, 1.00)" }}
      ></div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[51px] top-[579px]">
        미백이나 주름 개선 등 <br />
        확실한 효과를 주는 고기능성 앰플{" "}
      </div>
      <div className="text-[#9d9d9d] text-left font-['HankenGrotesk-Regular',_sans-serif] text-[8px] font-normal absolute left-[51px] top-[622px]">
        단순 보습을 넘어 내 피부 고민을 빠르게 해결해 줄 기능성 케어를 선호해요.{" "}
      </div>
      <div className="rounded-[50%] border-solid border-[#d3d3d3] border w-[26px] h-[26px] absolute left-[315px] top-[593px]"></div>
      <div
        className="bg-[#ffffff] rounded-lg w-[323px] h-[79px] absolute left-[35px] top-[473px]"
        style={{ boxShadow: "2px 3px 15px 2px rgba(45, 122, 79, 1.00)" }}
      ></div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[51px] top-[492px]">
        자극 성분이 없는 순한 화장품{" "}
      </div>
      <div className="text-[#9d9d9d] text-left font-['HankenGrotesk-Regular',_sans-serif] text-[8px] font-normal absolute left-[51px] top-[521px]">
        기능성 성분보다는 오직 피부가 편안하고 안전한 무첨가 제품을 선호해요.{" "}
      </div>
      <div className="rounded-[50%] border-solid border-[#d3d3d3] border w-[26px] h-[26px] absolute left-[315px] top-[500px]"></div>
      <div
        className="bg-[#ffffff] rounded-lg w-[323px] h-[79px] absolute left-[35px] top-[380px]"
        style={{ boxShadow: "2px 3px 15px 2px rgba(45, 122, 79, 1.00)" }}
      ></div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[51px] top-[399px]">
        영양을 채워주고 보호막을 씌워주는 쫀쫀한 크림{" "}
      </div>
      <div className="text-[#9d9d9d] text-left font-['HankenGrotesk-Regular',_sans-serif] text-[8px] font-normal absolute left-[51px] top-[428px]">
        가벼운 제형은 금방 날아가는 느낌이라 유수분을 잡아주는 텍스처를
        선호해요.{" "}
      </div>
      <div className="rounded-[50%] border-solid border-[#d3d3d3] border w-[26px] h-[26px] absolute left-[315px] top-[407px]"></div>
      <div
        className="bg-[#ffffff] rounded-lg w-[323px] h-[79px] absolute left-[35px] top-[287px]"
        style={{ boxShadow: "2px 3px 15px 2px rgba(45, 122, 79, 1.00)" }}
      ></div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[50px] top-[306px]">
        끈적임 없고 촉촉하게 스며드는 가벼운 에센스{" "}
      </div>
      <div className="text-[#9d9d9d] text-left font-['HankenGrotesk-Regular',_sans-serif] text-[8px] font-normal absolute left-[51px] top-[335px]">
        무겁거나 답답한 느낌이 싫어 수분감 위주의 가볍고 빠른 흡수력을 선호해요.{" "}
      </div>
      <div className="rounded-[50%] border-solid border-[#d3d3d3] border w-[26px] h-[26px] absolute left-[315px] top-[314px]"></div>
      <div className="text-[#b3b3b3] text-left font-['HankenGrotesk-SemiBold',_sans-serif] text-[10px] font-semibold absolute left-[39px] top-[225px]">
        자신의 피부 상태에 가장 가까운 것을 선택해 주세요.{" "}
      </div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Bold',_sans-serif] text-[19px] font-bold absolute left-[38px] top-[166px]">
        평소 스킨케어를 고를 때 가장 중요하게 <br />
        생각하는 포인트는 무엇인가요?{" "}
      </div>
      <div className="text-[#2d7a4f] text-left font-['HankenGrotesk-SemiBold',_sans-serif] text-xl font-semibold absolute left-[37px] top-[133px]">
        Q6.{" "}
      </div>
      <div
        className="text-[#2d7a4f] text-left font-['Inter-BoldItalic',_sans-serif] text-[13px] font-bold absolute left-[324px] top-[58px]"
        style={{ fontStyle: "italic" }}
      >
        06{" "}
      </div>
      <div
        className="text-[#000000] text-left font-['HankenGrotesk-BoldItalic',_sans-serif] text-[10px] font-bold absolute left-[342px] top-[60px]"
        style={{ fontStyle: "italic" }}
      >
        /{" "}
      </div>
      <div
        className="text-[#000000] text-left font-['HankenGrotesk-BoldItalic',_sans-serif] text-[10px] font-bold absolute left-[348px] top-[61px]"
        style={{ fontStyle: "italic" }}
      >
        06{" "}
      </div>
      <div className="bg-[#d9d9d9] rounded-[20px] w-[222px] h-1 absolute left-[84px] top-16"></div>
      <div className="bg-[#2d7a4f] rounded-[20px] w-[222px] h-1 absolute left-[84px] top-16"></div>
      <div className="bg-[#d9d9d9] rounded-[50%] w-[29px] h-[29px] absolute left-[23px] top-[50px]"></div>
      <ChevronLeftSize48 className="!w-[21px] !h-[21px] !absolute !left-[26px] !top-[54px] !shrink-[unset]"></ChevronLeftSize48>
      <BuildingBlocksStatusBar
        cameraCutout={false}
        className="!w-[396px] !h-[37px] !absolute !left-[-2px] !top-0"
      ></BuildingBlocksStatusBar>
    </div>
  );
};
