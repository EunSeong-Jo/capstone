import { LiquidGlassRegularSmallModeLightStateDefault } from "../LiquidGlassRegularSmallModeLightStateDefault/LiquidGlassRegularSmallModeLightStateDefault";
import { ChevronLeftSize48 } from "../ChevronLeftSize48/ChevronLeftSize48";
import { BuildingBlocksStatusBar } from "../BuildingBlocksStatusBar/BuildingBlocksStatusBar";

export interface IThreeProps {
  className?: string;
}

export const Three = ({ className, ...props }: IThreeProps): JSX.Element => {
  return (
    <div
      className={"bg-[#ffffff] h-[787px] relative overflow-hidden " + className}
    >
      <div className="w-[356px] h-12 static">
        <LiquidGlassRegularSmallModeLightStateDefault className="!absolute !right-[18px] !left-[19px] !bottom-[27px] !top-[712px] !w-[unset] !h-[unset]"></LiquidGlassRegularSmallModeLightStateDefault>
      </div>
      <div className="text-[#ffffff] text-left font-['HankenGrotesk-Medium',_sans-serif] text-lg font-medium absolute left-[163px] top-[724px]">
        다음으로{" "}
      </div>
      <img
        className="w-[25px] h-0 absolute left-[323px] top-[736px] overflow-visible"
        src="arrow-10.svg"
      />
      <div
        className="bg-[#ffffff] rounded-lg w-[323px] h-[79px] absolute left-[35px] top-[566px]"
        style={{ boxShadow: "2px 3px 15px 2px rgba(45, 122, 79, 1.00)" }}
      ></div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[51px] top-[585px]">
        트러블이나 염증성 고민이 거의 없이 깨끗하다{" "}
      </div>
      <div className="text-[#9d9d9d] text-left font-['HankenGrotesk-Regular',_sans-serif] text-[8px] font-normal absolute left-[51px] top-[614px]">
        피부에 유해한 염증이나 뾰루지 걱정이 거의 없는 청정 피부예요{" "}
      </div>
      <div className="rounded-[50%] border-solid border-[#d3d3d3] border w-[26px] h-[26px] absolute left-[315px] top-[593px]"></div>
      <div
        className="bg-[#ffffff] rounded-lg w-[323px] h-[79px] absolute left-[35px] top-[473px]"
        style={{ boxShadow: "2px 3px 15px 2px rgba(45, 122, 79, 1.00)" }}
      ></div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[51px] top-[487px]">
        생리 전이나 컨디션이 <br />안 좋을 때만 한두 개씩 올라온다{" "}
      </div>
      <div className="text-[#9d9d9d] text-left font-['HankenGrotesk-Regular',_sans-serif] text-[8px] font-normal absolute left-[51px] top-[528px]">
        가끔 호르몬 변화나 피로 때문에 일시적으로 트러블이 스쳐 지나가요{" "}
      </div>
      <div className="rounded-[50%] border-solid border-[#d3d3d3] border w-[26px] h-[26px] absolute left-[315px] top-[500px]"></div>
      <div
        className="bg-[#ffffff] rounded-lg w-[323px] h-[79px] absolute left-[35px] top-[380px]"
        style={{ boxShadow: "2px 3px 15px 2px rgba(45, 122, 79, 1.00)" }}
      ></div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[51px] top-[393px]">
        유분이 많아 좁쌀 여드름이나 <br />
        블랙헤드가 자주 생긴다{" "}
      </div>
      <div className="text-[#9d9d9d] text-left font-['HankenGrotesk-Regular',_sans-serif] text-[8px] font-normal absolute left-[51px] top-[434px]">
        큰 염증은 없지만 모공 속에 피지가 고여 오돌토돌한 좁쌀이 고민이에요.{" "}
      </div>
      <div className="rounded-[50%] border-solid border-[#d3d3d3] border w-[26px] h-[26px] absolute left-[315px] top-[407px]"></div>
      <div
        className="bg-[#ffffff] rounded-lg w-[323px] h-[79px] absolute left-[35px] top-[287px]"
        style={{ boxShadow: "2px 3px 15px 2px rgba(45, 122, 79, 1.00)" }}
      ></div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[13px] font-medium absolute left-[51px] top-[303px]">
        365일 큰 염증과 붉은 기가 가라앉지 않는다{" "}
      </div>
      <div className="text-[#9d9d9d] text-left font-['HankenGrotesk-Regular',_sans-serif] text-[8px] font-normal absolute left-[51px] top-[330px]">
        얼굴이 늘 울긋불긋하거나
        <br />
        화농성 염증이 자주 반복되어 장기적인 진정이 필요해요.{" "}
      </div>
      <div className="rounded-[50%] border-solid border-[#d3d3d3] border w-[26px] h-[26px] absolute left-[315px] top-[314px]"></div>
      <div className="text-[#b3b3b3] text-left font-['HankenGrotesk-SemiBold',_sans-serif] text-[10px] font-semibold absolute left-[39px] top-[225px]">
        자신의 피부 상태에 가장 가까운 것을 선택해 주세요.{" "}
      </div>
      <div className="text-[#000000] text-left font-['HankenGrotesk-Bold',_sans-serif] text-[19px] font-bold absolute left-[38px] top-[166px]">
        평소 여드름, 붉은 홍조, 혹은 <br />
        화농성 염증이 얼마나 자주 발생하나요?{" "}
      </div>
      <div className="text-[#2d7a4f] text-left font-['HankenGrotesk-SemiBold',_sans-serif] text-xl font-semibold absolute left-[37px] top-[133px]">
        Q3.{" "}
      </div>
      <div className="w-9 h-4 static">
        <div
          className="text-[#2d7a4f] text-left font-['Inter-BoldItalic',_sans-serif] text-[13px] font-bold absolute left-[324px] top-[58px]"
          style={{ fontStyle: "italic" }}
        >
          03{" "}
        </div>
        <div
          className="text-[#000000] text-left font-['HankenGrotesk-BoldItalic',_sans-serif] text-[10px] font-bold absolute left-[342px] top-[60px]"
          style={{ fontStyle: "italic" }}
        >
          /{" "}
        </div>
        <div
          className="text-[#000000] text-left font-['HankenGrotesk-BoldItalic',_sans-serif] text-[10px] font-bold absolute left-[348px] top-[61px]"
          style={{ fontStyle: "italic" }}
        >
          06{" "}
        </div>
      </div>
      <div className="bg-[#d9d9d9] rounded-[20px] w-[222px] h-1 absolute left-[84px] top-16"></div>
      <div className="bg-[#2d7a4f] rounded-[20px] w-[111px] h-1 absolute left-[84px] top-16"></div>
      <div className="bg-[#d9d9d9] rounded-[50%] w-[29px] h-[29px] absolute left-[23px] top-[50px]"></div>
      <ChevronLeftSize48 className="!w-[21px] !h-[21px] !absolute !left-[26px] !top-[54px] !shrink-[unset]"></ChevronLeftSize48>
      <BuildingBlocksStatusBar
        cameraCutout={false}
        className="!w-[396px] !h-[37px] !absolute !left-[-2px] !top-0"
      ></BuildingBlocksStatusBar>
    </div>
  );
};
