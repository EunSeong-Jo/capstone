export interface IComponent1Props {
  className?: string;
}

export const Component1 = ({
  className,
  ...props
}: IComponent1Props): JSX.Element => {
  return (
    <div
      className={"w-[138px] h-[180px] relative " + className}
      style={{ boxShadow: "6px 6px 25px 0px rgba(120, 230, 255, 0.18)" }}
    >
      <div className="bg-[#f6fffc] rounded-tl-[10px] rounded-tr-[10px] border-solid border-[#efeff0] border-[0.3px] w-[100%] h-[60.78%] absolute right-[0%] left-[0%] bottom-[37.91%] top-[1.31%]"></div>
      <div className="bg-[#ffffff] rounded-br-[10px] rounded-bl-[10px] border-solid border-[#efeff0] border-r-[0.3px] border-b-[0.3px] border-l-[0.3px] w-[100%] h-[39.22%] absolute right-[0%] left-[0%] bottom-[-1.31%] top-[62.09%]"></div>
      <div className="text-[#2c00ca] text-left font-['Geom-Bold',_sans-serif] text-[7px] font-bold absolute right-[64.96%] left-[6.84%] w-[28.21%] bottom-[26.14%] top-[66.01%] h-[7.84%]">
        DR.G{" "}
      </div>
    </div>
  );
};
