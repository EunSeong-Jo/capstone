export interface IShoppingBagProps {
  className?: string;
}

export const ShoppingBag = ({
  className,
  ...props
}: IShoppingBagProps): JSX.Element => {
  return (
    <img
      className={"w-4 h-4 relative overflow-visible " + className}
      src="shopping-bag.svg"
    />
  );
};
