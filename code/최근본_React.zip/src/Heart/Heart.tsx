export interface IHeartProps {
  className?: string;
}

export const Heart = ({ className, ...props }: IHeartProps): JSX.Element => {
  return (
    <img
      className={"w-4 h-4 relative overflow-visible " + className}
      src="heart.svg"
    />
  );
};
