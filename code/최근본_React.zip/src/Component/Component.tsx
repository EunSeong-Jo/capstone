import { Component1 } from "../Component1/Component1";
import { Heart } from "../Heart/Heart";
import { ShoppingBag } from "../ShoppingBag/ShoppingBag";
import { BuildingBlocksStatusBar } from "../BuildingBlocksStatusBar/BuildingBlocksStatusBar";
import { ShoppingCartSize20 } from "../ShoppingCartSize20/ShoppingCartSize20";
import { SearchSize20 } from "../SearchSize20/SearchSize20";
import { LiquidGlassRegularSmallModeLightStateDefault } from "../LiquidGlassRegularSmallModeLightStateDefault/LiquidGlassRegularSmallModeLightStateDefault";
import { Search } from "../Search/Search";
import { HomeSize20 } from "../HomeSize20/HomeSize20";
import { Menu } from "../Menu/Menu";
import { Stars } from "../Stars/Stars";
import { AccountCircle } from "../AccountCircle/AccountCircle";

export interface IComponentProps {
  className?: string;
}

export const Component = ({
  className,
  ...props
}: IComponentProps): JSX.Element => {
  return (
    <div
      className={
        "bg-[#ffffff] h-[1163px] relative overflow-hidden " + className
      }
    >
      <div
        className="w-[138px] h-[180px] absolute left-[19px] top-[890px]"
        style={{ boxShadow: "6px 6px 25px 0px rgba(120, 230, 255, 0.18)" }}
      >
        <div className="bg-[#f6fffc] rounded-tl-[10px] rounded-tr-[10px] border-solid border-[#efeff0] border-[0.3px] w-[100%] h-[60.78%] absolute right-[0%] left-[0%] bottom-[37.91%] top-[1.31%]"></div>
        <div className="bg-[#ffffff] rounded-br-[10px] rounded-bl-[10px] border-solid border-[#efeff0] border-r-[0.3px] border-b-[0.3px] border-l-[0.3px] w-[100%] h-[39.22%] absolute right-[0%] left-[0%] bottom-[-1.31%] top-[62.09%]"></div>
        <div className="text-[#2c00ca] text-left font-['Geom-Bold',_sans-serif] text-[7px] font-bold absolute right-[64.96%] left-[6.84%] w-[28.21%] bottom-[26.14%] top-[66.01%] h-[7.84%]">
          DR.G{" "}
        </div>
      </div>
      <div className="w-[129.74px] h-[41.18px] static">
        <img
          className="w-[7.5%] h-[8.24px] absolute right-[85.56%] left-[6.94%] top-[1035.88px]"
          style={{ objectFit: "cover" }}
          src="image-10.png"
        />
        <div className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[4px] font-light absolute left-[57.92px] top-[1037.06px] w-[23.59px] h-[8.24px]">
          5.0 (8.7k){" "}
        </div>
        <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[8px] font-semibold absolute left-[27.26px] top-[1051.18px] w-[43.64px] h-[11.76px]">
          24,300원{" "}
        </div>
        <div
          className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[6px] font-light absolute left-[70.9px] top-[1052.35px] w-[61.3px] h-[10.59px]"
          style={{ textDecoration: "line-through" }}
        >
          32,000원{" "}
        </div>
        <div className="text-[#000000] text-left font-['Geom-Medium',_sans-serif] text-[8px] font-medium absolute left-[27.26px] top-[1021.76px] w-[129.74px] h-[11.76px]">
          브라이트닝 업 선크림 SPF50+{" "}
        </div>
      </div>
      <div className="bg-[#40cda0] rounded-[3px] w-[28.31px] h-[12.94px] absolute left-[23.72px] top-[899.41px]"></div>
      <div className="text-[#ffffff] text-left font-['Geom-Bold',_sans-serif] text-[7px] font-bold absolute left-[29.62px] top-[900.59px] w-[20.43px] h-[10.59px]">
        24%{" "}
      </div>
      <Component1 className="!absolute !left-[317px] !top-[892px]"></Component1>
      <div className="w-[129.74px] h-[41.18px] static">
        <img
          className="w-[7.5%] h-[8.24px] absolute right-[4.14%] left-[88.36%] top-[1035.88px]"
          style={{ objectFit: "cover" }}
          src="image-11.png"
        />
        <div className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[4px] font-light absolute left-[377.92px] top-[1037.06px] w-[23.59px] h-[8.24px]">
          5.0 (8.7k){" "}
        </div>
        <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[8px] font-semibold absolute left-[347.26px] top-[1051.18px] w-[43.64px] h-[11.76px]">
          24,300원{" "}
        </div>
        <div
          className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[6px] font-light absolute left-[390.9px] top-[1052.35px] w-[61.3px] h-[10.59px]"
          style={{ textDecoration: "line-through" }}
        >
          32,000원{" "}
        </div>
        <div className="text-[#000000] text-left font-['Geom-Medium',_sans-serif] text-[8px] font-medium absolute left-[347.26px] top-[1021.76px] w-[129.74px] h-[11.76px]">
          브라이트닝 업 선크림 SPF50+{" "}
        </div>
      </div>
      <div className="bg-[#40cda0] rounded-[3px] w-[28.31px] h-[12.94px] absolute left-[343.72px] top-[899.41px]"></div>
      <div className="text-[#ffffff] text-left font-['Geom-Bold',_sans-serif] text-[7px] font-bold absolute left-[350px] top-[900px] w-[20.43px] h-[10.59px]">
        24%{" "}
      </div>
      <Component1 className="!absolute !left-[168px] !top-[890px]"></Component1>
      <div className="w-[129.74px] h-[41.18px] static">
        <img
          className="w-[7.5%] h-[8.24px] absolute right-[47.65%] left-[44.85%] top-[1035.88px]"
          style={{ objectFit: "cover" }}
          src="image-12.png"
        />
        <div className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[4px] font-light absolute left-[206.92px] top-[1037.06px] w-[23.59px] h-[8.24px]">
          5.0 (8.7k){" "}
        </div>
        <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[8px] font-semibold absolute left-[176.26px] top-[1051.18px] w-[43.64px] h-[11.76px]">
          24,300원{" "}
        </div>
        <div
          className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[6px] font-light absolute left-[219.9px] top-[1052.35px] w-[61.3px] h-[10.59px]"
          style={{ textDecoration: "line-through" }}
        >
          32,000원{" "}
        </div>
        <div className="text-[#000000] text-left font-['Geom-Medium',_sans-serif] text-[8px] font-medium absolute left-[176.26px] top-[1021.76px] w-[129.74px] h-[11.76px]">
          브라이트닝 업 선크림 SPF50+{" "}
        </div>
      </div>
      <div className="bg-[#40cda0] rounded-[3px] w-[28.31px] h-[12.94px] absolute left-[172.72px] top-[899.41px]"></div>
      <div className="text-[#ffffff] text-left font-['Geom-Bold',_sans-serif] text-[7px] font-bold absolute left-[178.62px] top-[900.59px] w-[20.43px] h-[10.59px]">
        24%{" "}
      </div>
      <div className="w-[355px] h-[100px] static">
        <div
          className="bg-[#ffffff] rounded-[10px] border-solid border-[#efeff0] border w-[355px] h-[100px] absolute left-[18px] top-[283px]"
          style={{ boxShadow: "6px 6px 25px 0px rgba(120, 230, 255, 0.18)" }}
        ></div>
        <div className="bg-[#b4b4b4] rounded-[10px] w-[72px] h-[72px] absolute left-8 top-[299px]"></div>
        <div className="w-[167px] h-[69px] static">
          <div className="text-[#2c00ca] text-left font-['Geom-Bold',_sans-serif] text-[8px] font-bold absolute left-[118px] top-[298px] w-[26px] h-3.5">
            DR.G{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-Medium',_sans-serif] text-[13px] font-medium absolute left-[118px] top-[316px]">
            브라이트닝 업 선크림 SPF50+{" "}
          </div>
          <div className="text-[#2c00ca] text-left font-['Geom-Bold',_sans-serif] text-[7px] font-bold absolute left-[118px] top-[356px]">
            24%{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[10px] font-semibold absolute left-[138px] top-[354px]">
            24,300원{" "}
          </div>
          <div
            className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[188px] top-[357px] w-[45px] h-[9px]"
            style={{ textDecoration: "line-through" }}
          >
            32,000원{" "}
          </div>
          <div className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[166px] top-[340px] w-[45px] h-[9px]">
            5.0 (8.7k){" "}
          </div>
          <img
            className="w-[43px] h-3 absolute left-[121px] top-[338px]"
            style={{ objectFit: "cover", aspectRatio: "43/12" }}
            src="image-13.png"
          />
        </div>
      </div>
      <div className="w-[167px] h-[69px] static">
        <div className="w-[167px] h-[69px] static">
          <div className="text-[#2c00ca] text-left font-['Geom-Bold',_sans-serif] text-[8px] font-bold absolute left-[118px] top-[298px] w-[26px] h-3.5">
            DR.G{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-Medium',_sans-serif] text-[13px] font-medium absolute left-[118px] top-[316px]">
            브라이트닝 업 선크림 SPF50+{" "}
          </div>
          <div className="text-[#2c00ca] text-left font-['Geom-Bold',_sans-serif] text-[7px] font-bold absolute left-[118px] top-[356px]">
            24%{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[10px] font-semibold absolute left-[138px] top-[354px]">
            24,300원{" "}
          </div>
          <div
            className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[188px] top-[357px] w-[45px] h-[9px]"
            style={{ textDecoration: "line-through" }}
          >
            32,000원{" "}
          </div>
          <div className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[166px] top-[340px] w-[45px] h-[9px]">
            5.0 (8.7k){" "}
          </div>
          <img
            className="w-[43px] h-3 absolute left-[121px] top-[338px]"
            style={{ objectFit: "cover", aspectRatio: "43/12" }}
            src="image-14.png"
          />
        </div>
      </div>
      <Heart className="!absolute !left-[340px] !top-[311px]"></Heart>
      <ShoppingBag className="!absolute !left-[340px] !top-[345px]"></ShoppingBag>
      <div className="w-[355px] h-[100px] static">
        <div
          className="bg-[#ffffff] rounded-[10px] border-solid border-[#efeff0] border w-[355px] h-[100px] absolute left-[18px] top-[739px]"
          style={{ boxShadow: "6px 6px 25px 0px rgba(120, 230, 255, 0.18)" }}
        ></div>
        <div className="bg-[#b4b4b4] rounded-[10px] w-[72px] h-[72px] absolute left-8 top-[755px]"></div>
        <div className="w-[167px] h-[69px] static">
          <div className="text-[#2c00ca] text-left font-['Geom-Bold',_sans-serif] text-[8px] font-bold absolute left-[118px] top-[754px] w-[26px] h-3.5">
            DR.G{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-Medium',_sans-serif] text-[13px] font-medium absolute left-[118px] top-[772px]">
            브라이트닝 업 선크림 SPF50+{" "}
          </div>
          <div className="text-[#2c00ca] text-left font-['Geom-Bold',_sans-serif] text-[7px] font-bold absolute left-[118px] top-[812px]">
            24%{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[10px] font-semibold absolute left-[138px] top-[810px]">
            24,300원{" "}
          </div>
          <div
            className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[188px] top-[813px] w-[45px] h-[9px]"
            style={{ textDecoration: "line-through" }}
          >
            32,000원{" "}
          </div>
          <div className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[166px] top-[796px] w-[45px] h-[9px]">
            5.0 (8.7k){" "}
          </div>
          <img
            className="w-[43px] h-3 absolute left-[121px] top-[794px]"
            style={{ objectFit: "cover", aspectRatio: "43/12" }}
            src="image-15.png"
          />
        </div>
      </div>
      <div className="w-[167px] h-[69px] static">
        <div className="w-[167px] h-[69px] static">
          <div className="text-[#2c00ca] text-left font-['Geom-Bold',_sans-serif] text-[8px] font-bold absolute left-[118px] top-[754px] w-[26px] h-3.5">
            DR.G{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-Medium',_sans-serif] text-[13px] font-medium absolute left-[118px] top-[772px]">
            브라이트닝 업 선크림 SPF50+{" "}
          </div>
          <div className="text-[#2c00ca] text-left font-['Geom-Bold',_sans-serif] text-[7px] font-bold absolute left-[118px] top-[812px]">
            24%{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[10px] font-semibold absolute left-[138px] top-[810px]">
            24,300원{" "}
          </div>
          <div
            className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[188px] top-[813px] w-[45px] h-[9px]"
            style={{ textDecoration: "line-through" }}
          >
            32,000원{" "}
          </div>
          <div className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[166px] top-[796px] w-[45px] h-[9px]">
            5.0 (8.7k){" "}
          </div>
          <img
            className="w-[43px] h-3 absolute left-[121px] top-[794px]"
            style={{ objectFit: "cover", aspectRatio: "43/12" }}
            src="image-16.png"
          />
        </div>
      </div>
      <Heart className="!absolute !left-[340px] !top-[767px]"></Heart>
      <ShoppingBag className="!absolute !left-[340px] !top-[801px]"></ShoppingBag>
      <div className="w-[355px] h-[100px] static">
        <div
          className="bg-[#ffffff] rounded-[10px] border-solid border-[#efeff0] border w-[355px] h-[100px] absolute left-[18px] top-[625px]"
          style={{ boxShadow: "6px 6px 25px 0px rgba(120, 230, 255, 0.18)" }}
        ></div>
        <div className="bg-[#b4b4b4] rounded-[10px] w-[72px] h-[72px] absolute left-8 top-[641px]"></div>
        <div className="w-[167px] h-[69px] static">
          <div className="text-[#2c00ca] text-left font-['Geom-Bold',_sans-serif] text-[8px] font-bold absolute left-[118px] top-[640px] w-[26px] h-3.5">
            DR.G{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-Medium',_sans-serif] text-[13px] font-medium absolute left-[118px] top-[658px]">
            브라이트닝 업 선크림 SPF50+{" "}
          </div>
          <div className="text-[#2c00ca] text-left font-['Geom-Bold',_sans-serif] text-[7px] font-bold absolute left-[118px] top-[698px]">
            24%{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[10px] font-semibold absolute left-[138px] top-[696px]">
            24,300원{" "}
          </div>
          <div
            className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[188px] top-[699px] w-[45px] h-[9px]"
            style={{ textDecoration: "line-through" }}
          >
            32,000원{" "}
          </div>
          <div className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[166px] top-[682px] w-[45px] h-[9px]">
            5.0 (8.7k){" "}
          </div>
          <img
            className="w-[43px] h-3 absolute left-[121px] top-[680px]"
            style={{ objectFit: "cover", aspectRatio: "43/12" }}
            src="image-17.png"
          />
        </div>
      </div>
      <div className="w-[167px] h-[69px] static">
        <div className="w-[167px] h-[69px] static">
          <div className="text-[#2c00ca] text-left font-['Geom-Bold',_sans-serif] text-[8px] font-bold absolute left-[118px] top-[640px] w-[26px] h-3.5">
            DR.G{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-Medium',_sans-serif] text-[13px] font-medium absolute left-[118px] top-[658px]">
            브라이트닝 업 선크림 SPF50+{" "}
          </div>
          <div className="text-[#2c00ca] text-left font-['Geom-Bold',_sans-serif] text-[7px] font-bold absolute left-[118px] top-[698px]">
            24%{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[10px] font-semibold absolute left-[138px] top-[696px]">
            24,300원{" "}
          </div>
          <div
            className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[188px] top-[699px] w-[45px] h-[9px]"
            style={{ textDecoration: "line-through" }}
          >
            32,000원{" "}
          </div>
          <div className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[166px] top-[682px] w-[45px] h-[9px]">
            5.0 (8.7k){" "}
          </div>
          <img
            className="w-[43px] h-3 absolute left-[121px] top-[680px]"
            style={{ objectFit: "cover", aspectRatio: "43/12" }}
            src="image-18.png"
          />
        </div>
      </div>
      <Heart className="!absolute !left-[340px] !top-[653px]"></Heart>
      <ShoppingBag className="!absolute !left-[340px] !top-[687px]"></ShoppingBag>
      <div className="w-[355px] h-[100px] static">
        <div
          className="bg-[#ffffff] rounded-[10px] border-solid border-[#efeff0] border w-[355px] h-[100px] absolute left-[18px] top-[511px]"
          style={{ boxShadow: "6px 6px 25px 0px rgba(120, 230, 255, 0.18)" }}
        ></div>
        <div className="bg-[#b4b4b4] rounded-[10px] w-[72px] h-[72px] absolute left-8 top-[527px]"></div>
        <div className="w-[167px] h-[69px] static">
          <div className="text-[#2c00ca] text-left font-['Geom-Bold',_sans-serif] text-[8px] font-bold absolute left-[118px] top-[526px] w-[26px] h-3.5">
            DR.G{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-Medium',_sans-serif] text-[13px] font-medium absolute left-[118px] top-[544px]">
            브라이트닝 업 선크림 SPF50+{" "}
          </div>
          <div className="text-[#2c00ca] text-left font-['Geom-Bold',_sans-serif] text-[7px] font-bold absolute left-[118px] top-[584px]">
            24%{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[10px] font-semibold absolute left-[138px] top-[582px]">
            24,300원{" "}
          </div>
          <div
            className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[188px] top-[585px] w-[45px] h-[9px]"
            style={{ textDecoration: "line-through" }}
          >
            32,000원{" "}
          </div>
          <div className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[166px] top-[568px] w-[45px] h-[9px]">
            5.0 (8.7k){" "}
          </div>
          <img
            className="w-[43px] h-3 absolute left-[121px] top-[566px]"
            style={{ objectFit: "cover", aspectRatio: "43/12" }}
            src="image-19.png"
          />
        </div>
      </div>
      <div className="w-[167px] h-[69px] static">
        <div className="w-[167px] h-[69px] static">
          <div className="text-[#2c00ca] text-left font-['Geom-Bold',_sans-serif] text-[8px] font-bold absolute left-[118px] top-[526px] w-[26px] h-3.5">
            DR.G{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-Medium',_sans-serif] text-[13px] font-medium absolute left-[118px] top-[544px]">
            브라이트닝 업 선크림 SPF50+{" "}
          </div>
          <div className="text-[#2c00ca] text-left font-['Geom-Bold',_sans-serif] text-[7px] font-bold absolute left-[118px] top-[584px]">
            24%{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[10px] font-semibold absolute left-[138px] top-[582px]">
            24,300원{" "}
          </div>
          <div
            className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[188px] top-[585px] w-[45px] h-[9px]"
            style={{ textDecoration: "line-through" }}
          >
            32,000원{" "}
          </div>
          <div className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[166px] top-[568px] w-[45px] h-[9px]">
            5.0 (8.7k){" "}
          </div>
          <img
            className="w-[43px] h-3 absolute left-[121px] top-[566px]"
            style={{ objectFit: "cover", aspectRatio: "43/12" }}
            src="image-110.png"
          />
        </div>
      </div>
      <Heart className="!absolute !left-[340px] !top-[539px]"></Heart>
      <ShoppingBag className="!absolute !left-[340px] !top-[573px]"></ShoppingBag>
      <div className="w-[355px] h-[100px] static">
        <div
          className="bg-[#ffffff] rounded-[10px] border-solid border-[#efeff0] border w-[355px] h-[100px] absolute left-[18px] top-[397px]"
          style={{ boxShadow: "6px 6px 25px 0px rgba(120, 230, 255, 0.18)" }}
        ></div>
        <div className="bg-[#b4b4b4] rounded-[10px] w-[72px] h-[72px] absolute left-8 top-[413px]"></div>
        <div className="w-[167px] h-[69px] static">
          <div className="text-[#2c00ca] text-left font-['Geom-Bold',_sans-serif] text-[8px] font-bold absolute left-[118px] top-[412px] w-[26px] h-3.5">
            DR.G{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-Medium',_sans-serif] text-[13px] font-medium absolute left-[118px] top-[430px]">
            브라이트닝 업 선크림 SPF50+{" "}
          </div>
          <div className="text-[#2c00ca] text-left font-['Geom-Bold',_sans-serif] text-[7px] font-bold absolute left-[118px] top-[470px]">
            24%{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[10px] font-semibold absolute left-[138px] top-[468px]">
            24,300원{" "}
          </div>
          <div
            className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[188px] top-[471px] w-[45px] h-[9px]"
            style={{ textDecoration: "line-through" }}
          >
            32,000원{" "}
          </div>
          <div className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[166px] top-[454px] w-[45px] h-[9px]">
            5.0 (8.7k){" "}
          </div>
          <img
            className="w-[43px] h-3 absolute left-[121px] top-[452px]"
            style={{ objectFit: "cover", aspectRatio: "43/12" }}
            src="image-111.png"
          />
        </div>
      </div>
      <div className="w-[167px] h-[69px] static">
        <div className="w-[167px] h-[69px] static">
          <div className="text-[#2c00ca] text-left font-['Geom-Bold',_sans-serif] text-[8px] font-bold absolute left-[118px] top-[412px] w-[26px] h-3.5">
            DR.G{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-Medium',_sans-serif] text-[13px] font-medium absolute left-[118px] top-[430px]">
            브라이트닝 업 선크림 SPF50+{" "}
          </div>
          <div className="text-[#2c00ca] text-left font-['Geom-Bold',_sans-serif] text-[7px] font-bold absolute left-[118px] top-[470px]">
            24%{" "}
          </div>
          <div className="text-[#000000] text-left font-['Geom-SemiBold',_sans-serif] text-[10px] font-semibold absolute left-[138px] top-[468px]">
            24,300원{" "}
          </div>
          <div
            className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[188px] top-[471px] w-[45px] h-[9px]"
            style={{ textDecoration: "line-through" }}
          >
            32,000원{" "}
          </div>
          <div className="text-[#949494] text-left font-['Geom-Light',_sans-serif] text-[7px] font-light absolute left-[166px] top-[454px] w-[45px] h-[9px]">
            5.0 (8.7k){" "}
          </div>
          <img
            className="w-[43px] h-3 absolute left-[121px] top-[452px]"
            style={{ objectFit: "cover", aspectRatio: "43/12" }}
            src="image-112.png"
          />
        </div>
      </div>
      <Heart className="!absolute !left-[340px] !top-[425px]"></Heart>
      <ShoppingBag className="!absolute !left-[340px] !top-[459px]"></ShoppingBag>
      <div className="bg-[#40cda0] rounded-[10px] w-[33px] h-3.5 absolute left-[18px] top-[870px]"></div>
      <div
        className="text-[#ffffff] text-left font-['Inter-Medium',_sans-serif] text-[8px] font-medium absolute left-[23px] top-[872px]"
        style={{ letterSpacing: "-0.05em" }}
      >
        AI 추천{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Medium',_sans-serif] text-[13px] font-medium absolute left-[55px] top-[869px]">
        최근 관심 기반 추천{" "}
      </div>
      <div
        className="text-[#000000] text-left font-['Inter-BoldItalic',_sans-serif] text-[13px] font-bold absolute left-[21px] top-[253px]"
        style={{ fontStyle: "italic" }}
      >
        최근 본 상품{" "}
      </div>
      <img
        className="w-[371px] h-[94px] absolute left-[11px] top-[145px]"
        style={{ objectFit: "cover" }}
        src="image-20.png"
      />
      <div
        className="bg-[#ffffff] w-[395px] h-[126px] absolute left-[-2px] top-0"
        style={{ boxShadow: "0px 4px 4px 0px rgba(0, 0, 0, 0.10)" }}
      ></div>
      <BuildingBlocksStatusBar
        cameraCutout={false}
        className="!w-[396px] !h-[37px] !absolute !left-[-2px] !top-0"
      ></BuildingBlocksStatusBar>
      <div
        className="text-[#000000] text-left font-['Inter-BoldItalic',_sans-serif] text-xl font-bold absolute left-[19px] top-[50px]"
        style={{ fontStyle: "italic" }}
      >
        History{" "}
      </div>
      <ShoppingCartSize20
        size="20"
        className="!absolute !left-[350px] !top-14 !shrink-[unset]"
      ></ShoppingCartSize20>
      <div className="bg-[#ffffff] border-solid border-[#519288] border-b-2 w-[79px] h-[33px] absolute left-10 top-[92px]"></div>
      <div className="text-[#519288] text-left font-['Aubrey-Regular',_sans-serif] text-xs font-normal absolute left-[61px] top-[102px]">
        최근 본{" "}
      </div>
      <div className="bg-[#ffffff] w-[114.56px] h-[33px] absolute left-[137px] top-[92px]"></div>
      <div className="text-[rgba(162,162,162,0.64)] text-center font-['Aubrey-Regular',_sans-serif] text-xs font-normal absolute left-[138.33px] top-[104px] w-[109.23px]">
        나의 좋아요 상품{" "}
      </div>
      <div className="bg-[#ffffff] w-[79px] h-[33px] absolute left-[269px] top-[92px]"></div>
      <div className="text-[#a2a2a2] text-left font-['Aubrey-Regular',_sans-serif] text-xs font-normal absolute left-[285px] top-[102px]">
        자주 구매{" "}
      </div>
      <SearchSize20
        size="20"
        className="!w-[23px] !h-[23px] !absolute !left-[309px] !top-[54px] !shrink-[unset]"
      ></SearchSize20>
      <LiquidGlassRegularSmallModeLightStateDefault className="!w-[356px] !absolute !left-4 !bottom-6"></LiquidGlassRegularSmallModeLightStateDefault>
      <div className="w-[30px] h-[38px] static">
        <Search className="!w-[30px] !h-[30px] !absolute !left-[179px] !bottom-[37px]"></Search>
        <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-[180px] bottom-[29px]">
          SEARCH{" "}
        </div>
      </div>
      <div className="w-[29px] h-[39px] static">
        <HomeSize20
          size="20"
          className="!w-[29px] !h-[29px] !absolute !left-11 !bottom-[38px] !shrink-[unset]"
        ></HomeSize20>
        <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-12 bottom-7">
          HOME{" "}
        </div>
      </div>
      <div className="w-[38px] h-[38px] static">
        <Menu className="!w-[30px] !h-[30px] !absolute !left-[111px] !bottom-[37px]"></Menu>
        <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-[107px] bottom-[29px]">
          CATEGORY{" "}
        </div>
      </div>
      <div className="w-[31px] h-[37px] static">
        <Stars className="!w-[30px] !h-[30px] !absolute !left-[245px] !bottom-[37px]"></Stars>
        <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-[245px] bottom-[30px]">
          HISOTRY{" "}
        </div>
      </div>
      <div className="w-[30px] h-[39px] static">
        <AccountCircle className="!w-[30px] !h-[30px] !absolute !left-[315px] !bottom-[37px]"></AccountCircle>
        <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-[324px] bottom-7">
          MY{" "}
        </div>
      </div>
    </div>
  );
};
