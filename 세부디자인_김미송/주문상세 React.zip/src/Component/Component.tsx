import { BuildingBlocksStatusBar } from "../BuildingBlocksStatusBar/BuildingBlocksStatusBar";
import { ChevronBackward } from "../ChevronBackward/ChevronBackward";
import { LiquidGlassRegularSmallModeLightStateDefault } from "../LiquidGlassRegularSmallModeLightStateDefault/LiquidGlassRegularSmallModeLightStateDefault";

export interface IComponentProps {
  className?: string;
}

export const Component = ({
  className,
  ...props
}: IComponentProps): JSX.Element => {
  return (
    <div
      className={"bg-[#ffffff] h-[787px] relative overflow-hidden " + className}
    >
      <div className="bg-[#f6f6f6] w-[393px] h-[750px] absolute left-0 top-10"></div>
      <BuildingBlocksStatusBar
        cameraCutout={false}
        className="!w-[341px] !h-[37px] !absolute !left-[-2px] !top-0"
      ></BuildingBlocksStatusBar>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-sm font-normal absolute left-7 top-[49px] w-[79px]">
        주문상세{" "}
      </div>
      <ChevronBackward className="!w-[22px] !h-[25px] !absolute !left-1 !top-[45px]"></ChevronBackward>
      <div className="bg-[#ffffff] w-[339px] h-[55px] absolute left-0 top-[79px]"></div>
      <div className="bg-[#ffffff] w-[339px] h-[110px] absolute left-0 top-36"></div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-sm font-normal absolute left-3 top-[90px] w-[99px]">
        27.07.23 (목){" "}
      </div>
      <div className="text-[#a3a3a3] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-3 top-[111px] w-48">
        주문번호 151216510616504160465{" "}
      </div>
      <div className="text-[#a3a3a3] text-left font-['Inter-Regular',_sans-serif] text-[8px] font-normal absolute left-[233px] top-[154px] w-[100px]">
        교환 및 반품 문의 하러가기 &gt;{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-[11px] top-[182px] w-[33px]">
        받는 사람{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-[11px] top-[198px] w-7">
        연락처 1{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-[11px] top-[214px] w-[18px]">
        주소{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-[11px] top-[231px] w-7">
        기타사항{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-[65px] top-[182px] w-[35px]">
        김미송{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-[65px] top-[198px] w-[57px]">
        010-****-1234{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-[65px] top-[214px] w-[170px]">
        도로명 : 서울특별시 구로구 경인로 445(고척동){" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-[65px] top-[231px] w-[27px]">
        기타사항{" "}
      </div>
      <div
        className="border-solid border-[#dbdbdb] border-t border-r-[0] border-b-[0] border-l-[0] w-[340px] h-0 absolute left-0 top-[173px]"
        style={{ marginTop: "-1px" }}
      ></div>
      <div className="text-[#000000] text-left font-['Inter-Medium',_sans-serif] text-xs font-medium absolute left-[9px] top-[150px] w-[65px]">
        배송지 정보{" "}
      </div>
      <div className="bg-[#ffffff] w-[339px] h-[183px] absolute left-0 top-[263px]"></div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-2.5 top-[299px] w-10">
        총 상품금액{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-2.5 top-[315px] w-[33px]">
        총 배송비{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-2.5 top-[339px] w-[30px]">
        할인내역{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-[299px] top-[299px] w-[31px]">
        75,122원{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-[300px] top-[315px] w-7">
        2,500원{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-[299px] top-[339px] w-[30px]">
        -1,788원{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-2.5 top-[386px] w-[30px]">
        결제수단{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[7px] font-normal absolute left-[298px] top-[386px] w-7">
        토스페이{" "}
      </div>
      <div className="text-[#ea0000] text-left font-['Inter-Regular',_sans-serif] text-[10px] font-normal absolute left-[9px] top-[362px] w-14">
        총 결제금액{" "}
      </div>
      <div className="text-[#ea0000] text-left font-['Inter-Regular',_sans-serif] text-[10px] font-normal absolute left-[281px] top-[362px] w-12">
        88,888원{" "}
      </div>
      <div
        className="border-solid border-[#dbdbdb] border-t border-r-[0] border-b-[0] border-l-[0] w-[340px] h-0 absolute left-0 top-[292px]"
        style={{ marginTop: "-1px" }}
      ></div>
      <div
        className="border-solid border-[#dbdbdb] border-t border-r-[0] border-b-[0] border-l-[0] w-[340px] h-0 absolute left-0 top-[355px]"
        style={{ marginTop: "-1px" }}
      ></div>
      <div
        className="border-solid border-[#dbdbdb] border-t border-r-[0] border-b-[0] border-l-[0] w-[340px] h-0 absolute left-0 top-[400px]"
        style={{ marginTop: "-1px" }}
      ></div>
      <div
        className="bg-[#d9d9d9] border-dashed border-[#dbdbdb] border-t border-r-[0] border-b-[0] border-l-[0] w-[329px] h-0 absolute left-1 top-[334px]"
        style={{
          marginTop: "-1px",
          transformOrigin: "0 0",
          transform: "rotate(0deg) scale(1, 1)",
        }}
      ></div>
      <div
        className="bg-[#d9d9d9] border-dashed border-[#dbdbdb] border-t border-r-[0] border-b-[0] border-l-[0] w-[329px] h-0 absolute left-1 top-[383px]"
        style={{
          marginTop: "-1px",
          transformOrigin: "0 0",
          transform: "rotate(0deg) scale(1, 1)",
        }}
      ></div>
      <div className="text-[#000000] text-left font-['Inter-Medium',_sans-serif] text-xs font-medium absolute left-2.5 top-[270px] w-[54px]">
        결제정보{" "}
      </div>
      <div className="w-[202.03px] h-[25.48px] static">
        <LiquidGlassRegularSmallModeLightStateDefault className="!absolute !right-[69.97px] !left-[67px] !bottom-[352.52px] !top-[409px] !w-[unset] !h-[unset]"></LiquidGlassRegularSmallModeLightStateDefault>
      </div>
      <div className="text-[#ffffff] text-left font-['HankenGrotesk-Medium',_sans-serif] text-[11px] font-medium absolute left-[157.23px] top-[415px] w-[20.6px] h-3">
        목록{" "}
      </div>
    </div>
  );
};
