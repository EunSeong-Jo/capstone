import { BuildingBlocksStatusBar } from "../BuildingBlocksStatusBar/BuildingBlocksStatusBar";
import { ChevronBackward } from "../ChevronBackward/ChevronBackward";

export interface IComponentProps {
  className?: string;
}

export const Component = ({
  className,
  ...props
}: IComponentProps): JSX.Element => {
  return (
    <div
      className={
        "bg-[#ffffff] w-[285px] h-[787px] relative overflow-hidden " + className
      }
    >
      <BuildingBlocksStatusBar
        cameraCutout={false}
        className="!w-72 !h-[37px] !absolute !left-[-2px] !top-0"
      ></BuildingBlocksStatusBar>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[10px] font-normal absolute left-2 top-[116px] w-[37px]">
        해지{" "}
      </div>
      <div className="text-[#717171] text-left font-['Inter-Regular',_sans-serif] text-[8px] font-normal absolute left-[7px] top-[102px] w-[95px]">
        계약해지 | 2027.07.25{" "}
      </div>
      <div
        className="border-solid border-[#b1b1b1] border-t-[0.5px] border-r-[0] border-b-[0] border-l-[0] w-[285.09px] h-0 absolute left-0 top-[317px]"
        style={{
          marginTop: "-0.5px",
          transformOrigin: "0 0",
          transform: "rotate(0.108deg) scale(1, 1)",
        }}
      ></div>
      <div className="text-[#000000] text-left font-['Inter-Medium',_sans-serif] text-sm font-medium absolute left-[105px] top-[57px] w-[75px]">
        1:1 문의내역{" "}
      </div>
      <ChevronBackward className="!w-[30px] !h-[29px] !absolute !left-[7px] !top-[51px]"></ChevronBackward>
      <ChevronBackward className="!w-[21px] !h-5 !absolute !left-[255px] !top-[308px]"></ChevronBackward>
      <ChevronBackward className="!w-[21px] !h-5 !absolute !left-[255px] !top-32"></ChevronBackward>
      <ChevronBackward className="!w-[21px] !h-5 !absolute !left-[255px] !top-[349px]"></ChevronBackward>
      <div className="bg-[#eaeaea] w-[285px] h-[135px] absolute left-0 top-[139px]"></div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[10px] font-normal absolute left-[19px] top-[151px] w-[250px]">
        Q. 해지신청했는데 돈을 계속 빼가시네요? 머하시는건지?{" "}
      </div>
      <div
        className="border-solid border-[#b1b1b1] border-t-[0.5px] border-r-[0] border-b-[0] border-l-[0] w-[285.09px] h-0 absolute left-[-0.55px] top-[139px]"
        style={{
          marginTop: "-0.5px",
          transformOrigin: "0 0",
          transform: "rotate(0.108deg) scale(1, 1)",
        }}
      ></div>
      <div className="bg-[#fefefe] w-[267px] h-[93px] absolute left-2 top-[173px]"></div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[10px] font-normal absolute left-[17px] top-[180px] w-[250px]">
        A. 안녕하세요 대체모야 고객센터입니다.
        <br />
        먼저 대체모야를 이용해주셔서 감사하다는 말씀을 드립니다.
        <br />
        <br />위 자료는 불완전판매 증빙 안녕하세요 가나다라마바사아
        <br />
        동해물과 백두산이 마르고 닳도록 하느님이 불변하사 우리 <br />
        나라만세{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[10px] font-normal absolute left-[9px] top-[298px] w-[91px]">
        카드결제관련 문의{" "}
      </div>
      <div className="text-[#717171] text-left font-['Inter-Regular',_sans-serif] text-[8px] font-normal absolute left-[7.55px] top-[284px] w-[95px]">
        결제 | 2027.07.25{" "}
      </div>
      <div
        className="border-solid border-[#b1b1b1] border-t-[0.5px] border-r-[0] border-b-[0] border-l-[0] w-[285.09px] h-0 absolute left-0 top-[274px]"
        style={{
          marginTop: "-0.5px",
          transformOrigin: "0 0",
          transform: "rotate(0.108deg) scale(1, 1)",
        }}
      ></div>
      <div
        className="border-solid border-[#b1b1b1] border-t-[0.5px] border-r-[0] border-b-[0] border-l-[0] w-[285.09px] h-0 absolute left-0 top-[317px]"
        style={{
          marginTop: "-0.5px",
          transformOrigin: "0 0",
          transform: "rotate(0.108deg) scale(1, 1)",
        }}
      ></div>
      <div
        className="border-solid border-[#b1b1b1] border-t-[0.5px] border-r-[0] border-b-[0] border-l-[0] w-[285.09px] h-0 absolute left-0 top-[358px]"
        style={{
          marginTop: "-0.5px",
          transformOrigin: "0 0",
          transform: "rotate(0.108deg) scale(1, 1)",
        }}
      ></div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[10px] font-normal absolute left-[9px] top-[339px] w-20">
        배송 언제오나요{" "}
      </div>
      <div className="text-[#717171] text-left font-['Inter-Regular',_sans-serif] text-[8px] font-normal absolute left-[7.55px] top-[325px] w-[95px]">
        배송 | 2027.07.25{" "}
      </div>
      <div
        className="border-solid border-[#b1b1b1] border-t-[0.5px] border-r-[0] border-b-[0] border-l-[0] w-[285.09px] h-0 absolute left-0 top-[358px]"
        style={{
          marginTop: "-0.5px",
          transformOrigin: "0 0",
          transform: "rotate(0.108deg) scale(1, 1)",
        }}
      ></div>
      <div
        className="border-solid border-[#b1b1b1] border-t-[0.5px] border-r-[0] border-b-[0] border-l-[0] w-[285.09px] h-0 absolute left-0 top-[274px]"
        style={{
          marginTop: "-0.5px",
          transformOrigin: "0 0",
          transform: "rotate(0.108deg) scale(1, 1)",
        }}
      ></div>
    </div>
  );
};
