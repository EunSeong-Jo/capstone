export interface IShoppingCartSize20Props {
  size?: "20" | "16" | "24" | "32" | "40" | "48";
  className?: string;
}

export const ShoppingCartSize20 = ({
  size = "20",
  className,
  ...props
}: IShoppingCartSize20Props): JSX.Element => {
  const variantsClassName = "size-" + size;

  return (
    <img
      className={
        "w-5 h-5 relative overflow-visible " +
        className +
        " " +
        variantsClassName
      }
      src="shopping-cart-size-20.svg"
    />
  );
};
