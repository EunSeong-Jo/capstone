import { BuildingBlocksStatusBar } from "../BuildingBlocksStatusBar/BuildingBlocksStatusBar";
import { ShoppingCartSize20 } from "../ShoppingCartSize20/ShoppingCartSize20";
import { SearchSize20 } from "../SearchSize20/SearchSize20";
import { ChevronBackward } from "../ChevronBackward/ChevronBackward";

export interface IComponentProps {
  className?: string;
}

export const Component = ({
  className,
  ...props
}: IComponentProps): JSX.Element => {
  return (
    <div
      className={"bg-[#ffffff] h-[892px] relative overflow-hidden " + className}
    >
      <div className="bg-[#f6f6f6] w-[393px] h-[741px] absolute left-0 top-[151px]"></div>
      <BuildingBlocksStatusBar
        cameraCutout={false}
        className="!w-[396px] !h-[37px] !absolute !left-[-2px] !top-0"
      ></BuildingBlocksStatusBar>
      <div className="text-[#000000] text-left font-['Inter-Medium',_sans-serif] text-sm font-medium absolute left-[153px] top-[57px]">
        주문/ 배송내역{" "}
      </div>
      <div className="bg-[#ffffff] w-[393px] h-[156px] absolute left-px top-[171px]"></div>
      <div className="text-[#000000] text-left font-['Inter-Medium',_sans-serif] text-xs font-medium absolute left-[18px] top-[179px]">
        상품준비중{" "}
      </div>
      <div className="bg-[#d9d9d9] rounded-[5px] w-[58px] h-[58px] absolute left-[18px] top-[204px]"></div>
      <div className="text-[#979797] text-left font-['Inter-Regular',_sans-serif] text-[8px] font-normal absolute left-[85px] top-[204px]">
        07.25 결제{" "}
      </div>
      <div className="bg-[#ffffff] w-[393px] h-[58px] absolute left-0 top-[93px]"></div>
      <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[11px] font-light absolute left-[85px] top-[218px]">
        [피카소] FB14파운데이션 브러쉬{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Bold',_sans-serif] text-[11px] font-bold absolute left-[85px] top-[234px]">
        35,421원{" "}
      </div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#559371] border-[0.7px] w-[352px] h-[22px] absolute left-[18px] top-[271px]"></div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#818181] border-[0.7px] w-[173px] h-[22px] absolute left-[18px] top-[297px]"></div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#818181] border-[0.7px] w-44 h-[22px] absolute left-[194px] top-[297px]"></div>
      <div className="text-[#559371] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[167px] top-[276px]">
        한달사용리뷰{" "}
      </div>
      <div className="text-[#818181] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[253px] top-[303px]">
        취소/반품/교환{" "}
      </div>
      <div className="text-[#818181] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[85px] top-[303px]">
        상세보기{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Medium',_sans-serif] text-xs font-medium absolute left-[18px] top-[179px]">
        상품준비중{" "}
      </div>
      <div className="bg-[#d9d9d9] rounded-[5px] w-[58px] h-[58px] absolute left-[18px] top-[204px]"></div>
      <div className="text-[#979797] text-left font-['Inter-Regular',_sans-serif] text-[8px] font-normal absolute left-[85px] top-[204px]">
        07.25 결제{" "}
      </div>
      <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[11px] font-light absolute left-[85px] top-[218px]">
        [피카소] FB14파운데이션 브러쉬{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Bold',_sans-serif] text-[11px] font-bold absolute left-[85px] top-[234px]">
        35,421원{" "}
      </div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#559371] border-[0.7px] w-[352px] h-[22px] absolute left-[18px] top-[271px]"></div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#818181] border-[0.7px] w-[173px] h-[22px] absolute left-[18px] top-[297px]"></div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#818181] border-[0.7px] w-44 h-[22px] absolute left-[194px] top-[297px]"></div>
      <div className="text-[#559371] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[167px] top-[276px]">
        한달사용리뷰{" "}
      </div>
      <div className="text-[#818181] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[253px] top-[303px]">
        취소/반품/교환{" "}
      </div>
      <div className="text-[#818181] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[85px] top-[303px]">
        상세보기{" "}
      </div>
      <div className="bg-[#ffffff] w-[393px] h-[156px] absolute left-px top-[341px]"></div>
      <div className="text-[#000000] text-left font-['Inter-Medium',_sans-serif] text-xs font-medium absolute left-[18px] top-[349px]">
        상품준비중{" "}
      </div>
      <div className="bg-[#d9d9d9] rounded-[5px] w-[58px] h-[58px] absolute left-[18px] top-[374px]"></div>
      <div className="text-[#979797] text-left font-['Inter-Regular',_sans-serif] text-[8px] font-normal absolute left-[85px] top-[374px]">
        07.25 결제{" "}
      </div>
      <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[11px] font-light absolute left-[85px] top-[388px]">
        [피카소] FB14파운데이션 브러쉬{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Bold',_sans-serif] text-[11px] font-bold absolute left-[85px] top-[404px]">
        35,421원{" "}
      </div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#559371] border-[0.7px] w-[352px] h-[22px] absolute left-[18px] top-[441px]"></div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#818181] border-[0.7px] w-[173px] h-[22px] absolute left-[18px] top-[467px]"></div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#818181] border-[0.7px] w-44 h-[22px] absolute left-[194px] top-[467px]"></div>
      <div className="text-[#559371] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[167px] top-[446px]">
        한달사용리뷰{" "}
      </div>
      <div className="text-[#818181] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[253px] top-[473px]">
        취소/반품/교환{" "}
      </div>
      <div className="text-[#818181] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[85px] top-[473px]">
        상세보기{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Medium',_sans-serif] text-xs font-medium absolute left-[18px] top-[349px]">
        상품준비중{" "}
      </div>
      <div className="bg-[#d9d9d9] rounded-[5px] w-[58px] h-[58px] absolute left-[18px] top-[374px]"></div>
      <div className="text-[#979797] text-left font-['Inter-Regular',_sans-serif] text-[8px] font-normal absolute left-[85px] top-[374px]">
        07.25 결제{" "}
      </div>
      <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[11px] font-light absolute left-[85px] top-[388px]">
        [피카소] FB14파운데이션 브러쉬{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Bold',_sans-serif] text-[11px] font-bold absolute left-[85px] top-[404px]">
        35,421원{" "}
      </div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#559371] border-[0.7px] w-[352px] h-[22px] absolute left-[18px] top-[441px]"></div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#818181] border-[0.7px] w-[173px] h-[22px] absolute left-[18px] top-[467px]"></div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#818181] border-[0.7px] w-44 h-[22px] absolute left-[194px] top-[467px]"></div>
      <div className="text-[#559371] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[167px] top-[446px]">
        한달사용리뷰{" "}
      </div>
      <div className="text-[#818181] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[253px] top-[473px]">
        취소/반품/교환{" "}
      </div>
      <div className="text-[#818181] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[85px] top-[473px]">
        상세보기{" "}
      </div>
      <div className="bg-[#ffffff] w-[393px] h-[156px] absolute left-px top-[511px]"></div>
      <div className="text-[#000000] text-left font-['Inter-Medium',_sans-serif] text-xs font-medium absolute left-[18px] top-[519px]">
        상품준비중{" "}
      </div>
      <div className="bg-[#d9d9d9] rounded-[5px] w-[58px] h-[58px] absolute left-[18px] top-[544px]"></div>
      <div className="text-[#979797] text-left font-['Inter-Regular',_sans-serif] text-[8px] font-normal absolute left-[85px] top-[544px]">
        07.25 결제{" "}
      </div>
      <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[11px] font-light absolute left-[85px] top-[558px]">
        [피카소] FB14파운데이션 브러쉬{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Bold',_sans-serif] text-[11px] font-bold absolute left-[85px] top-[574px]">
        35,421원{" "}
      </div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#559371] border-[0.7px] w-[352px] h-[22px] absolute left-[18px] top-[611px]"></div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#818181] border-[0.7px] w-[173px] h-[22px] absolute left-[18px] top-[637px]"></div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#818181] border-[0.7px] w-44 h-[22px] absolute left-[194px] top-[637px]"></div>
      <div className="text-[#559371] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[167px] top-[616px]">
        한달사용리뷰{" "}
      </div>
      <div className="text-[#818181] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[253px] top-[643px]">
        취소/반품/교환{" "}
      </div>
      <div className="text-[#818181] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[85px] top-[643px]">
        상세보기{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Medium',_sans-serif] text-xs font-medium absolute left-[18px] top-[519px]">
        상품준비중{" "}
      </div>
      <div className="bg-[#d9d9d9] rounded-[5px] w-[58px] h-[58px] absolute left-[18px] top-[544px]"></div>
      <div className="text-[#979797] text-left font-['Inter-Regular',_sans-serif] text-[8px] font-normal absolute left-[85px] top-[544px]">
        07.25 결제{" "}
      </div>
      <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[11px] font-light absolute left-[85px] top-[558px]">
        [피카소] FB14파운데이션 브러쉬{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Bold',_sans-serif] text-[11px] font-bold absolute left-[85px] top-[574px]">
        35,421원{" "}
      </div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#559371] border-[0.7px] w-[352px] h-[22px] absolute left-[18px] top-[611px]"></div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#818181] border-[0.7px] w-[173px] h-[22px] absolute left-[18px] top-[637px]"></div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#818181] border-[0.7px] w-44 h-[22px] absolute left-[194px] top-[637px]"></div>
      <div className="text-[#559371] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[167px] top-[616px]">
        한달사용리뷰{" "}
      </div>
      <div className="text-[#818181] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[253px] top-[643px]">
        취소/반품/교환{" "}
      </div>
      <div className="text-[#818181] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[85px] top-[643px]">
        상세보기{" "}
      </div>
      <div className="bg-[#ffffff] w-[393px] h-[156px] absolute left-px top-[681px]"></div>
      <div className="text-[#000000] text-left font-['Inter-Medium',_sans-serif] text-xs font-medium absolute left-[18px] top-[689px]">
        상품준비중{" "}
      </div>
      <div className="bg-[#d9d9d9] rounded-[5px] w-[58px] h-[58px] absolute left-[18px] top-[714px]"></div>
      <div className="text-[#979797] text-left font-['Inter-Regular',_sans-serif] text-[8px] font-normal absolute left-[85px] top-[714px]">
        07.25 결제{" "}
      </div>
      <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[11px] font-light absolute left-[85px] top-[728px]">
        [피카소] FB14파운데이션 브러쉬{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Bold',_sans-serif] text-[11px] font-bold absolute left-[85px] top-[744px]">
        35,421원{" "}
      </div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#559371] border-[0.7px] w-[352px] h-[22px] absolute left-[18px] top-[781px]"></div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#818181] border-[0.7px] w-[173px] h-[22px] absolute left-[18px] top-[807px]"></div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#818181] border-[0.7px] w-44 h-[22px] absolute left-[194px] top-[807px]"></div>
      <div className="text-[#559371] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[167px] top-[786px]">
        한달사용리뷰{" "}
      </div>
      <div className="text-[#818181] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[253px] top-[813px]">
        취소/반품/교환{" "}
      </div>
      <div className="text-[#818181] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[85px] top-[813px]">
        상세보기{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Medium',_sans-serif] text-xs font-medium absolute left-[18px] top-[689px]">
        상품준비중{" "}
      </div>
      <div className="bg-[#d9d9d9] rounded-[5px] w-[58px] h-[58px] absolute left-[18px] top-[714px]"></div>
      <div className="text-[#979797] text-left font-['Inter-Regular',_sans-serif] text-[8px] font-normal absolute left-[85px] top-[714px]">
        07.25 결제{" "}
      </div>
      <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[11px] font-light absolute left-[85px] top-[728px]">
        [피카소] FB14파운데이션 브러쉬{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Bold',_sans-serif] text-[11px] font-bold absolute left-[85px] top-[744px]">
        35,421원{" "}
      </div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#559371] border-[0.7px] w-[352px] h-[22px] absolute left-[18px] top-[781px]"></div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#818181] border-[0.7px] w-[173px] h-[22px] absolute left-[18px] top-[807px]"></div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#818181] border-[0.7px] w-44 h-[22px] absolute left-[194px] top-[807px]"></div>
      <div className="text-[#559371] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[167px] top-[786px]">
        한달사용리뷰{" "}
      </div>
      <div className="text-[#818181] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[253px] top-[813px]">
        취소/반품/교환{" "}
      </div>
      <div className="text-[#818181] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[85px] top-[813px]">
        상세보기{" "}
      </div>
      <div className="bg-[#ffffff] w-[393px] h-[156px] absolute left-px top-[171px]"></div>
      <div className="text-[#000000] text-left font-['Inter-Medium',_sans-serif] text-xs font-medium absolute left-[18px] top-[179px]">
        상품준비중{" "}
      </div>
      <div className="bg-[#d9d9d9] rounded-[5px] w-[58px] h-[58px] absolute left-[18px] top-[204px]"></div>
      <div className="text-[#979797] text-left font-['Inter-Regular',_sans-serif] text-[8px] font-normal absolute left-[85px] top-[204px]">
        07.25 결제{" "}
      </div>
      <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[11px] font-light absolute left-[85px] top-[218px]">
        [피카소] FB14파운데이션 브러쉬{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Bold',_sans-serif] text-[11px] font-bold absolute left-[85px] top-[234px]">
        35,421원{" "}
      </div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#559371] border-[0.7px] w-[352px] h-[22px] absolute left-[18px] top-[271px]"></div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#818181] border-[0.7px] w-[173px] h-[22px] absolute left-[18px] top-[297px]"></div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#818181] border-[0.7px] w-44 h-[22px] absolute left-[194px] top-[297px]"></div>
      <div className="text-[#559371] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[167px] top-[276px]">
        한달사용리뷰{" "}
      </div>
      <div className="text-[#818181] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[253px] top-[303px]">
        취소/반품/교환{" "}
      </div>
      <div className="text-[#818181] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[85px] top-[303px]">
        상세보기{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Medium',_sans-serif] text-xs font-medium absolute left-[18px] top-[179px]">
        상품준비중{" "}
      </div>
      <div className="bg-[#d9d9d9] rounded-[5px] w-[58px] h-[58px] absolute left-[18px] top-[204px]"></div>
      <div className="text-[#979797] text-left font-['Inter-Regular',_sans-serif] text-[8px] font-normal absolute left-[85px] top-[204px]">
        07.25 결제{" "}
      </div>
      <div className="text-[#000000] text-left font-['Geom-Light',_sans-serif] text-[11px] font-light absolute left-[85px] top-[218px]">
        [피카소] FB14파운데이션 브러쉬{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Bold',_sans-serif] text-[11px] font-bold absolute left-[85px] top-[234px]">
        35,421원{" "}
      </div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#559371] border-[0.7px] w-[352px] h-[22px] absolute left-[18px] top-[271px]"></div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#818181] border-[0.7px] w-[173px] h-[22px] absolute left-[18px] top-[297px]"></div>
      <div className="bg-[#ffffff] rounded-[3px] border-solid border-[#818181] border-[0.7px] w-44 h-[22px] absolute left-[194px] top-[297px]"></div>
      <div className="text-[#559371] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[167px] top-[276px]">
        한달사용리뷰{" "}
      </div>
      <div className="text-[#818181] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[253px] top-[303px]">
        취소/반품/교환{" "}
      </div>
      <div className="text-[#818181] text-left font-['Inter-Regular',_sans-serif] text-[9px] font-normal absolute left-[85px] top-[303px]">
        상세보기{" "}
      </div>
      <div className="text-[#8b8b8b] text-left font-['Inter-Regular',_sans-serif] text-[10px] font-normal absolute left-[47px] top-[101px]">
        배송중{" "}
      </div>
      <div className="text-[#8b8b8b] text-left font-['Inter-Regular',_sans-serif] text-[10px] font-normal absolute left-[173px] top-[101px]">
        배송완료{" "}
      </div>
      <div className="text-[#8b8b8b] text-left font-['Inter-Regular',_sans-serif] text-[10px] font-normal absolute left-[307px] top-[101px]">
        취소/반품{" "}
      </div>
      <div
        className="border-solid border-[#000000] border-t border-r-[0] border-b-[0] border-l-[0] w-5 h-0 absolute left-[117px] top-[116px]"
        style={{
          marginTop: "-1px",
          transformOrigin: "0 0",
          transform: "rotate(90deg) scale(1, 1)",
        }}
      ></div>
      <div
        className="border-solid border-[#000000] border-t border-r-[0] border-b-[0] border-l-[0] w-5 h-0 absolute left-[271px] top-[116px]"
        style={{
          marginTop: "-1px",
          transformOrigin: "0 0",
          transform: "rotate(90deg) scale(1, 1)",
        }}
      ></div>
      <div className="text-[#559371] text-left font-['Inter-SemiBold',_sans-serif] text-sm font-semibold absolute left-14 top-[125px]">
        0{" "}
      </div>
      <div className="text-[#559371] text-left font-['Inter-SemiBold',_sans-serif] text-sm font-semibold absolute left-[187px] top-[125px]">
        0{" "}
      </div>
      <div className="text-[#559371] text-left font-['Inter-SemiBold',_sans-serif] text-sm font-semibold absolute left-[323px] top-[125px]">
        0{" "}
      </div>
      <ShoppingCartSize20 className="!absolute !left-[356px] !top-14 !shrink-[unset]"></ShoppingCartSize20>
      <SearchSize20 className="!w-[23px] !h-[23px] !absolute !left-[315px] !top-[54px] !shrink-[unset]"></SearchSize20>
      <ChevronBackward className="!w-[30px] !h-[29px] !absolute !left-2.5 !top-[51px]"></ChevronBackward>
    </div>
  );
};
