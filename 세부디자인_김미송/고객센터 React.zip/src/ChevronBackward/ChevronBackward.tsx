export interface IChevronBackwardProps {
  className?: string;
}

export const ChevronBackward = ({
  className,
  ...props
}: IChevronBackwardProps): JSX.Element => {
  return (
    <img
      className={"w-[30px] h-[29px] relative overflow-visible " + className}
      src="chevron-backward.svg"
    />
  );
};
