import { BuildingBlocksStatusBar } from "../BuildingBlocksStatusBar/BuildingBlocksStatusBar";
import { ChevronBackward } from "../ChevronBackward/ChevronBackward";
import { SearchSize20 } from "../SearchSize20/SearchSize20";

export interface IComponentProps {
  className?: string;
}

export const Component = ({
  className,
  ...props
}: IComponentProps): JSX.Element => {
  return (
    <div
      className={"bg-[#ffffff] h-[787px] relative overflow-hidden " + className}
    >
      <BuildingBlocksStatusBar
        cameraCutout={false}
        className="!w-[396px] !h-[37px] !absolute !left-[-2px] !top-0"
      ></BuildingBlocksStatusBar>
      <div className="text-[#000000] text-left font-['Inter-Medium',_sans-serif] text-sm font-medium absolute left-[171px] top-[57px]">
        고객센터{" "}
      </div>
      <ChevronBackward className="!w-[30px] !h-[29px] !absolute !left-2.5 !top-[51px]"></ChevronBackward>
      <div className="text-[#000000] text-left font-['Inter-Medium',_sans-serif] text-sm font-medium absolute left-[171px] top-[57px]">
        고객센터{" "}
      </div>
      <ChevronBackward className="!w-[30px] !h-[29px] !absolute !left-2.5 !top-[51px]"></ChevronBackward>
      <div
        className="border-solid border-[#dbdbdb] border-t border-r-[0] border-b-[0] border-l-[0] w-[393px] h-0 absolute left-[-1px] top-[146px]"
        style={{
          marginTop: "-1px",
          transformOrigin: "0 0",
          transform: "rotate(-0.146deg) scale(1, 1)",
        }}
      ></div>
      <div className="bg-[#ffffff] rounded-[20px] border-solid border-[#b7b7b7] border-[0.5px] w-[353px] h-[30px] absolute left-[17px] top-[157px]"></div>
      <SearchSize20 className="!w-[23px] !h-[23px] !absolute !left-[337px] !top-40 !shrink-[unset]"></SearchSize20>
      <div className="text-[#8e8e8e] text-left font-['Inter-Light',_sans-serif] text-[10px] font-light absolute left-[37px] top-[166px]">
        질문 키워드를 입력해 주세요.{" "}
      </div>
      <div className="bg-[#ffffff] border-solid border-[#559371] border-b w-[81px] h-[33px] absolute left-[60px] top-[111px]"></div>
      <div className="text-[#a2a2a2] text-left font-['Inter-Regular',_sans-serif] text-xs font-normal absolute left-[88px] top-[121px] w-[25px]">
        FAQ{" "}
      </div>
      <div className="bg-[#ffffff] border-solid border-[#559371] border-b w-[114.56px] h-[33px] absolute left-[229px] top-[111px]"></div>
      <div className="text-[#a2a2a2] text-center font-['Aubrey-Regular',_sans-serif] text-xs font-normal absolute left-[231.33px] top-[123px] w-[109.23px]">
        내 문의내역{" "}
      </div>
      <div className="text-left font-['Inter-SemiBold',_sans-serif] text-xs font-semibold absolute left-[9px] top-[210px]">
        <span>
          <span className="top-3-span">자주 문는 질문</span>
          <span className="top-3-span2">TOP3</span>
        </span>{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-SemiBold',_sans-serif] text-xs font-semibold absolute left-[9px] top-[336px]">
        주문 / 결제{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[10px] font-normal absolute left-[30px] top-[241px]">
        배송기간은 어떻게 되나요?{" "}
      </div>
      <div className="text-[#559371] text-left font-['Inter-Bold',_sans-serif] text-xs font-bold absolute left-3.5 top-60">
        1{" "}
      </div>
      <div className="text-[#559371] text-left font-['Inter-Bold',_sans-serif] text-xs font-bold absolute left-3.5 top-[269px]">
        2{" "}
      </div>
      <div className="text-[#559371] text-left font-['Inter-Bold',_sans-serif] text-xs font-bold absolute left-3.5 top-[296px]">
        3{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[10px] font-normal absolute left-[30px] top-[271px]">
        취소(반품)했는데 사용한 쿠폰/포인트 복원 되나요?{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[10px] font-normal absolute left-[29px] top-[298px]">
        취소(반품)했는데 언제 환불 되나요?{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[10px] font-normal absolute left-[9px] top-[361px]">
        현금 결제는 어떻게 하나요?{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[10px] font-normal absolute left-[9px] top-[386px]">
        입금자 명을 바꾸고 싶어요{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[10px] font-normal absolute left-[9px] top-[411px]">
        현금영수증 발급은 어떻게 받나요?{" "}
      </div>
      <div
        className="border-solid border-[#b1b1b1] border-t-[0.5px] border-r-[0] border-b-[0] border-l-[0] w-[392px] h-0 absolute left-0 top-[379px]"
        style={{
          marginTop: "-0.5px",
          transformOrigin: "0 0",
          transform: "rotate(0.148deg) scale(1, 1)",
        }}
      ></div>
      <div
        className="border-solid border-[#b1b1b1] border-t-[0.5px] border-r-[0] border-b-[0] border-l-[0] w-[392px] h-0 absolute left-0 top-[292px]"
        style={{
          marginTop: "-0.5px",
          transformOrigin: "0 0",
          transform: "rotate(0.148deg) scale(1, 1)",
        }}
      ></div>
      <div
        className="border-solid border-[#b1b1b1] border-t-[0.5px] border-r-[0] border-b-[0] border-l-[0] w-[392px] h-0 absolute left-0 top-[262px]"
        style={{
          marginTop: "-0.5px",
          transformOrigin: "0 0",
          transform: "rotate(0.148deg) scale(1, 1)",
        }}
      ></div>
      <div
        className="border-solid border-[#b1b1b1] border-t-[0.5px] border-r-[0] border-b-[0] border-l-[0] w-[392px] h-0 absolute left-0 top-[404px]"
        style={{
          marginTop: "-0.5px",
          transformOrigin: "0 0",
          transform: "rotate(0.148deg) scale(1, 1)",
        }}
      ></div>
      <div className="text-[#000000] text-left font-['Inter-SemiBold',_sans-serif] text-xs font-semibold absolute left-[9px] top-[454px]">
        배송{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[10px] font-normal absolute left-[9px] top-[479px]">
        배송기간은 어떻게 되나요?{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[10px] font-normal absolute left-[9px] top-[504px]">
        입금자 명을 바꾸고 싶어요{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[10px] font-normal absolute left-[9px] top-[529px]">
        현금영수증 발급은 어떻게 받나요?{" "}
      </div>
      <div
        className="border-solid border-[#b1b1b1] border-t-[0.5px] border-r-[0] border-b-[0] border-l-[0] w-[392px] h-0 absolute left-0 top-[497px]"
        style={{
          marginTop: "-0.5px",
          transformOrigin: "0 0",
          transform: "rotate(0.148deg) scale(1, 1)",
        }}
      ></div>
      <div
        className="border-solid border-[#b1b1b1] border-t-[0.5px] border-r-[0] border-b-[0] border-l-[0] w-[392px] h-0 absolute left-0 top-[522px]"
        style={{
          marginTop: "-0.5px",
          transformOrigin: "0 0",
          transform: "rotate(0.148deg) scale(1, 1)",
        }}
      ></div>
      <div className="text-[#000000] text-left font-['Inter-SemiBold',_sans-serif] text-xs font-semibold absolute left-[9px] top-[572px]">
        아이디 찾기{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[10px] font-normal absolute left-[9px] top-[597px]">
        전체 아이디를 확인하고 싶어요.{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[10px] font-normal absolute left-[9px] top-[622px]">
        아이디 찾기를 했는데, 제가 사용하던 게정이 아니에요.{" "}
      </div>
      <div className="text-[#000000] text-left font-['Inter-Regular',_sans-serif] text-[10px] font-normal absolute left-[9px] top-[647px]">
        소셜(카카오/네이버/애플/페이스북) 게정을 탈퇴해서, 연동 로그인이 안
        돼요.{" "}
      </div>
      <div
        className="border-solid border-[#b1b1b1] border-t-[0.5px] border-r-[0] border-b-[0] border-l-[0] w-[392px] h-0 absolute left-0 top-[615px]"
        style={{
          marginTop: "-0.5px",
          transformOrigin: "0 0",
          transform: "rotate(0.148deg) scale(1, 1)",
        }}
      ></div>
      <div
        className="border-solid border-[#b1b1b1] border-t-[0.5px] border-r-[0] border-b-[0] border-l-[0] w-[392px] h-0 absolute left-0 top-[640px]"
        style={{
          marginTop: "-0.5px",
          transformOrigin: "0 0",
          transform: "rotate(0.148deg) scale(1, 1)",
        }}
      ></div>
    </div>
  );
};
